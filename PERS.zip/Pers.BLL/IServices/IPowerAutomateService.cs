﻿using Microsoft.AspNetCore.Mvc;
using Pers.BLL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.BLL.IServices
{
    public interface IPowerAutomateService
    {
        Task<Response<string>> SendForm(CandidateProfileDTO CandidateDTO);
        Task<Response<string>> MakeRequestAsync(HttpRequestMessage getRequest, HttpClient client);
        Task<Response<string>> SendApprovalStageContractProposal(StageContractProposalDTO stageContractProposalDTO);
		Task<Response<string>> SendApprovalHiredContractProposal(HiredContractProposalDTO hiredContractProposalDTO);
	}
}
