﻿using Microsoft.AspNetCore.Mvc;
using Pers.BLL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.BLL.IServices
{
    public interface IFullCandidateProfileService
    {
        
        Task<ListResponse<FullCandidateProfileDTO>> GetAll();
        Task<Response<FullCandidateProfileDTO>> Put(FullCandidateProfileDTO candidateProfileDTO);
        Task<Response<FullCandidateProfileDTO>> Delete(int id);
        Task<Response<FullCandidateProfileDTO>> Find(int id);
    }
}
