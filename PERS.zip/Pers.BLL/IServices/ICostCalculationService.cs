﻿using Pers.BLL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.BLL.IServices
{
    public interface ICostCalculationService
    {
        Task<Response<MarginDTO>> GenerateMarginResourceCost(ContractDTO contractDTO);
    }
}
