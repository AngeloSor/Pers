﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Pers.BLL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.BLL.IServices
{
    public interface IPersonalDetailsService
    {
        Task<Response<PersonalDetailsDTO>> Create(PersonalDetailsDTO bmhrProfileDTO);
        Task<Response<PersonalDetailsDTO>> Find(int id);
        Task<Response<PersonalDetailsDTO>> FindDetailsForSpecificCandidate(int idCandidate);
        Task<Response<PersonalDetailsDTO>> Put(PersonalDetailsDTO bmhrProfileDTO);
        Task<Response<PersonalDetailsDTO>> Delete(int id);
        Task<Response<PersonalDetailsDTO>> FilesManagement(FilesDTO files);
        Task<Response<string>> GetIdCard(int candidateId);
        Task<Response<string>> GetHealthCard(int candidateId);
        Task<Response<string>> GetResidencepermit(int candidateId);
        Task<bool> HasResidencePermit(int candidateId);


    }
}
