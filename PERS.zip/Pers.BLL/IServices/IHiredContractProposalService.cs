﻿using Pers.BLL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.BLL.IServices
{
    public interface IHiredContractProposalService
    {
        Task<Response<HiredContractProposalDTO>> Create(HiredContractProposalDTO hireContract);
        Task<Response<HiredContractProposalDTO>> Put (HiredContractProposalDTO hireContract);
        Task<Response<HiredContractProposalDTO>> Find(int id);
        Task<Response<HiredContractProposalDTO>> Delete(int id);
        Task<ListResponse<HiredContractProposalDTO>> GetAll();
    }
}
