﻿using Microsoft.AspNetCore.Mvc;
using Pers.BLL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.BLL.IServices
{//TODO: Implementare IService con Generics per CRud
	public interface ICandidateProfileService
	{
		Task<Response<CandidateProfileDTO>> Create(CandidateProfileDTO candidateProfileDTO);
		Task<ListResponse<CandidateProfileDTO>> GetAll();
		Task<Response<CandidateProfileDTO>> Put(CandidateProfileDTO candidateProfileDTO);
        Task<Response<CandidateProfileDTO>> Find(int id);
        Task<ListResponse<CandidateProfileDTO>> GetAllCandidateWithAcceptedForm();
        Task<ListResponse<CandidateProfileDTO>> GetAllCandidateBm(int bmProfileId);
        Task<Response<CandidateProfileDTO>> SetFormToSend(int id);
        Task<Response<CandidateProfileDTO>> SetFormToCompiled(int id);
        Task<Response<CandidateProfileDTO>> SetCareer(int id);
        


    }




}
