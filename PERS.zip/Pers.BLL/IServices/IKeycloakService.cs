﻿using Pers.BLL.Models;
using Pers.DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.BLL.IServices
{
    public interface IKeycloakService
    {
        Task<string> CreateUserOnKeycloak(UserKeycloak bmHrKeycloak);
        Task<string> GetIdKeycloak(string email);
        Task<Response<KeycloakResponse>> Login(CredentialDTO credentialDTO);
        Task<Response<KeycloakResponse>> RefreshToken(string token);
        Task<bool> SetPasswordOnKeycloak(string password, string userId);
        Task<bool> SetGroupOnUser(string userId, string groupId);
    }
}
