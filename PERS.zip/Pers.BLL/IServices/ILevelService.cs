﻿using Pers.BLL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.BLL.IServices
{
    public interface ILevelService
    {
        Task<Response<LevelDTO>> Create(LevelDTO levelDTO);
        Task<Response<LevelDTO>> Find(int id);
      
        Task<ListResponse<LevelDTO>> GetAll();
        Task<Response<LevelDTO>> Put(LevelDTO levelDTO);
        Task<Response<LevelDTO>> Delete(int id);
    }
}
