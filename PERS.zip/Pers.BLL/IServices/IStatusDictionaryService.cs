﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.BLL.IServices
{
    public interface IStatusDictionaryService
    {
        Dictionary<string, string> GetDictionary(string language);
        string GetDictionaryValue(string key);
    }
}
