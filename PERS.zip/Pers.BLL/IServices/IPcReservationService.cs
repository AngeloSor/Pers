﻿using Microsoft.EntityFrameworkCore.Metadata;
using Pers.BLL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.BLL.IServices
{
    public interface IPcReservationService
    {
        Task<Response<PcReservationDTO>> Create(PcReservationDTO pcReservationDTO);
        Task<Response<PcReservationDTO>> Update(PcReservationDTO pcReservationDTO);
        Task<Response<SmallReservationDTO>> FindSmall(int id);
        Task<Response<PcReservationDTO>> Find(int id);
        Task <ListResponse<PcReservationDTO>> GetAll();
        Task<ListResponse<SmallReservationDTO>> GetAllSmall();
        Task <Response<bool>>Delete(int id);
    }
}
