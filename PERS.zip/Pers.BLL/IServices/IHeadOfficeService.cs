﻿using Pers.BLL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.BLL.IServices
{
    public interface IHeadOfficeService 
    {
        Task<Response<HeadOfficeDTO>> Create(HeadOfficeDTO headOfficeDTO);
        Task<Response<HeadOfficeDTO>> Find(int id);
        Task<ListResponse<HeadOfficeDTO>> GetAll();
        Task<Response<HeadOfficeDTO>> Put(HeadOfficeDTO bmhrProfileDTO);
        Task<Response<HeadOfficeDTO>> Delete(int id);

    }
}
