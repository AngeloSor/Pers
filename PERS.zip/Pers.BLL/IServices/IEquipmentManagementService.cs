﻿using Pers.BLL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.BLL.IServices
{
    public interface IEquipmentManagementService
    {
        Task<Response<EquipmentManagementDTO>> Create(EquipmentManagementDTO equipmentManagementDTO);
        Task<Response<EquipmentManagementDTO>> Update(EquipmentManagementDTO equipmentManagementDTO);
        Task<Response<EquipmentManagementDTO>> Find(int id);
        Task<ListResponse<EquipmentManagementDTO>> GetAll();
        Task<Response<EquipmentManagementDTO>> Delete(int id);
    }
}
