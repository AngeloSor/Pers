﻿using Microsoft.AspNetCore.Http;
using Pers.BLL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.BLL.IServices
{
    public interface IAzureBlobService
    {
        Task<bool> UploadBlob(Stream file);
        Task<IFormFile> DownloadBlob();
    }
}
