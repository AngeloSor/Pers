﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Pers.BLL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.BLL.IServices
{
    public interface IBmHrProfileService
    {
        Task<Response<BmHrProfileDTO>> Create(BmHrProfileDTO bmhrProfileDTO);
        Task<Response<BmHrProfileDTO>> Find(int id);
        Task<Response<BmHrProfileDTO>> Find(string email);
        Task<ListResponse<BmHrProfileDTO>> GetAll();
        Task<Response<BmHrProfileDTO>> Put(BmHrProfileDTO bmhrProfileDTO);
        Task<Response<BmHrProfileDTO>> Delete(int id);
    }
}
