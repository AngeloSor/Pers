﻿using Microsoft.AspNetCore.Mvc;
using Pers.BLL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.BLL.IServices
{
	public interface IStageContractProposalService
	{
	  Task<Response<StageContractProposalDTO>> Create(StageContractProposalDTO stageContractProposalDTO);
	  Task<Response<StageContractProposalDTO>> Update(StageContractProposalDTO stageContractProposalDTO);
	  Task<ListResponse<StageContractProposalDTO>> GetAll();
	  Task<Response<StageContractProposalDTO>> Find(int id);
      Task<Response<StageContractProposalDTO>> Delete(int id);
		Task<Response<StageContractProposalDTO>> FindContractProposal(int candidateId);
	}

      
    
}
