﻿using Pers.BLL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.BLL.IServices
{
    public interface IContractProposalService
    {
        Task<Response<ContractProposalDTO>> Create(ContractProposalDTO contractProposalDTO);
        Task<Response<bool>> Delete(int id);
        Task<Response<ContractProposalDTO>> Find(int id);
        Task<Response<ContractProposalDTO>> Update(ContractProposalDTO contractProposalDTO);
        Task<ListResponse<ContractProposalDTO>> GetAll();
    }
}
