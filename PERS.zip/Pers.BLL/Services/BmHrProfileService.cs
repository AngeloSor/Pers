﻿using AutoMapper;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Pers.BLL.IServices;
using Pers.BLL.Models;
using Pers.DAL.Entities;
using Pers.DAL.IRepositories;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Net;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Text;
using System.Text.RegularExpressions;

namespace Pers.BLL.Services
{
    public class BmHrProfileService : IBmHrProfileService
    {
        private readonly ILogger<BmHrProfileService> _logger;
        private readonly IBmHrProfileRepository _bmhrRepository;
        private readonly IMapper _mapper;
        private readonly IStatusDictionaryService _statusDictionaryService;
        private readonly IKeycloakService _keycloakService;
        private readonly string keycloakId;
        private readonly List<string> roles;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IConfiguration _configuration;
        public BmHrProfileService(IBmHrProfileRepository bmhrRepository, IMapper mapper,IHttpContextAccessor httpContextAccessor, ILogger<BmHrProfileService> logger, IStatusDictionaryService statusDictionaryService, IKeycloakService keycloakService, IConfiguration configuration)
        {
            _bmhrRepository = bmhrRepository;
            _mapper = mapper;
            _httpContextAccessor = httpContextAccessor;
            _statusDictionaryService = statusDictionaryService;
            _logger = logger;
            _keycloakService = keycloakService;
            keycloakId = GetClaim(ClaimTypes.NameIdentifier);
            roles = GetClaimRole("resource_access");
            _keycloakService = keycloakService;
            _configuration = configuration;
        }
        public async Task<Response<BmHrProfileDTO>> Create(BmHrProfileDTO bmHrProfileDTO)
        {
            try
            {
                if (!FormatCheckFields(bmHrProfileDTO))
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("BadRequestFormatCheckFields"));
                    return new Response<BmHrProfileDTO> { Success = false, StatusCode = HttpStatusCode.BadRequest, Message = "BadRequestFormatCheckFields" };
                }
                if (!FormatCheckFiscalCode(bmHrProfileDTO.FiscalCode))
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("BadRequestFormatFiscalCode"));
                    return new Response<BmHrProfileDTO> { Success = false, StatusCode = HttpStatusCode.BadRequest, Message = "BadRequestFormatFiscalCode" };
                }
                UserKeycloak keycloakProfile;
                try
                {
                    keycloakProfile = _mapper.Map<UserKeycloak>(bmHrProfileDTO);
                    var responseKeycloak = _keycloakService.CreateUserOnKeycloak(keycloakProfile).Result;
                    bmHrProfileDTO.IdKeycloak = await _keycloakService.GetIdKeycloak(bmHrProfileDTO.Email);
                    var res = await _keycloakService.SetGroupOnUser(bmHrProfileDTO.IdKeycloak, bmHrProfileDTO.Group.ToString());
                    if (!res) return new Response<BmHrProfileDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = "InternalServerErrorKeycloak", };
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex.Message);
                    return new Response<BmHrProfileDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };
                }
                var id = await _bmhrRepository.Create(_mapper.Map<BmHrProfile>(bmHrProfileDTO));
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("ProfileSuccessfullyCreated") + " - " + id.ToString());
                return new Response<BmHrProfileDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "ProfileSuccessfullyCreated" + " Id: " + id.ToString() };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new Response<BmHrProfileDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };
            }
            
        }
        public async Task<Response<BmHrProfileDTO>> Find(int id)
        {
            try
            {
                if (!(await _bmhrRepository.UserExists(id)))
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("ProfileNotFound"));
                    return new Response<BmHrProfileDTO> { Success = false, StatusCode = HttpStatusCode.NotFound, Message = "ProfileNotFound" };
                }

                var bmHrProfileDTO = await _bmhrRepository.Find(id);
                var userToSend = _mapper.Map<BmHrProfileDTO>(bmHrProfileDTO);
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("ProfileSuccessfullyFound"));
                return new Response<BmHrProfileDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "ProfileSuccessfullyFound", Dto = userToSend };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new Response<BmHrProfileDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };
            }
        }
        public async Task<Response<BmHrProfileDTO>> Find(string email)
        {
            try
            {
                if (!(await _bmhrRepository.UserExists(email)))
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("ProfileNotFound"));
                    return new Response<BmHrProfileDTO> { Success = false, StatusCode = HttpStatusCode.NotFound, Message = "ProfileNotFound" };
                }

                var bmHrProfileDTO = await _bmhrRepository.Find(email);
                var userToSend = _mapper.Map<BmHrProfileDTO>(bmHrProfileDTO);
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("ProfileSuccessfullyFound"));
                return new Response<BmHrProfileDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "ProfileSuccessfullyFound", Dto = userToSend };
            }
            catch (Exception ex)
            {

                _logger.LogError(ex.Message);
                return new Response<BmHrProfileDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };
            }
        }
        public async Task<ListResponse<BmHrProfileDTO>> GetAll()
        {
            try 
            {
                var allBmHrProfile = await _bmhrRepository.GetAll();
                var allBmHrProfileToSend = allBmHrProfile.Select(bmhr => _mapper.Map<BmHrProfileDTO>(bmhr)).ToList();
                if (allBmHrProfileToSend.Count() == 0)
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("ProfileNotFound"));
                    return new ListResponse<BmHrProfileDTO> { Success = false, StatusCode = HttpStatusCode.NotFound, Message = "ProfileNotFound" };
                }
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("ListProfileSuccessfullyFound"));
                return new ListResponse<BmHrProfileDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "ListProfileSuccessfullyFound", DTOs = allBmHrProfileToSend };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new ListResponse<BmHrProfileDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };
            }   
        }
        public async Task<Response<BmHrProfileDTO>> Put(BmHrProfileDTO bmHrProfileDTO)
        {
            try
            {
                if (!await _bmhrRepository.UserExists(bmHrProfileDTO.Id))
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("UpdateProfileBadRequest"));
                    return new Response<BmHrProfileDTO> { Success = false, StatusCode = HttpStatusCode.BadRequest, Message = "UpdateProfileBadRequest" };
                } 
                var userDTOWithId = await _bmhrRepository.Update(_mapper.Map<BmHrProfile>(bmHrProfileDTO));
                var DTOToReturn = _mapper.Map<BmHrProfileDTO>(userDTOWithId);
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("ProfileSuccessfullyUpdated"));
                return new Response<BmHrProfileDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "ProfileSuccessfullyUpdated"};
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new Response<BmHrProfileDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };
            }
        }
        public async Task<Response<BmHrProfileDTO>> Delete(int id)
        {
            try
            {
                var userToFind = await _bmhrRepository.Find(id);
                if (userToFind is null)
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("ProfileNotFound"));
                    return new Response<BmHrProfileDTO>() { Success = false, StatusCode = HttpStatusCode.NotFound, Message = "ProfileNotFound" };
                } 
                var message = await _bmhrRepository.Delete(userToFind);
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("ProfileSuccessfullyDeleted"));
                return new Response<BmHrProfileDTO>() { Success = true, StatusCode = HttpStatusCode.OK , Message = "ProfileSuccessfullyDeleted" };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new Response<BmHrProfileDTO>() { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };
            }
            
        }
        private bool FormatCheckFields(BmHrProfileDTO dtoToCheck)
        {
            if (dtoToCheck.Name.Equals("") || dtoToCheck.Surname.Equals("")
                || dtoToCheck.Email.Equals("") || dtoToCheck.FiscalCode.Equals("")
                || dtoToCheck.City.Equals("") || dtoToCheck.Region.Equals("")
                || dtoToCheck.Province.Equals("") || dtoToCheck.ZipCode.Equals("")
                || dtoToCheck.Address.Equals("") || dtoToCheck.StreetNumber.Equals(""))
            { return false; }
            return true;
        }

        private string GetClaim(string claimType)
        {
            return ((ClaimsIdentity)_httpContextAccessor.HttpContext.User.Identity!).FindFirst(claim => claim.Type == claimType)!.Value;
        }
        private List<string> GetClaimRole(string claimType)
        {
            List<string> rolesList = new List<string>();
            var userRole = ((ClaimsIdentity)_httpContextAccessor.HttpContext.User.Identity!).FindFirst(claim => claim.Type == claimType);
            var content = Newtonsoft.Json.Linq.JObject.Parse(userRole.Value);
            foreach (var role in content["PersHr"]["roles"])
            {
                rolesList.Add(role.ToString());
            }
            return rolesList;
        }
       
        private bool FormatCheckFiscalCode(string fiscalCodeToCheck)
        {
            string strRegex = @"^([A-Z]{6}[0-9LMNPQRSTUV]{2}[ABCDEHLMPRST]{1}[0-9LMNPQRSTUV]{2}[A-Z]{1}[0-9LMNPQRSTUV]{3}[A-Z]{1})$";
            //|([0-9]{11})$";
            Regex strControl = new Regex(strRegex);
            return strControl.IsMatch(fiscalCodeToCheck);
        }
        private string GetToken()
        {
            return _httpContextAccessor.HttpContext.GetTokenAsync("access_token").Result;
        }
    }
}
