﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Pers.BLL.IServices;
using Pers.BLL.Models;
using Pers.DAL.Entities;
using Pers.DAL.IRepositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Reflection.Metadata.Ecma335;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace Pers.BLL.Services
{
    public class ContractProposalService: IContractProposalService
    {
        private readonly ILogger _logger;
        private readonly IStatusDictionaryService _statusDictionaryService;
        private readonly IContractProposalRepository _contractProposalRepository;
        private readonly IMapper _mapper;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly string keycloakId;
        private readonly List<string> roles;
        private readonly int MAX_AGE_HIRED_CONTRACT_PROPOSAL = 35;
        private readonly int MAX_APPRENTICESHIP_AGE_HIRED_CONTRACT_PROPOSAL = 29;
        public ContractProposalService(IContractProposalRepository contractProposalRepository, IMapper mapper, IHttpContextAccessor httpContextAccessor, ILogger<ContractProposalService> logger, IStatusDictionaryService statusDictionaryService ) 
        {
            _logger = logger;
            _statusDictionaryService = statusDictionaryService;
            _contractProposalRepository = contractProposalRepository;
            _mapper = mapper;
            _httpContextAccessor = httpContextAccessor;
            keycloakId = GetClaim(ClaimTypes.NameIdentifier);
            roles = GetClaimRole("resource_access");

        }

        public async Task<Response<ContractProposalDTO>> Create(ContractProposalDTO contractProposalDTO)
        {
            try
            {
                //if (candidate != null && contractProposalDTO.Contract == HiredContractProposal.ContractType.Apprenticeship && (DateTime.Now.Year - candidate.BirthDate.Value.Year) > MAX_APPRENTICESHIP_AGE_HIRED_CONTRACT_PROPOSAL)
                //{
                //    _logger.LogError(_statusDictionaryService.GetDictionaryValue("ContractAgeExceededForContractType"));
                //    return new Response<HiredContractProposalDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = "ContractAgeExceededForContractType" };
                //}
                if (! await FormatControlAsync(contractProposalDTO))
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("ContractProposalHasForeignKeyZeroOrAlreadyCreated"));
                    return new Response<ContractProposalDTO> { Success = true, StatusCode = System.Net.HttpStatusCode.BadRequest, Message = "ContractProposalHasForeignKeyZeroOrAlreadyCreated" };
                     
                }
                var contractToSave = _mapper.Map<ContractProposal>(contractProposalDTO);
                var id = await _contractProposalRepository.Create(contractToSave);
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("ContractProposalSuccessfullyCreated"));
                return new Response<ContractProposalDTO> { Success = true, StatusCode = System.Net.HttpStatusCode.OK, Message = "ContractProposalSuccessfullyCreated" + "Id:" + id };




            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new Response<ContractProposalDTO> { Success = false, StatusCode = System.Net.HttpStatusCode.InternalServerError, Message = ex.Message };
            }
        }
        private async Task<bool> FormatControlAsync(ContractProposalDTO contract) 
        {
           
            if (contract.BmHrId == 0 || contract.HeadOfficeId == 0 || contract.CandidateId == 0 || await _contractProposalRepository.HasAlreadyContract(contract.CandidateId))
            { 
                   return false;
            }

            return true;
        }


        public async Task<Response<bool>> Delete(int id)
        {
            try
            {
                var contractToDelete = await _contractProposalRepository.Find(id);
                if (contractToDelete is null)
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("ContractProposalNotFound"));
                    return new Response<bool> { Success = false, StatusCode = System.Net.HttpStatusCode.NotFound, Message = "ContractProposalNotFound" };
                }
                var response = await _contractProposalRepository.Delete(contractToDelete);
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("ContractProposalSuccesDelete"));
                return new Response<bool> { Success = true, StatusCode = System.Net.HttpStatusCode.OK, Message = "ContractProposalSuccessfullyDelete" };
              
            }
            catch(Exception ex)
            {
                _logger.LogError(ex.Message);
                return new Response<bool> { Success = false, StatusCode = System.Net.HttpStatusCode.InternalServerError, Message = ex.Message };
            }
            
        }

        public async Task<Response<ContractProposalDTO>> Find(int id)
        {
            try
            {
                var contractToFind = await _contractProposalRepository.Find(id);
                if (contractToFind is null)
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("ContractProposalNotFound"));
                    return new Response<ContractProposalDTO> { Success = false, StatusCode = System.Net.HttpStatusCode.NotFound, Message = "ContractProposalNotFound" };
                }
                var contratToSend = _mapper.Map<ContractProposalDTO>(contractToFind);
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("ContractsProposalSuccessfullyFound"));
                return new Response<ContractProposalDTO> { Success = true, StatusCode = System.Net.HttpStatusCode.OK, Dto = contratToSend, Message = "ContractProposalSuccessfullFound" };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new Response<ContractProposalDTO> { Success = false, StatusCode = System.Net.HttpStatusCode.InternalServerError, Message = ex.Message };
            }
        }

        public async Task<ListResponse<ContractProposalDTO>> GetAll()
        {
            try
            {
                var contractProposalList = await _contractProposalRepository.GetAll();
                var allContractProposalToSend = contractProposalList.Select(contract => _mapper.Map<ContractProposalDTO>(contract)).ToList();
                if (contractProposalList.Count == 0)
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("ContractProposalNotFound"));
                    return new ListResponse<ContractProposalDTO> { Success = false, StatusCode = System.Net.HttpStatusCode.NotFound, Message = "ContractProposalNotFound" };
                }

                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("ContractsProposalSuccessfullyFound"));
                return new ListResponse<ContractProposalDTO> { Success = true, StatusCode = System.Net.HttpStatusCode.OK, Message = "ContractsProposalSuccessfullyFound", DTOs = allContractProposalToSend };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new ListResponse<ContractProposalDTO> { Success = false, StatusCode = System.Net.HttpStatusCode.InternalServerError, Message =ex.Message };  
            }
        }

        public async Task<Response<ContractProposalDTO>> Update(ContractProposalDTO contractProposalDTO)
        {
            try 
            {
                if(!await FormatControlAsync(contractProposalDTO))
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("ContractProposalHasForeignKeyZero"));
                    return new Response<ContractProposalDTO> { Success = true, StatusCode = System.Net.HttpStatusCode.BadRequest, Message = "ContractProposalHasForeignKeyZero" };

                }

                //if (candidate != null && hiredContractProposalDTO.Contract == HiredContractProposal.ContractType.Apprenticeship && (DateTime.Now.Year - candidate.BirthDate.Value.Year) > MAX_APPRENTICESHIP_AGE_HIRED_CONTRACT_PROPOSAL)
                //{
                //    _logger.LogError(_statusDictionaryService.GetDictionaryValue("ContractAgeExceededForContractType"));
                //    return new Response<HiredContractProposalDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = "ContractAgeExceededForContractType" };
                //}
                var contractToUpdate = _mapper.Map<ContractProposal>(contractProposalDTO);
                var contractResponse = await _contractProposalRepository.Update(contractToUpdate);
                var contractToSend = _mapper.Map<ContractProposalDTO>(contractResponse);
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("ContractProposalSuccessfullyUpdated"));
                return new Response<ContractProposalDTO> { Success = true, StatusCode = System.Net.HttpStatusCode.OK, Message = "ContractProposalSuccessfullyUpdated" };

            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);   
                return new Response<ContractProposalDTO> { Success = true , StatusCode= System.Net.HttpStatusCode.InternalServerError, Message= ex.Message };

            }
        }

        private string GetClaim(string claimType)
        {
            return ((ClaimsIdentity)_httpContextAccessor.HttpContext.User.Identity!).FindFirst(claim => claim.Type == claimType)!.Value;
        }
        private List<string> GetClaimRole(string claimType)
        {
            List<string> rolesList = new List<string>();
            var userRole = ((ClaimsIdentity)_httpContextAccessor.HttpContext.User.Identity!).FindFirst(claim => claim.Type == claimType);
            var content = Newtonsoft.Json.Linq.JObject.Parse(userRole.Value);
            foreach (var role in content["PersHr"]["roles"])
            {
                rolesList.Add(role.ToString());
            }
            return rolesList;
        }

    }
}
