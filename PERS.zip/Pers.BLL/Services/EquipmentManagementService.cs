﻿using AutoMapper;
using Microsoft.Extensions.Logging;
using Pers.BLL.IServices;
using Pers.BLL.Models;
using Pers.DAL.Entities;
using Pers.DAL.IRepositories;
using Pers.DAL.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Pers.BLL.Services
{
    public class EquipmentManagementService : IEquipmentManagementService
    {
        private readonly IEquipmentManagementRepository _equipmentManagementRepository;
        private readonly ILogger<EquipmentManagementService> _logger;
        private readonly IStatusDictionaryService _statusDictionaryService;
        private readonly IMapper _mapper;

        public EquipmentManagementService(IEquipmentManagementRepository equipmentManagementRepository,ILogger<EquipmentManagementService> logger,IMapper mapper,IStatusDictionaryService statusDictionaryService)
        {
            _equipmentManagementRepository= equipmentManagementRepository;
            _logger= logger;
            _mapper=mapper;
            _statusDictionaryService=statusDictionaryService;
        }
        public async Task<Response<EquipmentManagementDTO>> Create(EquipmentManagementDTO equipmentManagementDTO)
        {

            try
            {
                if (!await _equipmentManagementRepository.DataCheck(equipmentManagementDTO.Date, equipmentManagementDTO.Time))
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("EquipmentManagementNotCreatedForDataCheck"));
                    return new Response<EquipmentManagementDTO> { Success = false, StatusCode = HttpStatusCode.BadRequest, Message = "EquipmentManagementNotCreated" };

                }
                if (equipmentManagementDTO.ContractProposalId == 0)
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("HasForeignKeyZero"));
                    return new Response<EquipmentManagementDTO> { Success = false, StatusCode = HttpStatusCode.BadRequest, Message = "HasForeignKeyZero" };
                }
                if (await _equipmentManagementRepository.ContractAlreadyAssociated(equipmentManagementDTO.ContractProposalId))
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("ContractHasAlreadyAssociatedEquipment"));
                    return new Response<EquipmentManagementDTO> { Success = false, StatusCode = HttpStatusCode.BadRequest, Message = "ContractHasAlreadyAssociatedEquipment" };
                }
                var stageContractId = await _equipmentManagementRepository.Create(_mapper.Map<EquipmentManagement>(equipmentManagementDTO));

                equipmentManagementDTO.Id = stageContractId;

                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("EquipmentManagementSuccessfullyCreated"));
                return new Response<EquipmentManagementDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "EquipmentManagementSuccessfullyCreated" + " con Id: " + stageContractId };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new Response<EquipmentManagementDTO> { Success = false, StatusCode = HttpStatusCode.BadRequest, Message = ex.Message };
            }
        }
        public async Task<Response<EquipmentManagementDTO>> Update(EquipmentManagementDTO equipmentManagementDTO)
        {
            try
            {
                if (!(await _equipmentManagementRepository.EquipmentExists(equipmentManagementDTO.Id)))
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("EquipmentNotFound"));
                    return new Response<EquipmentManagementDTO> { Success = false, StatusCode = HttpStatusCode.NotFound, Message = "EquipmentNotFound" };
                }
                var conditionToControlForEquipment = await _equipmentManagementRepository.ContractAlreadyAssociatedWithIdControl(equipmentManagementDTO.Id,equipmentManagementDTO.ContractProposalId);
                var conditionToControl = await _equipmentManagementRepository.ContractAlreadyAssociated(equipmentManagementDTO.ContractProposalId);
                if (!conditionToControlForEquipment && conditionToControl)
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("ContractHasAlreadyAssociatedEquipment"));
                    return new Response<EquipmentManagementDTO> { Success = false, StatusCode = HttpStatusCode.BadRequest, Message = "ContractHasAlreadyAssociatedEquipment" };
                }
                var equipmentToPut = await _equipmentManagementRepository.Update(_mapper.Map<EquipmentManagement>(equipmentManagementDTO));
                var equipmentToSend = _mapper.Map<EquipmentManagementDTO>(equipmentToPut);
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("EquipmentManagementSuccessfullyUpdated"));
                return new Response<EquipmentManagementDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "EquipmentManagementSuccessfullyUpdated" };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new Response<EquipmentManagementDTO> { Success = false, StatusCode = HttpStatusCode.BadRequest, Message = ex.Message };
            }

        }
        public async Task<Response<EquipmentManagementDTO>> Find(int id)
        {
            try
            {
                var equipmentToFind = _mapper.Map<EquipmentManagementDTO>(await _equipmentManagementRepository.Find(id));
                if (equipmentToFind is null)
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("EquipmentNotFound"));
                    return new Response<EquipmentManagementDTO> { Success = false, StatusCode = HttpStatusCode.NotFound, Message = "EquipmentNotFound"};
                }
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("EquipmentManagementSuccessfullyFound"));
                return new Response<EquipmentManagementDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "EquipmentManagementSuccessfullyFound", Dto = equipmentToFind };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new Response<EquipmentManagementDTO> { Success = false, StatusCode = HttpStatusCode.BadRequest, Message = ex.Message };
            }
        }
        public async Task<ListResponse<EquipmentManagementDTO>> GetAll()
        {
            try
            {
                var allEquipments = await _equipmentManagementRepository.GetAll();
                var allEquipmentsToSend = allEquipments.Select(equipment => _mapper.Map<EquipmentManagementDTO>(equipment)).ToList();
                if (allEquipments.Count() == 0)
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("EquipmentNotFound"));
                    return new ListResponse<EquipmentManagementDTO> { Success = false, StatusCode = HttpStatusCode.NotFound, Message = "EquipmentNotFound" };
                }
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("EquipmentManagementSuccessfullyFound"));
                return new ListResponse<EquipmentManagementDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "EquipmentManagementSuccessfullyFound", DTOs = allEquipmentsToSend };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new ListResponse<EquipmentManagementDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };
            }
        }
        private async Task<bool> ReservationCheck(EquipmentManagementDTO eqDTO)
        {

            return await _equipmentManagementRepository.DataCheck(eqDTO.Date, eqDTO.Time);

        }
        public async Task<Response<EquipmentManagementDTO>> Delete(int id)
        {
            try
            {
                var equipmentToDelete = await _equipmentManagementRepository.Find(id);
                if (equipmentToDelete is null)
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("EquipmentNotFound"));
                    return new Response<EquipmentManagementDTO> { Success = false, StatusCode = HttpStatusCode.NotFound, Message = "EquipmentNotFound" };
                }
                var message = await _equipmentManagementRepository.Delete(equipmentToDelete);
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("EquipmentManagementSuccessfullyDeleted"));
                return new Response<EquipmentManagementDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "EquipmentManagementSuccessfullyDeleted" };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new Response<EquipmentManagementDTO> { Success = false, StatusCode = HttpStatusCode.BadRequest, Message = ex.Message };
            }
        }
    }
}
