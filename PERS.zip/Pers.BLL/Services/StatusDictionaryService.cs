﻿using Pers.BLL.Dictionaries;
using Pers.BLL.IServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.BLL.Services
{
    public class StatusDictionaryService : IStatusDictionaryService
    {
        private StatusDictionaryResponse _statusDictionaryResponse { get; set; }
        public StatusDictionaryService(StatusDictionaryResponse statusDictionaryResponse)
        {
            _statusDictionaryResponse = statusDictionaryResponse;
        }

        public Dictionary<string, string> GetDictionary(string language)
        {
                return _statusDictionaryResponse.StatusDictionary;
        }
        public string GetDictionaryValue(string key) => _statusDictionaryResponse.GetValueByKey(key);
    }
}
