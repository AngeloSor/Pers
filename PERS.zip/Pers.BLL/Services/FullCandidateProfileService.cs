﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Pers.BLL.IServices;
using Pers.BLL.Models;
using Pers.DAL.Entities;
using Pers.DAL.IRepositories;
using Pers.DAL.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Pers.BLL.Services
{
    public class FullCandidateProfileService : IFullCandidateProfileService
    {
        private readonly ILogger<FullCandidateProfileService> _logger;
        private readonly IStatusDictionaryService _statusDictionaryService;
        private readonly ICandidateProfileRepository _candidateProfileRepository;
        private readonly IMapper _mapper;
        private readonly string _keycloakId;
        private readonly List<string> _roles;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public FullCandidateProfileService(ICandidateProfileRepository candidateProfileRepository, IMapper mapper, IHttpContextAccessor httpContextAccessor, ILogger<FullCandidateProfileService> logger, IStatusDictionaryService statusDictionaryService)
        {
            _logger = logger;
            _statusDictionaryService = statusDictionaryService;
            _candidateProfileRepository = candidateProfileRepository;
            _mapper = mapper;
            _httpContextAccessor = httpContextAccessor;
            _keycloakId = GetClaim(ClaimTypes.NameIdentifier);
            _roles = GetClaimRole("resource_access");
        }


        public async Task<Response<FullCandidateProfileDTO>> Find(int id)
        {
            try
            {
                var candidateToFind = _mapper.Map<FullCandidateProfileDTO>(await _candidateProfileRepository.Find(id));
                if (candidateToFind is null)
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("ProfileNotFound"));
                    return new Response<FullCandidateProfileDTO> { Success = false, StatusCode = HttpStatusCode.NotFound, Message = "ProfileNotFound", Dto = candidateToFind };
                }
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("ProfileSuccessfullyFound"));
                return new Response<FullCandidateProfileDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "ProfileSuccessfullyFound", Dto = candidateToFind };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new Response<FullCandidateProfileDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };
            }

        }

        public async Task<ListResponse<FullCandidateProfileDTO>> GetAll()
        {
            try
            {
                var allCandidate = await _candidateProfileRepository.GetAll();
                var allCandidateToSend = allCandidate.Select(candidate => _mapper.Map<FullCandidateProfileDTO>(candidate)).ToList();
                if (allCandidate.Count() == 0)
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("ProfileNotFound"));
                    return new ListResponse<FullCandidateProfileDTO> { Success = false, StatusCode = HttpStatusCode.NotFound, Message = "ProfileNotFound" };
                }
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("ProfileSuccessfullyFound"));
                return new ListResponse<FullCandidateProfileDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "ProfileSuccessfullyFound", DTOs = allCandidateToSend };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new ListResponse<FullCandidateProfileDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };

            }

        }
        public async Task<Response<FullCandidateProfileDTO>> Put(FullCandidateProfileDTO candidateProfileDTO)
        {
            try
            {

                if (!FormatCheckFields(candidateProfileDTO) || !FKCheck(candidateProfileDTO))
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("BadRequestFormatCheckFields"));
                    return new Response<FullCandidateProfileDTO> { Success = false, StatusCode = HttpStatusCode.BadRequest, Message = "BadRequestFormatCheckFields" };
                }

                if (!(await _candidateProfileRepository.CandidateExists(candidateProfileDTO.Id)))
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("ProfileNotFound"));
                    return new Response<FullCandidateProfileDTO> { Success = false, StatusCode = HttpStatusCode.NotFound, Message = "ProfileNotFound" };
                }
                var candidateDTOWithId = await _candidateProfileRepository.Update(_mapper.Map<CandidateProfile>(candidateProfileDTO));
                var DTOToReturn = _mapper.Map<FullCandidateProfileDTO>(candidateDTOWithId);
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("ProfileSuccessfullyFound"));
                return new Response<FullCandidateProfileDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "ProfileSuccessfullyUpdated" };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new Response<FullCandidateProfileDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };
            }

        }

        public async Task<Response<FullCandidateProfileDTO>> Delete(int id)
        {
            try
            {
                var candidateToDelete = await _candidateProfileRepository.Find(id);
                if (candidateToDelete is null)
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("ProfileNotFound"));
                    return new Response<FullCandidateProfileDTO>() { Success = false, StatusCode = HttpStatusCode.NotFound, Message = "ProfileNotFound" };
                }
                var message = await _candidateProfileRepository.Delete(candidateToDelete);
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("ProfileSuccessfullyDeleted"));
                return new Response<FullCandidateProfileDTO>() { Success = true, StatusCode = HttpStatusCode.OK, Message = "ProfileSuccessfullyDeleted" };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new Response<FullCandidateProfileDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };
            }
        }

        private string GetClaim(string claimType)
        {
            return ((ClaimsIdentity)_httpContextAccessor.HttpContext.User.Identity!).FindFirst(claim => claim.Type == claimType)!.Value;
        }
        private List<string> GetClaimRole(string claimType)
        {
            List<string> rolesList = new List<string>();
            var userRole = ((ClaimsIdentity)_httpContextAccessor.HttpContext.User.Identity!).FindFirst(claim => claim.Type == claimType);
            var content = Newtonsoft.Json.Linq.JObject.Parse(userRole.Value);
            foreach (var role in content["PersHr"]["roles"])
            {
                rolesList.Add(role.ToString());
            }
            return rolesList;
        }
        private bool FormatCheckFields(FullCandidateProfileDTO dtoToCheck)
        {
            if (dtoToCheck.Name.Equals("") || dtoToCheck.Surname.Equals("")
                || dtoToCheck.Email.Equals("") || dtoToCheck.PhoneNumber.Equals(""))
                return false;
            return true;
        }
        private bool FKCheck(FullCandidateProfileDTO fullCandidateProfileDTO)
        { 
            if(fullCandidateProfileDTO.BmHrId == 0 || fullCandidateProfileDTO.BmHrId is null)
                return false;
            return true;
        }
    }
}
