﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using Pers.BLL.IServices;
using Pers.BLL.Models;
using Pers.DAL.Entities;
using Pers.DAL.IRepositories;
using Pers.DAL.Repositories;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Pers.BLL.Services
{
	public class CandidateProfileService :ICandidateProfileService
	{
		private readonly ILogger<CandidateProfileService> _logger;
		private readonly ICandidateProfileRepository _candidateProfileRepository;
		private readonly IMapper _mapper;
		private readonly IStatusDictionaryService _statusDictionaryService;
		private readonly string keycloakId;
		private readonly List<string> roles;
		private readonly IHttpContextAccessor _httpContextAccessor;

		public CandidateProfileService(ICandidateProfileRepository candidateProfileRepository, IMapper mapper, IHttpContextAccessor httpContextAccessor, ILogger<CandidateProfileService> logger,IStatusDictionaryService statusDictionaryService)
		{
			_candidateProfileRepository = candidateProfileRepository;
			_mapper = mapper;
		    _httpContextAccessor = httpContextAccessor;
			_logger = logger;
			_statusDictionaryService = statusDictionaryService;
			//keycloakId = GetClaim(ClaimTypes.NameIdentifier);
			//roles = GetClaimRole("resource_access");
		}

		public async Task<Response<CandidateProfileDTO>> Create(CandidateProfileDTO candidateProfileDTO)
		{
			try
			{
                if (candidateProfileDTO.BmHrId == 0)
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("HasForeignKeyZero"));
                    return new Response<CandidateProfileDTO> { Success = true, StatusCode = HttpStatusCode.BadRequest, Message = "HasForeignKeyZero" };
                }
                if (!FormatCheckFields(candidateProfileDTO))
				{
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("BadRequestFormatCheckFields"));
                    return new Response<CandidateProfileDTO> { Success = false, StatusCode = HttpStatusCode.BadRequest, Message = "BadRequestFormatCheckFields" };
				}
					
				if (await _candidateProfileRepository.CandidateExists(candidateProfileDTO.Email))
				{
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("BadRequestCandidateEmailAlreadyExist"));
                    return new Response<CandidateProfileDTO> { Success = false, StatusCode = HttpStatusCode.BadRequest, Message = "BadRequestCandidateEmailAlreadyExist" };
				}
					
				candidateProfileDTO.StateForm = CandidateProfileDTO.FormType.NotSend;
				var id = await _candidateProfileRepository.Create(_mapper.Map<CandidateProfile>(candidateProfileDTO));
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("ProfileSuccessfullyCreated") + " - " + id.ToString());
                return new Response<CandidateProfileDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "ProfileSuccessfullyCreated" + " Id: " + id.ToString() };
			}
			catch (Exception ex)
			{
                _logger.LogError(ex.Message);
                return new Response<CandidateProfileDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };
			}

		}
        public async Task<Response<CandidateProfileDTO>> Find(int id)
		{
			try
			{
				//TODO: confronto corpo metodo Find in BmHrProfileService
				var candidateToFind = _mapper.Map<CandidateProfileDTO>(await _candidateProfileRepository.Find(id));
				if (candidateToFind is null)
				{
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("ProfileNotFound"));
                    return new Response<CandidateProfileDTO> { Success = false, StatusCode = HttpStatusCode.NotFound, Message = "ProfileNotFound", Dto = candidateToFind };
				}
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("ProfileSuccessfullyFound"));
                return new Response<CandidateProfileDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "ProfileSuccessfullyFound", Dto = candidateToFind };
			}
			catch (Exception ex)
			{
                _logger.LogError(ex.Message);
                return new Response<CandidateProfileDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };
            }
			
        }
		public async Task<Response<CandidateProfileDTO>> SetFormToSend(int id)
		{
			try
			{
				var candidateToFind = await _candidateProfileRepository.Find(id);
				if (candidateToFind is null)
				{
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("ProfileNotFound"));
                    return new Response<CandidateProfileDTO> { Success = false, StatusCode = HttpStatusCode.NotFound, Message = "ProfileNotFound" };
				} 
				var IsCandidateSet = await _candidateProfileRepository.SetFormToSend(candidateToFind);
				if (!IsCandidateSet)
				{
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("CandidateNotSaved"));
                    return new Response<CandidateProfileDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = "CandidateNotSaved" };
				}
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("CandidateSuccessfullySet"));
                return new Response<CandidateProfileDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "CandidateSuccessfullySet" };
			}
			catch (Exception ex)
			{
                _logger.LogError(ex.Message);
                return new Response<CandidateProfileDTO> { Success = true, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };
			}
		}
        public async Task<Response<CandidateProfileDTO>> SetFormToCompiled(int id)
        {
            try
            {
                var candidateToFind = await _candidateProfileRepository.Find(id);
				if (candidateToFind is null)
				{
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("ProfileNotFound"));
                    return new Response<CandidateProfileDTO> { Success = false, StatusCode = HttpStatusCode.NotFound, Message = "ProfileNotFound" };
				} 
                var IsCandidateSet = await _candidateProfileRepository.SetFormToCompiled(candidateToFind);
				if (!IsCandidateSet)
				{
					_logger.LogError(_statusDictionaryService.GetDictionaryValue("CandidateNotSaved"));
                    return new Response<CandidateProfileDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = "CandidateNotSaved" };
				}
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("CandidateSuccessfullySet"));
                return new Response<CandidateProfileDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "CandidateSuccessfullySet" };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new Response<CandidateProfileDTO> { Success = true, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };

            }
        }
        public async Task<ListResponse<CandidateProfileDTO>> GetAll()
		{
            try
            {
                var allCandidate = await _candidateProfileRepository.GetAll();
                var allCandidateToSend = allCandidate.Select(candidate => _mapper.Map<CandidateProfileDTO>(candidate)).ToList();
				if (allCandidateToSend.Count() == 0)
				{
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("ProfileNotFound"));
                    return new ListResponse<CandidateProfileDTO> { Success = false, StatusCode = HttpStatusCode.NotFound, Message = "ProfileNotFound" };
				}
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("ListProfileSuccessfullyFound"));
                return new ListResponse<CandidateProfileDTO> {Success = true, StatusCode = HttpStatusCode.OK, Message = "ListProfileSuccessfullyFound", DTOs = allCandidateToSend };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new ListResponse<CandidateProfileDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };
            }
   
		}
		public async Task<ListResponse<CandidateProfileDTO>> GetAllCandidateBm(int bmId)
		{
			try
			{
				var candidateToFind = await _candidateProfileRepository.GetCandidateBM(bmId);
				var candidateToSend = candidateToFind.Select(candidate => _mapper.Map<CandidateProfileDTO>(candidate)).ToList();
				if (candidateToSend.Count() == 0)
				{
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("ProfileNotFound"));
                    return new ListResponse<CandidateProfileDTO> { Success = false, StatusCode = HttpStatusCode.NotFound, Message = "ProfileNotFound" };
                }
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("ListProfileSuccessfullyFound"));
                return new ListResponse<CandidateProfileDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "ListProfileSuccessfullyFound", DTOs = candidateToSend };
			}
			catch (Exception ex)
			{
                _logger.LogError(ex.Message);
                return new ListResponse<CandidateProfileDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };
			}
		}
		public async Task<ListResponse<CandidateProfileDTO>> GetAllCandidateWithAcceptedForm()
		{
			try
			{
                var candidateToFind = await _candidateProfileRepository.GetCandidateWithAcceptedForm();
                var candidateToSend = candidateToFind.Select(candidate => _mapper.Map<CandidateProfileDTO>(candidate)).ToList();
				if (candidateToSend.Count() == 0)
				{
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("ProfileNotFound"));
                    return new ListResponse<CandidateProfileDTO> { Success = false, StatusCode = HttpStatusCode.NotFound, Message = "ProfileNotFound" };
                }
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("ListProfileSuccessfullyFound"));
                return new ListResponse<CandidateProfileDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "ListProfileSuccessfullyFound", DTOs = candidateToSend };
            }
			catch (Exception ex)
			{
                _logger.LogError(ex.Message);
                return new ListResponse<CandidateProfileDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };
			}
		}
		public async Task<Response<CandidateProfileDTO>> Put(CandidateProfileDTO candidateProfileDTO)
		{
			try
			{
				if (!(await _candidateProfileRepository.CandidateExists(candidateProfileDTO.Id)))
				{
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("ProfileNotFound"));
                    return new Response<CandidateProfileDTO> { Success = false, StatusCode = HttpStatusCode.NotFound, Message = "ProfileNotFound" };
				} 
                var candidateDTOWithId = await _candidateProfileRepository.Update(_mapper.Map<CandidateProfile>(candidateProfileDTO));
                var DTOToReturn = _mapper.Map<CandidateProfileDTO>(candidateDTOWithId);
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("ProfileSuccessfullyUpdated"));
                return new Response<CandidateProfileDTO> { Success = true, StatusCode = HttpStatusCode.OK , Message = "ProfileSuccessfullyUpdated" };
			}
			catch (Exception ex)
			{
                _logger.LogError(ex.Message);
                return new Response<CandidateProfileDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message};
			}

		}
        public async Task<Response<CandidateProfileDTO>> SetCareer(int id)
        {
            try
            {
                var candidateToFind = await _candidateProfileRepository.Find(id);
                if (candidateToFind is null)
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("ProfileNotFound"));
                    return new Response<CandidateProfileDTO> { Success = false, StatusCode = HttpStatusCode.NotFound, Message = "ProfileNotFound" };
                }
                var IsCandidateSet = await _candidateProfileRepository.SetCareer(candidateToFind);
                if (!IsCandidateSet)
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("CandidateNotSaved"));
                    return new Response<CandidateProfileDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = "CandidateNotSaved" };
                }
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("CandidateSuccessfullySet"));
                return new Response<CandidateProfileDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "CandidateSuccessfullySet" };

            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new Response<CandidateProfileDTO> { Success = true, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };

            }
        }
  //      private string GetClaim(string claimType)
		//{
		//	return ((ClaimsIdentity)_httpContextAccessor.HttpContext.User.Identity!).FindFirst(claim => claim.Type == claimType)!.Value;
		//}
		//private List<string> GetClaimRole(string claimType)
		//{
		//	List<string> rolesList = new List<string>();
		//	var userRole = ((ClaimsIdentity)_httpContextAccessor.HttpContext.User.Identity!).FindFirst(claim => claim.Type == claimType);
		//	var content = Newtonsoft.Json.Linq.JObject.Parse(userRole.Value);
		//	foreach (var role in content["PersHr"]["roles"])
		//	{
		//		rolesList.Add(role.ToString());
		//	}
		//	return rolesList;
		//}
        private bool FormatCheckFields(CandidateProfileDTO dtoToCheck)
        {
			if (dtoToCheck.Name.Equals("") || dtoToCheck.Surname.Equals("")
				|| dtoToCheck.Email.Equals("") || dtoToCheck.PhoneNumber.Equals(""))
				return false;
            return true;
        }
    }
}
