﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Pers.BLL.IServices;
using Pers.BLL.Models;
using Pers.DAL.IRepositories;
using Pers.DAL.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace Pers.BLL.Services
{
   
    public class LevelService : ILevelService
    {
        private readonly ILogger<LevelService> _logger;
        private readonly ILevelRepository _levelRepository;
        private readonly IStatusDictionaryService _statusDictionaryService;
        private readonly IMapper _mapper;
        private readonly string keycloakId;
        private readonly List<string> roles;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public LevelService(ILogger<LevelService> logger, ILevelRepository levelRepository, IMapper mapper,IHttpContextAccessor httpContextAccessor, IStatusDictionaryService statusDictionaryService)
        {
            _levelRepository= levelRepository;
            _mapper= mapper;
            _httpContextAccessor= httpContextAccessor;
            _logger = logger;
            _statusDictionaryService= statusDictionaryService;
            keycloakId = GetClaim(ClaimTypes.NameIdentifier);
            roles = GetClaimRole("resource_access");
        }
        public Task<Response<LevelDTO>> Create(LevelDTO levelDTO)
        {
            throw new NotImplementedException();
        }

        public Task<Response<LevelDTO>> Delete(int id)
        {
            throw new NotImplementedException();
        }

        public async Task<Response<LevelDTO>> Find(int id)
        {
            try
            {
                var level = await _levelRepository.Find(id);
                if (level is null)
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("LevelNotFound"));
                    return new Response<LevelDTO> { Success = false, StatusCode = HttpStatusCode.NotFound, Message = "LevelNotFound" };

                }
                var levelToSend = _mapper.Map<LevelDTO>(level);
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("LevelSuccessfullyFound"));
                return new Response<LevelDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "LevelSuccessfullyFound", Dto = levelToSend };


            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new Response<LevelDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };

            }
        }

        public async Task<ListResponse<LevelDTO>> GetAll()
        {
            try
            {
                var allLevel = await _levelRepository.GetAll();
                var allLevelToSend = allLevel.Select(level => _mapper.Map<LevelDTO>(level)).ToList();
                
                if(allLevelToSend.Count() == 0)
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("LevelNotFound"));
                    return new ListResponse<LevelDTO> { Success = false, StatusCode = HttpStatusCode.NotFound, Message = "LevelNotFound" };
                }
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("LevelsSuccessfullyFound"));
                return new ListResponse<LevelDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "LevelsSuccessfullyFound", DTOs = allLevelToSend};
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new ListResponse<LevelDTO> {Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message};
            }
        }

        public Task<Response<LevelDTO>> Put(LevelDTO levelDTO)
        {
            throw new NotImplementedException();
        }
        private string GetClaim(string claimType)
        {
            return ((ClaimsIdentity)_httpContextAccessor.HttpContext.User.Identity!).FindFirst(claim => claim.Type == claimType)!.Value;
        }
        private List<string> GetClaimRole(string claimType)
        {
            List<string> rolesList = new List<string>();
            var userRole = ((ClaimsIdentity)_httpContextAccessor.HttpContext.User.Identity!).FindFirst(claim => claim.Type == claimType);
            var content = Newtonsoft.Json.Linq.JObject.Parse(userRole.Value);
            foreach (var role in content["PersHr"]["roles"])
            {
                rolesList.Add(role.ToString());
            }
            return rolesList;
        }
    }
}
