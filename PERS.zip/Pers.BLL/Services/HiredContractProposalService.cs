﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Pers.BLL.IServices;
using Pers.BLL.Models;
using Pers.DAL.Entities;
using Pers.DAL.IRepositories;
using Pers.DAL.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Runtime.CompilerServices;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace Pers.BLL.Services
{
    public class HiredContractProposalService : IHiredContractProposalService
    {
        private readonly ILogger<HiredContractProposalService> _logger;
        private readonly IStatusDictionaryService _statusDictionaryService;
        private readonly IHiredContractProposalRepository _hiredContractProposalRepository;
        private readonly IMapper _mapper;
        private readonly string keycloakId;
        private readonly List<string> roles;
        private readonly IPowerAutomateService _powerAutomateService;
        private readonly IHttpContextAccessor _httpContextAccessor;

		public HiredContractProposalService(IHiredContractProposalRepository hiredContractProposalRepository, IMapper mapper, IHttpContextAccessor httpContextAccessor, IPowerAutomateService powerAutomateService, ILogger<HiredContractProposalService> logger,IStatusDictionaryService statusDictionaryService)
        {
            _logger = logger;
            _hiredContractProposalRepository = hiredContractProposalRepository;
            _mapper = mapper;
            _httpContextAccessor = httpContextAccessor;
            keycloakId = GetClaim(ClaimTypes.NameIdentifier);
            roles = GetClaimRole("resource_access");
            _powerAutomateService = powerAutomateService;
            _statusDictionaryService = statusDictionaryService;

        }

        public async Task<Response<HiredContractProposalDTO>> Create(HiredContractProposalDTO hiredContractProposalDTO)
        {
            try
            {
                if (hiredContractProposalDTO.ContractProposalId == 0 || hiredContractProposalDTO.LevelId==0)
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("HasForeignKeyZero"));
                    return new Response<HiredContractProposalDTO> { Success = false, StatusCode = HttpStatusCode.BadRequest, Message = "HasForeignKeyZero" };
                }
                if (await _hiredContractProposalRepository.ContractAlreadyAssociated(hiredContractProposalDTO.ContractProposalId))
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("ContractHasAlreadyAssociatedEquipment"));
                    return new Response<HiredContractProposalDTO> { Success = false, StatusCode = HttpStatusCode.BadRequest, Message = "ContractHasAlreadyAssociatedEquipment" };
                }
                var hiredContractId = await _hiredContractProposalRepository.Create(_mapper.Map<HiredContractProposal>(hiredContractProposalDTO));
				
					hiredContractProposalDTO.Id = hiredContractId;
					var response = _powerAutomateService.SendApprovalHiredContractProposal(hiredContractProposalDTO);
				
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("HiredContractProposalSuccessfullyCreated"));
                return new Response<HiredContractProposalDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "HiredContractProposalSuccessfullyCreated" };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new Response<HiredContractProposalDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };
            }
        }
        public async Task<Response<HiredContractProposalDTO>> Find(int id)
        {
            try
            {
                var contractToFind = _mapper.Map<HiredContractProposalDTO>(await _hiredContractProposalRepository.Find(id));
                if (contractToFind is null)
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("HiredContractProposalNotFound"));
                    return new Response<HiredContractProposalDTO> { Success = false, StatusCode = HttpStatusCode.NotFound, Message = "HiredContractProposalNotFound", Dto = contractToFind };
                }
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("HiredContractProposalSuccessfullyFound"));
                return new Response<HiredContractProposalDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "HiredContractProposalSuccessfullyFound", Dto = contractToFind };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new Response<HiredContractProposalDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };
            }
        }
        public async Task<ListResponse<HiredContractProposalDTO>> GetAll()
        {
            try
            {
                var allHiredContract = await _hiredContractProposalRepository.GetAll();
                var allHiredContractDTO = allHiredContract.Select(contract => _mapper.Map<HiredContractProposalDTO>(contract)).ToList();
                if (allHiredContract.Count() == 0)
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("HiredContractProposalNotFound"));
                    return new ListResponse<HiredContractProposalDTO> { Success = false, StatusCode = HttpStatusCode.NotFound, Message = "HiredContractProposalNotFound" };
                }
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("HiredContractProposalSuccessfullyFound"));
                return new ListResponse<HiredContractProposalDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "HiredContractProposalSuccessfullyFound", DTOs = allHiredContractDTO };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new ListResponse<HiredContractProposalDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };

            }
        }

        public async Task<Response<HiredContractProposalDTO>> Put(HiredContractProposalDTO hiredContractDTO)
        {
            try
            {
                if (!(await _hiredContractProposalRepository.ContractExist(hiredContractDTO.Id)))
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("HiredContractProposalNotFound"));
                    return new Response<HiredContractProposalDTO> { Success = false, StatusCode = HttpStatusCode.NotFound, Message = "HiredContractProposalNotFound" };
                }
                if (hiredContractDTO.ContractProposalId == 0 || hiredContractDTO.LevelId == 0)
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("HasForeignKeyZero"));
                    return new Response<HiredContractProposalDTO> { Success = false, StatusCode = HttpStatusCode.BadRequest, Message = "HasForeignKeyZero" };
                }
                var conditionToControlForHired = await _hiredContractProposalRepository.ContractAlreadyAssociatedWithIdControl(hiredContractDTO.Id, hiredContractDTO.ContractProposalId);
                var conditionToControl = await _hiredContractProposalRepository.ContractAlreadyAssociated(hiredContractDTO.ContractProposalId);
                if (!conditionToControlForHired && conditionToControl)
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("ContractHasAlreadyAssociatedEquipment"));
                    return new Response<HiredContractProposalDTO> { Success = false, StatusCode = HttpStatusCode.BadRequest, Message = "ContractHasAlreadyAssociatedEquipment" };
                }
                var hireContractToPut = await _hiredContractProposalRepository.Update(_mapper.Map<HiredContractProposal>(hiredContractDTO));
                var hireContractToSend = _mapper.Map<HiredContractProposalDTO>(hireContractToPut);
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("HiredContractProposalSuccessfullyUpdated"));
                return new Response<HiredContractProposalDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "HiredContractProposalSuccessfullyUpdated" };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new Response<HiredContractProposalDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };
            }
        }

        public async Task<Response<HiredContractProposalDTO>> Delete(int id)
        {
            try
            {
                var contractToDelete = await _hiredContractProposalRepository.Find(id);
                if (contractToDelete is null)
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("HiredContractProposalNotFound"));
                    return new Response<HiredContractProposalDTO> { Success = false, StatusCode = System.Net.HttpStatusCode.NotFound, Message = "HiredContractProposalNotFound" };
                }
                var message = await _hiredContractProposalRepository.Delete(contractToDelete);
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("HiredContractProposalSuccessfullyDelete"));
                return new Response<HiredContractProposalDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "HiredContractProposalSuccessfullyDelete" };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new Response<HiredContractProposalDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };
            }
        }

        private string GetClaim(string claimType)
        {
            return ((ClaimsIdentity)_httpContextAccessor.HttpContext.User.Identity!).FindFirst(claim => claim.Type == claimType)!.Value;
        }
        private List<string> GetClaimRole(string claimType)
        {
            List<string> rolesList = new List<string>();
            var userRole = ((ClaimsIdentity)_httpContextAccessor.HttpContext.User.Identity!).FindFirst(claim => claim.Type == claimType);
            var content = Newtonsoft.Json.Linq.JObject.Parse(userRole.Value);
            foreach (var role in content["PersHr"]["roles"])
            {
                rolesList.Add(role.ToString());
            }
            return rolesList;
        }
    }
}


