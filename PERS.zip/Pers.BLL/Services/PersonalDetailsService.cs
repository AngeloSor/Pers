﻿using AutoMapper;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Mvc;
using Pers.BLL.IServices;
using Pers.BLL.Models;
using Pers.DAL.Entities;
using Pers.DAL.IRepositories;
using Microsoft.AspNetCore.Http;
using Pers.DAL.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http.Headers;
using Microsoft.Extensions.Configuration;
using System.Buffers.Text;
using System.Text.RegularExpressions;

namespace Pers.BLL.Services
{
    public class PersonalDetailsService : IPersonalDetailsService
    {
        private readonly IPersonalDetailsRepository _personalDetailsRepository;
        private readonly ICandidateProfileRepository _candidateProfileRepository;
        private readonly ICandidateFileRepository _candidateFileRepository;
        private readonly IMapper _mapper;
        private readonly IStatusDictionaryService _statusDictionaryService;
        private readonly ILogger<PersonalDetailsService> _logger;
        private readonly IAzureBlobService _azureBlobService;
        public PersonalDetailsService(IMapper mapper, IStatusDictionaryService statusDictionaryService, ILogger<PersonalDetailsService> logger,IPersonalDetailsRepository personalDetailsRepository, ICandidateProfileRepository candidateProfileRepository, ICandidateFileRepository candidateFileRepository, IAzureBlobService azureBlobService)
        {
            _mapper = mapper;
            _statusDictionaryService = statusDictionaryService;
            _logger = logger;
            _personalDetailsRepository = personalDetailsRepository;
            _candidateProfileRepository = candidateProfileRepository;
            _candidateFileRepository = candidateFileRepository;
            _azureBlobService = azureBlobService;
        }

        public async Task<Response<PersonalDetailsDTO>> Create(PersonalDetailsDTO personalDetailsDTO)
        {
            try
            {
                
                    if (!(await _candidateProfileRepository.CandidateExists(personalDetailsDTO.CandidateProfileId)))
                    {
                        _logger.LogError(_statusDictionaryService.GetDictionaryValue("ProfileNotFound"));
                        return new Response<PersonalDetailsDTO> { Success = false, StatusCode = HttpStatusCode.NotFound, Message = "ProfileNotFound" };
                    }
                    else if ((await _personalDetailsRepository.CandidateAssociatedExists(personalDetailsDTO.CandidateProfileId)))
                    {
                       _logger.LogError(_statusDictionaryService.GetDictionaryValue("PersonalDetailsCandidateBadRequest"));
                       return new Response<PersonalDetailsDTO> { Success = false, StatusCode = HttpStatusCode.BadRequest, Message = "PersonalDetailsCandidateBadRequest" };
                    }
                //if (!await _azureBlobService.UploadBlob(personalDetailsDTO.FileId.FileData) || !await _azureBlobService.UploadBlob(personalDetailsDTO.FileCf.FileData))
                //{
                //    _logger.LogError(_statusDictionaryService.GetDictionaryValue("FileNotUploaded"));
                //    return new Response<PersonalDetailsDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = "FileNotUploaded" };
                //}

                    if (!FormatCheck(personalDetailsDTO)) return new Response<PersonalDetailsDTO> { Success = false, StatusCode = HttpStatusCode.BadRequest, Message = "PersonalDetailsFormatFieldCheckFailed" };
                    var id = await _personalDetailsRepository.Create(_mapper.Map<PersonalDetails>(personalDetailsDTO));
                    var candidate = await _candidateProfileRepository.Find(personalDetailsDTO.CandidateProfileId);
                    var IsStateFormSet = await _candidateProfileRepository.SetFormToCompiled(candidate);
                    if (!IsStateFormSet) return new Response<PersonalDetailsDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = "ErrorSetStatusForm" };
                    _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("PersonalDetailsSuccessfullyCreated") + " con id: " + id.ToString());
                    return new Response<PersonalDetailsDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "PersonalDetailsSuccessfullyCreated" + " Id: " + id.ToString() };
                
                
            }
            catch(Exception ex)
            {
                _logger.LogError(ex.Message);
                return new Response<PersonalDetailsDTO> { Success = false, StatusCode = HttpStatusCode.BadRequest, Message = ex.Message };
            }

        }
        private bool FormatCheck(PersonalDetailsDTO personalDetailsDTO) 
        {
            string strRegex = @"^([A-Z]{6}[0-9LMNPQRSTUV]{2}[ABCDEHLMPRST]{1}[0-9LMNPQRSTUV]{2}[A-Z]{1}[0-9LMNPQRSTUV]{3}[A-Z]{1})$";
            Regex strControl = new Regex(strRegex);
            
            if (personalDetailsDTO is null) return false;
            if(personalDetailsDTO.Surname is null || personalDetailsDTO.Name is null || personalDetailsDTO.BirthPlace is null || personalDetailsDTO.ResidenceAddress is null || personalDetailsDTO.DomicileAddress is null || personalDetailsDTO.DomicileCity is null || personalDetailsDTO.FiscalCode is null || personalDetailsDTO.Institute is null || personalDetailsDTO.ResidenceAddress is null || personalDetailsDTO.ResidenceZIPCode == 0|| personalDetailsDTO.DomicileZIPCode == 0 || personalDetailsDTO.Telephone == 0 || personalDetailsDTO.Vote is null || personalDetailsDTO.CandidateProfileId == 0) return false;
            if(!strControl.IsMatch(personalDetailsDTO.FiscalCode)) return false;
            return true;
        }
        //public async Task<Response<bool>> UploadFile(IFormFile file)
        //{
            
            
        //    if (!await _azureBlobService.UploadBlob(file))
        //    {
        //        _logger.LogError(_statusDictionaryService.GetDictionaryValue("FileNotUploaded"));
        //        return new Response<bool> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = "FileNotUploaded" };
        //    }
        //    return new Response<bool> { Success = false, StatusCode = HttpStatusCode.OK, Message = "FileUploaded" };

        //}
        public async Task<Response<PersonalDetailsDTO>> Find(int id)
        {
            try
            {
                if (!(await _personalDetailsRepository.DetailsExists(id)))
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("PersonalDetailsNotFound"));
                    return new Response<PersonalDetailsDTO> { Success = false, StatusCode = HttpStatusCode.NotFound, Message = "PersonalDetailsNotFound" };
                }

                var bmHrProfileDTO = await _personalDetailsRepository.Find(id);
                var userToSend = _mapper.Map<PersonalDetailsDTO>(bmHrProfileDTO);
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("PersonalDetailsSuccessfullyFound"));
                return new Response<PersonalDetailsDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "PersonalDetailsSuccessfullyFound", Dto = userToSend };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new Response<PersonalDetailsDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };
            }
        }

        public async Task<Response<PersonalDetailsDTO>> FindDetailsForSpecificCandidate(int candidateId)
        {
            try
            {
                var bmHrProfileDTO = await _personalDetailsRepository.FindByCandidate(candidateId);
                if(bmHrProfileDTO == null)
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("ProfileNotFound"));
                    return new Response<PersonalDetailsDTO> { Success = false, StatusCode = HttpStatusCode.NotFound, Message = "ProfileNotFound" };
                }

                var userToSend = _mapper.Map<PersonalDetailsDTO>(bmHrProfileDTO);
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("PersonalDetailsSuccessfullyFound"));
                return new Response<PersonalDetailsDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "PersonalDetailsSuccessfullyFound", Dto = userToSend };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new Response<PersonalDetailsDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };
            }
        }

        public async Task<Response<PersonalDetailsDTO>> Put(PersonalDetailsDTO personalDetailsDTO)
        {
            try
            {
                if (!(await _personalDetailsRepository.DetailsExists(personalDetailsDTO.Id)))
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("PersonalDetailsNotFound"));
                    return new Response<PersonalDetailsDTO> { Success = false, StatusCode = HttpStatusCode.NotFound, Message = "PersonalDetailsNotFound" };
                }else if (!(await _candidateProfileRepository.CandidateExists(personalDetailsDTO.CandidateProfileId)))
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("ProfileNotFound"));
                    return new Response<PersonalDetailsDTO> { Success = false, StatusCode = HttpStatusCode.BadRequest, Message = "ProfileNotFound" };
                }
                var detailsDTO = await _personalDetailsRepository.Update(_mapper.Map<PersonalDetails>(personalDetailsDTO));
                var DTOToReturn = _mapper.Map<PersonalDetailsDTO>(detailsDTO);
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("PersonalDetailsSuccessfullyUpdated"));
                return new Response<PersonalDetailsDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "PersonalDetailsSuccessfullyUpdated" };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new Response<PersonalDetailsDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };
            }
        }

        public async Task<Response<PersonalDetailsDTO>> Delete(int id)
        {
            try
            {
                var detailsToDelete = await _personalDetailsRepository.Find(id);
                if (detailsToDelete is null)
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("PersonalDetailsNotFound"));
                    return new Response<PersonalDetailsDTO> { Success = false, StatusCode = System.Net.HttpStatusCode.NotFound, Message = "PersonalDetailsNotFound" };
                }
                var message = await _personalDetailsRepository.Delete(detailsToDelete);
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("PersonalDetailsSuccessfullyDeleted"));
                return new Response<PersonalDetailsDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "PersonalDetailsSuccessfullyDeleted" };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new Response<PersonalDetailsDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };
            }
        }

        private async Task<List<FilePath>> Upload(IList<IFormFile> files, int Candidate)
        {
            
            try 
            {
                List<FilePath> result = new List<FilePath>();
                
                if (!files.Any())
                {
                    return null;
                }
                foreach (var file in files)
                {
                    string fileName = file.FileName.Replace(" ", "").Trim();   
                    var initialpath = Path.Combine(Directory.GetCurrentDirectory(), "Resources");           
                    var path = Path.Combine(initialpath, Candidate.ToString());
                    FilePath fileToAdd = new FilePath();
                    if (!Directory.Exists(path))
                    { 
                        Directory.CreateDirectory(path);
                    }
                    string pathFile = Path.Combine(path, fileName);
                    
                    using (var stream = File.Create(pathFile))
                    {
                        file.CopyTo(stream);
                        stream.Position = 0;
                        if (fileName.Contains("CartaIdentita"))
                        {
                            fileToAdd = new FilePath { type = FilePath.Type.IdCard, Path = Path.Combine(Candidate.ToString(), fileName) };
                        }
                        if (fileName.Contains("CodiceFiscale"))
                        {
                            fileToAdd = new FilePath { type = FilePath.Type.HealthCard, Path = Path.Combine(Candidate.ToString(), fileName) };
                        }
                        if (fileName.Contains("PermessoSoggiorno"))
                        { 
                            fileToAdd = new FilePath { type = FilePath.Type.ResidencePermit, Path = Path.Combine(Candidate.ToString(), fileName) };
                        }
                          
                        result.Add(fileToAdd);
                    }
                        
                }
                return result;

            }
            catch(Exception ex)
            {
                throw ex;
            }
            
            
            
        }

        public async Task<Response<PersonalDetailsDTO>> FilesManagement(FilesDTO files)
        {
            try
            {
                var user = await _candidateProfileRepository.Find(files.CandidateId);
                var listFiles = await Upload(files.files, user.Id);

                CandidateFile candidateFile = new CandidateFile { Id = 0, CandidateId = files.CandidateId };

                foreach (var file in listFiles)
                {
                    switch (file.type)
                    {
                        case FilePath.Type.IdCard:
                            candidateFile.IDCard = file.Path;
                            break;

                        case FilePath.Type.HealthCard:
                            candidateFile.HealthCard = file.Path;
                            break;

                        case FilePath.Type.ResidencePermit:
                            candidateFile.ResidencePermit = file.Path;
                            break;

                    }

                }
                var response = await _candidateFileRepository.Create(candidateFile);
                if (response == 0) return new Response<PersonalDetailsDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = "ErrorFileCandidateUpload" };
                return new Response<PersonalDetailsDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "CandidateFileCreated" + " Id: " + response.ToString() };
            }
            catch(Exception ex)
            {
                return new Response<PersonalDetailsDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message};
            }
            
        }

        public async Task<Response<string>> GetIdCard(int candidateId)
        {
            try
            {
                var candidateFiles = await _candidateFileRepository.FindByCandidateId(candidateId);
                var idCardPath = Path.Combine(Directory.GetCurrentDirectory(),"Resources", candidateFiles.IDCard);
             
                byte[] fileBytes = File.ReadAllBytes(idCardPath);
                string base64String = Convert.ToBase64String(fileBytes);

                return new Response<string> { Success = true, StatusCode = HttpStatusCode.OK, Dto = base64String, Message = "FileFounded" }; 

            }
            catch (Exception ex)
            {
                return new Response<string> { Success = true, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };
            }
        }

        public async Task<Response<string>> GetHealthCard(int candidateId)
        {
            try
            {
                var candidateFiles = await _candidateFileRepository.FindByCandidateId(candidateId);
                var idCardPath = Path.Combine(Directory.GetCurrentDirectory(), "Resources", candidateFiles.HealthCard);

                byte[] fileBytes = File.ReadAllBytes(idCardPath);
                string base64String = Convert.ToBase64String(fileBytes);

                return new Response<string> { Success = true, StatusCode = HttpStatusCode.OK, Dto = base64String, Message = "FileFounded" };

            }
            catch (Exception ex)
            {
                return new Response<string> { Success = true, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };
            }
        }

        public async Task<Response<string>> GetResidencepermit(int candidateId)
        {
            try
            {
                var candidateFiles = await _candidateFileRepository.FindByCandidateId(candidateId);
                var idCardPath = Path.Combine(Directory.GetCurrentDirectory(), "Resources", candidateFiles.ResidencePermit);

                byte[] fileBytes = File.ReadAllBytes(idCardPath);
                string base64String = Convert.ToBase64String(fileBytes);

                return new Response<string> { Success = true, StatusCode = HttpStatusCode.OK, Dto = base64String, Message = "FileFounded" };

            }
            catch (Exception ex)
            {
                return new Response<string> { Success = true, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };
            }
        }

        public async Task<bool> HasResidencePermit(int candidateId)
        {
            try 
            {
                var candidateFiles = await _candidateFileRepository.FindByCandidateId(candidateId);
                if(candidateFiles.ResidencePermit is null) return false; 
                return true;
                
            }catch(Exception ex) 
            {
                throw ex;
            }
        }
    }
}
