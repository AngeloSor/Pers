﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using Pers.BLL.IServices;
using Pers.BLL.Models;
using Pers.DAL.Entities;
using Pers.DAL.IRepositories;
using Pers.DAL.Repositories;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Reflection.Metadata.Ecma335;
using System.Security.Claims;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Pers.BLL.Services
{
    public class PcReservationService : IPcReservationService
    {
        private readonly ILogger<PcReservationService> _logger;
        private readonly IStatusDictionaryService _statusDictionaryService;
        private readonly IEquipmentManagementRepository _equipmentManagementRepository;
        private readonly IMapper _mapper;
        private readonly string keycloakId;
        private readonly List<string> roles;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public PcReservationService(IEquipmentManagementRepository equipmentManagementRepository, IMapper mapper, IHttpContextAccessor httpContextAccessor, ILogger<PcReservationService> logger, IStatusDictionaryService statusDictionaryService)
        {
            _logger = logger;
            _statusDictionaryService = statusDictionaryService;
            _equipmentManagementRepository = equipmentManagementRepository;
            _mapper = mapper;
            _httpContextAccessor = httpContextAccessor;
            keycloakId = GetClaim(ClaimTypes.NameIdentifier);
            roles = GetClaimRole("resource_access");
            _statusDictionaryService = statusDictionaryService;
        }

        public async Task<Response<PcReservationDTO>> Create(PcReservationDTO pcReservationDTO)
        {
            if (!(await ReservationCheck(pcReservationDTO)))
            {
                _logger.LogError(_statusDictionaryService.GetDictionaryValue("ReservationDateTimeCheckFailed"));
                return new Response<PcReservationDTO> { Success = false, StatusCode = HttpStatusCode.BadRequest, Message = "ReservationDateTimeCheckFailed" };
            } 
            try
            {
                var pcReservationToSend = await _equipmentManagementRepository.Create(_mapper.Map<EquipmentManagement>(pcReservationDTO));
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("PcReservationSuccessfullyCreated"));
                return new Response<PcReservationDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "PcReservationSuccessfullyCreated" + " Id: " + pcReservationToSend };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new Response<PcReservationDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };

            }
        }

        public async Task<Response<PcReservationDTO>> Update(PcReservationDTO pcReservationDTO)
        {
            try
            {
                var equipmentToUpdate = await _equipmentManagementRepository.Find(pcReservationDTO.Id);
                
                if (equipmentToUpdate == null) return new Response<PcReservationDTO> { Success = true, StatusCode = HttpStatusCode.BadRequest, Message = "EquipmentNotFound" };
                if (equipmentToUpdate.ContractProposalId == 0) return new Response<PcReservationDTO> { Success = false, StatusCode = HttpStatusCode.BadRequest, Message = "EquipmentRequestHasnoContractProposalId" };
                var eq = _mapper.Map<EquipmentManagement>(pcReservationDTO);
                eq.Telephone = equipmentToUpdate.Telephone;
                eq.SIM = equipmentToUpdate.SIM;
                eq.FringeBenefitCar = equipmentToUpdate.FringeBenefitCar;
                eq.Car = equipmentToUpdate.Car;
                eq.Badge = equipmentToUpdate.Badge;
                var pcReservationToSend = await _equipmentManagementRepository.Update(eq);
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("PcReservationSuccessfullyUpdated"));
                return new Response<PcReservationDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "PcReservationSuccessfullyUpdated", Dto = pcReservationDTO };
            }
            catch (Exception ex) 
            {
                _logger.LogError(ex.Message);
                return new Response<PcReservationDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message=ex.Message }; 
            }
        }
       
        public async Task<Response<PcReservationDTO>> Find(int id)
        {
            try
            {
                if (id == 0) return new Response<PcReservationDTO> { Success = false, StatusCode = HttpStatusCode.BadRequest, Message = "BadRequestId0IsNotaValideValue" };
                var pcReservationFound = await _equipmentManagementRepository.Find(id);
                var pcReservationToSend = _mapper.Map<PcReservationDTO>(pcReservationFound);
                if (pcReservationToSend is null)
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("PcReservationNotFound"));
                    return new Response<PcReservationDTO> { Success = false, StatusCode = HttpStatusCode.NotFound, Message = "PcReservationNotFound" };
                }
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("PcReservationSuccessfullyFound"));
                return new Response<PcReservationDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "PcReservationSuccessfullyFound", Dto = pcReservationToSend };

            }
            catch(Exception ex)
            {
                _logger.LogError(ex.Message);
                return new Response<PcReservationDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };
            }
        }
        public async Task<ListResponse<PcReservationDTO>> GetAll() 
        {
            try
            {
                var allPcReservation = await _equipmentManagementRepository.GetAll();
                var allPcReservationToSend = allPcReservation.Select(reservation => _mapper.Map<PcReservationDTO>(reservation)).ToList();
                if (allPcReservation.Count() == 0)
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("PcReservationNotFound"));
                    return new ListResponse<PcReservationDTO>{ Success = false, StatusCode = HttpStatusCode.NotFound, Message = "PcReservationNotFound"};
                }
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("PcReservatinonSuccessfullyFound"));
                return new ListResponse<PcReservationDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "PcReservatinonSuccessfullyFound", DTOs = allPcReservationToSend };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new ListResponse<PcReservationDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };

            }
        }
        public async Task<Response<bool>> Delete(int id)
        {
            try
            {
                if (id == 0) return new Response<bool> { Success = false, StatusCode = HttpStatusCode.BadRequest, Message = "BadRequestId0IsNotaValideValue" };
                var pcReservationToDelete = await _equipmentManagementRepository.Find(id);
                if (pcReservationToDelete is null)
                {
                   
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("PcReservationNotFound"));
                    return new Response<bool> { Success = false, StatusCode = HttpStatusCode.NotFound, Message = "PcReservationNotFound", Dto = false };
                } 
                var isPcReservationDeleted = await _equipmentManagementRepository.Delete(pcReservationToDelete);
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("PcReservationSuccessfullyDeleted"));
                return new Response<bool> { Success = false , StatusCode = HttpStatusCode.OK, Message = "PcReservationSuccessfullyDeleted", Dto = isPcReservationDeleted };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new Response<bool> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };
            }
        }

        private async Task<bool> ReservationCheck(PcReservationDTO pcReservationDTO)
        {

            return await _equipmentManagementRepository.DataCheck(pcReservationDTO.Date, pcReservationDTO.Time);
            
        }

        private string GetClaim(string claimType)
        {
            return ((ClaimsIdentity)_httpContextAccessor.HttpContext.User.Identity!).FindFirst(claim => claim.Type == claimType)!.Value;
        }
        private List<string> GetClaimRole(string claimType)
        {
            List<string> rolesList = new List<string>();
            var userRole = ((ClaimsIdentity)_httpContextAccessor.HttpContext.User.Identity!).FindFirst(claim => claim.Type == claimType);
            var content = Newtonsoft.Json.Linq.JObject.Parse(userRole.Value);
            foreach (var role in content["PersHr"]["roles"])
            {
                rolesList.Add(role.ToString());
            }
            return rolesList;
        }

        public async Task<Response<SmallReservationDTO>> FindSmall(int id)
        {
            try
            {
                if (id == 0) return new Response<SmallReservationDTO> { Success = false, StatusCode = HttpStatusCode.BadRequest, Message = "BadRequestId0IsNotaValideValue" };
                var res = await _equipmentManagementRepository.Find(id);
                if (res is null) return new Response<SmallReservationDTO> { Success = false, Message = "SmallResNotFound", StatusCode = HttpStatusCode.NotFound };
                var smallResToSend = _mapper.Map<SmallReservationDTO>(res);
                return new Response<SmallReservationDTO> { Success = true, StatusCode= HttpStatusCode.OK, Message="SmallResFound", Dto= smallResToSend };
            }
            catch (Exception ex)
            {
                return new Response<SmallReservationDTO> { StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };
            }
        }

        public async Task<ListResponse<SmallReservationDTO>> GetAllSmall()
        {
            try
            {

                var allPcReservation = await _equipmentManagementRepository.GetAll();
                var allPcReservationToSend = allPcReservation.Select(reservation => _mapper.Map<SmallReservationDTO>(reservation)).ToList();
                if (allPcReservation.Count() == 0)
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("PcReservationNotFound"));
                    return new ListResponse<SmallReservationDTO> { Success = false, StatusCode = HttpStatusCode.NotFound, Message = "PcReservationNotFound" };
                }
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("PcReservatinonSuccessfullyFound"));
                return new ListResponse<SmallReservationDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "PcReservatinonSuccessfullyFound", DTOs = allPcReservationToSend };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new ListResponse<SmallReservationDTO> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };

            }
        }
    }
}
