﻿using Microsoft.Extensions.Logging;
using Pers.BLL.IServices;
using Pers.BLL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Pers.BLL.Services
{
    public class PowerAutomateService : IPowerAutomateService
    {
        private readonly ILogger<PowerAutomateService> _logger;
        public PowerAutomateService(ILogger<PowerAutomateService> logger)
        {
            _logger = logger;
        }
       
        
       
        public async Task<Response<string>> SendForm(CandidateProfileDTO CandidateDTO)
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("https://prod-162.westeurope.logic.azure.com:443/workflows/06492aa92bfe47599808eb8cf52f5887/triggers/manual/paths/invoke?api-version=2016-06-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=8RLlMFO3Qg_J6jGZw8dMWVsHhaQ2Q1YGq2v0nFig8-c");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, client.BaseAddress);

            var body = JsonSerializer.Serialize(CandidateDTO);
            var content = new StringContent(body, Encoding.UTF8, "application/json");
            request.Content = content;
            var response = await MakeRequestAsync(request, client);
            return response;
        }
        public async Task<Response<string>> MakeRequestAsync(HttpRequestMessage getRequest, HttpClient client)
        {
            var response = await client.SendAsync(getRequest).ConfigureAwait(false);
            var responseString = string.Empty;
            var responseToSend = new Response<string>();

            try
            {
                response.EnsureSuccessStatusCode();
                responseString = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                _logger.LogInformation(responseString);
                responseToSend = new Response<string> { Success = true, StatusCode = response.StatusCode, Message = responseString };
            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex.Message);
                responseToSend = new Response<string> { Success = false, StatusCode = response.StatusCode, Message = ex.Message };
            }
            return responseToSend;
        }

		public async Task<Response<string>> SendApprovalStageContractProposal(StageContractProposalDTO stageContractProposalDTO)
		{
			HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("https://prod-71.westeurope.logic.azure.com:443/workflows/b728b84823c24c6bb459dec2eb1c3bc0/triggers/manual/paths/invoke?api-version=2016-06-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=jBGqJ1v804uwTFw7E1FNJdadF3BtwylLfBm0ojPJFpI");
			client.DefaultRequestHeaders.Accept.Clear();
			client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

			HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, client.BaseAddress);

			var body = JsonSerializer.Serialize(stageContractProposalDTO);
			var content = new StringContent(body, Encoding.UTF8, "application/json");
			request.Content = content;
			var response = await MakeRequestAsync(request, client);
			return response;
		}

		public async Task<Response<string>> SendApprovalHiredContractProposal(HiredContractProposalDTO hiredContractProposalDTO)
		{
			HttpClient client = new HttpClient();
			client.BaseAddress = new Uri("https://prod-211.westeurope.logic.azure.com:443/workflows/7b0e836103c348b4b7ccd71d949413e5/triggers/manual/paths/invoke?api-version=2016-06-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=9SmSFKghI1V8wkRuw1LWk4Z3AMS5_17ZmZymYMNy4W4");
			client.DefaultRequestHeaders.Accept.Clear();
			client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

			HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, client.BaseAddress);

			var body = JsonSerializer.Serialize(hiredContractProposalDTO);
			var content = new StringContent(body, Encoding.UTF8, "application/json");
			request.Content = content;
			var response = await MakeRequestAsync(request, client);
			return response;
		}

	}
}
