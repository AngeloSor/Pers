﻿using Microsoft.Extensions.Logging;
using Pers.BLL.IServices;
using Pers.BLL.Models;
using Pers.DAL.Entities;
using Pers.DAL.IRepositories;
using Pers.DAL.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Pers.BLL.Services
{
    public class CostCalculationService : ICostCalculationService
    {
        private readonly IContractProposalRepository _contractProposalRepository;
        private readonly ILogger<CostCalculationService> _logger;
        private readonly IStatusDictionaryService _statusDictionaryService;
        private readonly IHeadOfficeRepository _headOfficeRepository;
        public CostCalculationService(IHeadOfficeRepository headOfficeRepository, ILogger<CostCalculationService> logger, IStatusDictionaryService statusDictionaryService, IContractProposalRepository contractProposalRepository)
        {
            _logger = logger;
            _statusDictionaryService = statusDictionaryService;
            _contractProposalRepository = contractProposalRepository;
            _headOfficeRepository = headOfficeRepository;

        }
        
        
        private Response<double> TocCalculation(HiredContractProposalDTO hiredToCalculate)
        {
            double total = 0.00;
            try
            {
                if ( hiredToCalculate.TraveAllowance )
                {
                    total = (double)hiredToCalculate.Amount * 220;
                }
                if (( hiredToCalculate.Ticket == "Ticket specifico mensa Cliente" || hiredToCalculate.Ticket == "Mensa Cliente"))
                {
                    total += (double) hiredToCalculate.ApproximateDailyPrice * 220;
                }
                else total += 7 * 220;
                if ( hiredToCalculate.Guesthouse )
                {
                    if (hiredToCalculate.ApproximateMonthlyPrice is null || hiredToCalculate.ApproximateMonthlyPrice == 0)
                    {
                        total += 550 * 12;
                    }
                   total += (double)hiredToCalculate.ApproximateMonthlyPrice * 12;
                }
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("SuccessfullyCalculated"));
                return new Response<double> { Success = true, StatusCode = HttpStatusCode.OK, Message = "SuccessfullyCalculated", Dto = total};
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new Response<double> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };
            }
        }
        private async Task<Response<double>> Toc2Calculation(ContractProposalDTO contractProposal, EquipmentManagementDTO equipmentManagementDTO,HiredContractProposalDTO hiredContractProposalDTO)
        {
            double total = 0;
            try
            {
                if (equipmentManagementDTO.Telephone == true)
                {
                    total = 14 * 12;
                }
                if(hiredContractProposalDTO.WorkstationAltenCompany)
                {
                    var headOffice = await _headOfficeRepository.Find(contractProposal.HeadOfficeId);
                    total += headOffice.DailyCost;
                }
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("SuccessfullyCalculated"));
                return new Response<double> { Success = true, StatusCode = HttpStatusCode.OK, Message = "SuccessfullyCalculated", Dto = total };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new Response<double> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };
            }
        }

        private Response<double> TscCalculation(ContractDTO contractDTO)
        {
            try
            {
                
                double TSCHired = 0;
                double TSCStage = 0;
                if (contractDTO == null)
                {
                    return new Response<double> { Success = false, StatusCode = HttpStatusCode.BadRequest, Message = "ContractProposalNotFound" };
                }
                if (contractDTO.HiredContractProposalDTO is null)
                {
                    TSCStage = contractDTO.StageContractProposalDTO.RefundStage + SearchScAndTFR(contractDTO.ContractProposalDTO.ContractType);
                    return new Response<double> { Success = true, StatusCode = HttpStatusCode.OK, Dto = TSCStage };
                }
                else 
                {
                    if (contractDTO.StageContractProposalDTO is null)
                    {
                        TSCHired = (double)(contractDTO.HiredContractProposalDTO.Ral + contractDTO.HiredContractProposalDTO.BonusValue + SearchScAndTFR(contractDTO.ContractProposalDTO.ContractType));
                        return new Response<double> { Success = true, StatusCode = HttpStatusCode.OK, Dto = TSCHired };
                    }
                    
                }
                return new Response<double> { Success = false, StatusCode = HttpStatusCode.BadRequest, Message = "ContractProposalNotHaveHiredOrStage" };
              
                
                
            }
            catch (Exception ex)
            {
                return new Response<double> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };

            }
        }
        private double SearchScAndTFR(ContractProposalDTO.Contracts cType)
        {
            double calculation = 0;
            switch (cType)
            {
                case ContractProposalDTO.Contracts.Apprendistato:
                    return (14.91 / 100) + (7.41 / 100);
                case ContractProposalDTO.Contracts.TempoDeterminato:
                    return (31.61 / 100) + (6.91 / 100);
                case ContractProposalDTO.Contracts.TempoIndeterminato:
                    return (31.51 / 100) + (6.91 / 100);
                default: return 0;
            }
        }

        private Response<double> TicCalculation(EquipmentManagementDTO equipmentManagementDTO)
        {
            try
            {
                if(equipmentManagementDTO == null)
                {
                    return new Response<double> { Success = false, StatusCode = HttpStatusCode.BadRequest, Message = "ContractProposalNotFound" };
                }
                if(equipmentManagementDTO is null)
                {
                    return new Response<double> { Success = false, StatusCode = HttpStatusCode.BadRequest, Message = "EquipmentNotFound"};
                }
                return new Response<double> { Success = true, StatusCode = HttpStatusCode.OK, Message= "CalcolationSuccessfullyExecuted", Dto = TicPerformance(equipmentManagementDTO) }; 


            }
            catch(Exception ex)
            {
                return new Response<double> { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };
            }
        }
        private double TicPerformance(EquipmentManagementDTO equipmentManagementDTO) 
        {
            double Tic = 0;
            double pc = 0;
            double office = 0;
            switch (equipmentManagementDTO.LaptopModel)
            {
                case "Base: 14 pollici - 8gb ram - 256 GB SSD - windows 10":
                    pc += 554.00;
                    break;
                case "BM/TUM: 14 pollici - 8gb ram - 256 GB SSD - windows 10":
                    pc += 1250.00;
                    break;

                case "Pc Developer: 15 Pollici – Processore i7 - 16gb ram – 512 gb SSD- Windows 10":
                    pc += 850.00;
                    break;

                default: 
                    return pc;
            }
            switch(equipmentManagementDTO.OfficeVersion) 
            {
                case "Office 365 - P-FULL (installabile)":
                    office = 216.00;
                    break;

                case "Office 365 - P-online (office online)":
                    office = 51.94;
                    break;
                default: return office;
            }

            Tic += pc + office;
            return Tic;
        }

        public async Task<Response<MarginDTO>> GenerateMarginResourceCost(ContractDTO contractDTO)
        {
            var resourceCost = TscCalculation(contractDTO).Dto + TocCalculation(contractDTO.HiredContractProposalDTO).Dto + Toc2Calculation(contractDTO.ContractProposalDTO, contractDTO.EquipmentManagementDTO, contractDTO.HiredContractProposalDTO).Result.Dto + TicCalculation(contractDTO.EquipmentManagementDTO).Dto;
            var to = contractDTO.HiredContractProposalDTO.DailyCost * 220;
            var margine = ((to - resourceCost) / to) * 100;
            MarginDTO margin = new MarginDTO { ResourceCost = resourceCost, Margin = margine };
            return new Response<MarginDTO> { Success = true, StatusCode = HttpStatusCode.OK , Message = "Margin&RCCalculatedSuccessfully", Dto = margin};          
        }
    }
}
