﻿using Newtonsoft.Json;
using Pers.BLL.Models;
using Pers.DAL.Entities;
using System.Net.Http.Headers;
using System.Net;
using System.Text;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Authentication;
using Pers.BLL.IServices;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using IdentityModel.Client;
using Keycloak.AuthServices.Sdk.Admin.Models;
using System.Text.RegularExpressions;
using Org.BouncyCastle.Bcpg;
using Group = Pers.BLL.Models.Group;
using Microsoft.Extensions.ObjectPool;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion.Internal;
using Org.BouncyCastle.Crypto.Agreement;

namespace Pers.BLL.Services
{
    public class KeycloakService : IKeycloakService
    {
        private readonly IConfiguration _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ILogger<KeycloakService> _logger;
        public KeycloakService(IHttpContextAccessor httpContextAccessor, IConfiguration configuration, ILogger<KeycloakService> logger)
        {
            _httpContextAccessor = httpContextAccessor;
            _configuration = configuration;
            _logger = logger;
        }
        
        public async Task<Response<KeycloakResponse>> Login(CredentialDTO credentialDTO)
        {
            HttpClient client = new HttpClient();

            var clientSecret = _configuration.GetSection("Keycloak:client_secret").Value;
            var json = $"client_id=PersHr&username={credentialDTO.email}&password={credentialDTO.password}&grant_type=password&client_secret="+clientSecret;
            var authServerUrl = _configuration.GetSection("Keycloak:auth-server-url").Value;
            var realm = _configuration.GetSection("Keycloak:realm").Value;

            var url = authServerUrl + "realms/" + realm + "/protocol/openid-connect/token";

            var data = new StringContent(json, Encoding.UTF8, "application/x-www-form-urlencoded");

            var responseR = await client.PostAsync(url, data);

            var content = await responseR.Content.ReadAsStringAsync();
            KeycloakResponse res = JsonConvert.DeserializeObject<KeycloakResponse>(content);

            try
            {
                responseR.EnsureSuccessStatusCode();
               
                return new Response<KeycloakResponse> { Success = true, StatusCode = responseR.StatusCode, Dto = res};
            }
            catch (Exception ex)
            {
                 return new Response<KeycloakResponse> { Success = true, StatusCode = responseR.StatusCode, Message = ex.Message };
            }
        }
        public async Task<string> CreateUserOnKeycloak(UserKeycloak bmHrKeycloak)
        {
            HttpClient client = new HttpClient();
            var authServerUrl = _configuration.GetSection("Keycloak:auth-server-url").Value;
            var keycloakRealm = _configuration.GetSection("Keycloak:realm").Value;

            var url = authServerUrl + "admin/realms/" + keycloakRealm + "/users";
            var json = JsonConvert.SerializeObject(bmHrKeycloak);
            var data = new StringContent(json, Encoding.UTF8, "application/json");
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", GetToken());

            var responseR = await client.PostAsync(url, data);

            var content = responseR.Content.ReadAsStringAsync();
           
            return responseR.ReasonPhrase;
        }
        public async Task<bool> SetPasswordOnKeycloak(string password, string userId)
        {

                HttpClient client = new HttpClient();

                var authServerUrl = _configuration.GetSection("Keycloak:auth-server-url").Value;
                var realm = _configuration.GetSection("Keycloak:realm").Value;
                var url = authServerUrl + "admin/realms/" + realm + "/users/" + userId + "/reset-password";
                PasswordKeycloakDTO passwordKeycloak = new PasswordKeycloakDTO() { Value = password };
                var json = JsonConvert.SerializeObject(passwordKeycloak);
                var data = new StringContent(json, Encoding.UTF8, "application/json");

                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", GetToken());

                var responseR = await client.PutAsync(url, data);

                var content = responseR.Content.ReadAsStringAsync();
                return responseR.IsSuccessStatusCode;   

        }

        public async Task<string> GetIdKeycloak(string email)
        {

            HttpClient client = new HttpClient();

            var json = JsonConvert.SerializeObject(email);
            var authServerUrl = _configuration.GetSection("Keycloak:auth-server-url").Value;
            var keycloakRealm = _configuration.GetSection("Keycloak:realm").Value;
            var url = authServerUrl+"admin/realms/"+keycloakRealm+$"/users?email={email}";

            var data = new StringContent(json, Encoding.UTF8, "application/json");
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", GetToken());

            var responseR = await client.GetAsync(url);

            var content = await responseR.Content.ReadAsStringAsync();
            var split = content.Split("\"");
            var id = split[3];
            try
            {
                responseR.EnsureSuccessStatusCode();
                return id;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }

        }
        public async Task<bool> SetGroupOnUser(string userId, string group)
        {
            HttpClient client = new HttpClient();
            var authServerUrl = _configuration.GetSection("Keycloak:auth-server-url").Value;
            var keycloakRealm = _configuration.GetSection("Keycloak:realm").Value;
            var groupId = await GetIdGroup(group.ToLower());
            var url = authServerUrl + "admin/realms/" + keycloakRealm + "/users/" + userId+ "/groups/"+groupId;
            var json = "";
            var data = new StringContent(json, Encoding.UTF8, "application/json");
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", GetToken());

            var responseR = await client.PutAsync(url, data);

            var content = responseR.Content.ReadAsStringAsync();
            return responseR.IsSuccessStatusCode;

        }
        private async Task<string> GetIdGroup(string role)
        {
            var groups = await GetGroups();
            foreach(Group group in groups)
            {
                if(role == group.Name)
                { return group.Id; }
            }
            return null;
        }
        private async Task <List<Group>> GetGroups()
        {
            HttpClient client = new HttpClient();
            var authServerUrl = _configuration.GetSection("Keycloak:auth-server-url").Value;
            var keycloakRealm = _configuration.GetSection("Keycloak:realm").Value;
            var url = authServerUrl + "admin/realms/" + keycloakRealm + "/groups";

            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", GetToken());

            var responseR = await client.GetAsync(url);
            try 
            {
                responseR.EnsureSuccessStatusCode();
                var content = await responseR.Content.ReadAsStringAsync();
                List<Group> groups = JsonConvert.DeserializeObject<List<Group>>(content);
                return groups;
            }
            catch(Exception ex) 
            {
                return null;
            }

        }

        public async Task<Response<KeycloakResponse>> RefreshToken(string token)
        {

            HttpClient client = new HttpClient();
            var authServerUrl = _configuration.GetSection("Keycloak:auth-server-url").Value;
            var keycloakRealm = _configuration.GetSection("Keycloak:realm").Value;
            var clientId = _configuration.GetSection("Keycloak:resource").Value;
            var clientSecret = _configuration.GetSection("Keycloak:client_secret").Value;
            var json = $"client_id={clientId}&refresh_token={token}&client_secret={clientSecret}&grant_type=refresh_token";
            var url = authServerUrl+"realms/"+ keycloakRealm + "/protocol/openid-connect/token";

            var data = new StringContent(json, Encoding.UTF8, "application/x-www-form-urlencoded");
            //client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", GetToken());

            var responseR = await client.PostAsync(url, data);

            var content = await responseR.Content.ReadAsStringAsync();
            KeycloakResponse res = JsonConvert.DeserializeObject<KeycloakResponse>(content);

            try
            {
                responseR.EnsureSuccessStatusCode();

                return new Response<KeycloakResponse> { Success = true, StatusCode = responseR.StatusCode, Dto = res };
            }
            catch (Exception ex)
            {
                return new Response<KeycloakResponse> { Success = true, StatusCode = responseR.StatusCode, Message = ex.Message };
            }
        }
        private string GetToken()
        {
            return _httpContextAccessor.HttpContext.GetTokenAsync("access_token").Result;
        }
    }
}
