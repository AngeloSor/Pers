﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using Pers.BLL.IServices;
using Pers.BLL.Models;
using Pers.DAL.Entities;
using Pers.DAL.IRepositories;
using Pers.DAL.Repositories;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace Pers.BLL.Services
{
	public class StageContractProposalService : IStageContractProposalService
	{
		private readonly ILogger<StageContractProposalService> _logger;
		private readonly IStatusDictionaryService _statusDictionaryService;
		private readonly IStageContractProposalRepository _stageContractProposalRepository;
		private readonly IMapper _mapper;
		private readonly string keycloakId;
		private readonly List<string> roles;
		private readonly IPowerAutomateService _powerAutomateService;
		private readonly IHttpContextAccessor _httpContextAccessor;

		public StageContractProposalService(IStageContractProposalRepository stageContractProposalRepository, IMapper mapper, IHttpContextAccessor httpContextAccessor, IPowerAutomateService powerAutomateService, ILogger<StageContractProposalService> logger, IStatusDictionaryService statusDictionaryService)
		{
			_logger = logger;
			_statusDictionaryService = statusDictionaryService;
			_stageContractProposalRepository = stageContractProposalRepository;
			_mapper = mapper;
			_httpContextAccessor = httpContextAccessor;
			keycloakId = GetClaim(ClaimTypes.NameIdentifier);
			roles = GetClaimRole("resource_access");
			_powerAutomateService = powerAutomateService;
		}
		public async Task<Response<StageContractProposalDTO>> Create(StageContractProposalDTO stageContractProposalDTO)
		{

			try
			{
                if (await _stageContractProposalRepository.ContractAlreadyAssociated(stageContractProposalDTO.ContractProposalId))
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("ContractHasAlreadyAssociatedStage"));
                    return new Response<StageContractProposalDTO> { Success = true, StatusCode = HttpStatusCode.BadRequest, Message = "ContractHasAlreadyAssociatedStage" };
                }
				if (!formatCheck(stageContractProposalDTO)) return new Response<StageContractProposalDTO> { Success = false, StatusCode = HttpStatusCode.BadRequest, Message = "ContractFormatCheckFailed" };
				var stageContractId = await _stageContractProposalRepository.Create(_mapper.Map<StageContractProposal>(stageContractProposalDTO));
				
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("ContractSuccessfullyCreated"));
                return new Response<StageContractProposalDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "ContractSuccessfullyCreated" + " " + stageContractId };
			}
			catch (Exception ex)
			{
				_logger.LogError(ex.Message);
				return new Response<StageContractProposalDTO> { Success = false, StatusCode = HttpStatusCode.BadRequest, Message = ex.Message };
			}
		}
		private bool formatCheck(StageContractProposalDTO stageContractProposalDTO) 
		{
			if (stageContractProposalDTO.DurationStage is null || stageContractProposalDTO.TutorStage1 is null || stageContractProposalDTO.TutorStage2 is null || stageContractProposalDTO.FunctionTutor1 is null || stageContractProposalDTO.FunctionTutor2 is null || stageContractProposalDTO.ProjectDescription is null || stageContractProposalDTO.RefundStage == 0 || stageContractProposalDTO.ContractProposalId == 0) return false;
			return true;
		
		}

		public async Task<Response<StageContractProposalDTO>> Update(StageContractProposalDTO stageContractProposalDTO)
		{
			try
			{
				if (!(await _stageContractProposalRepository.ContractExist(stageContractProposalDTO.Id)))
				{
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("ContractProposalNotFound"));
                    return new Response<StageContractProposalDTO> { Success = true, StatusCode = HttpStatusCode.NotFound, Message = "ContractProposalNotFound" };
				}
				if (!formatCheck(stageContractProposalDTO)) return new Response<StageContractProposalDTO> { Success = false, StatusCode = HttpStatusCode.BadRequest, Message = "ContractProposalFormatCheckFailed" };

				var contractProposaltoPut = await _stageContractProposalRepository.Update(_mapper.Map<StageContractProposal>(stageContractProposalDTO));
				var contractProposalToSend = _mapper.Map<StageContractProposal>(contractProposaltoPut);
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("ContractSuccessfullyUpdated"));
                return new Response<StageContractProposalDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "ContractSuccessfullyUpdated" };
			}
			catch (Exception ex)
			{
                _logger.LogError(ex.Message);
                return new Response<StageContractProposalDTO> { Success = false, StatusCode = HttpStatusCode.BadRequest, Message = ex.Message };
            }

		}

		public async Task<Response<StageContractProposalDTO>> Find(int id)
		{
			try
			{
				var contractProposalToFind = _mapper.Map<StageContractProposalDTO>(await _stageContractProposalRepository.Find(id));
				if (contractProposalToFind is null)
				{
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("ContractNotFound"));
                    return new Response<StageContractProposalDTO> { Success = false, StatusCode = HttpStatusCode.NotFound, Message = "ContractNotFound" };
				}
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("ContractSuccessfullyFound"));
                return new Response<StageContractProposalDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "ContractSuccessfullyFound", Dto = contractProposalToFind };
			}
			catch (Exception ex)
			{
                _logger.LogError(ex.Message);
                return new Response<StageContractProposalDTO> { Success = false, StatusCode = HttpStatusCode.BadRequest, Message = ex.Message };
			}
		}
		public async Task<Response<StageContractProposalDTO>> FindContractProposal(int candidateId)
		{
			try
			{
				var contractToFind = await _stageContractProposalRepository.FindContract(candidateId);
				if (contractToFind is null)
				{
					_logger.LogError(_statusDictionaryService.GetDictionaryValue("ContractNotFound"));
					return new Response<StageContractProposalDTO> { Success = false, StatusCode = HttpStatusCode.NotFound, Message = "ContractNotFound" };
				}
				var contractToSend = _mapper.Map<StageContractProposalDTO>(contractToFind);
				_logger.LogError(_statusDictionaryService.GetDictionaryValue("ContractSuccessfullyFound"));
				return new Response<StageContractProposalDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "ContractSuccessfullyFound", Dto = contractToSend };
			}
			catch (Exception ex)
			{
				_logger.LogError(ex.Message);
				return new Response<StageContractProposalDTO>() { Success = false, StatusCode = HttpStatusCode.InternalServerError, Message = ex.Message };
			}
		}

		public async Task<ListResponse<StageContractProposalDTO>> GetAll()
		{
			try
			{
				var allContractProposal = await _stageContractProposalRepository.GetAll();
				var allContractProposaToSend = allContractProposal.Select(contract => _mapper.Map<StageContractProposalDTO>(contract)).ToList();
				if (allContractProposal.Count() == 0)
				{
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("ContractNotFound"));
                    return new ListResponse<StageContractProposalDTO> { Success = false, StatusCode = HttpStatusCode.NotFound, Message = "ContractNotFound" };
                }
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("ContractSuccessfullyFound"));
                return new ListResponse<StageContractProposalDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "ContractSuccessfullyFound", DTOs = allContractProposaToSend };
			}
			catch(Exception ex)
			{
                _logger.LogError(ex.Message);
                return new ListResponse<StageContractProposalDTO> {Success = false, StatusCode = HttpStatusCode.InternalServerError, Message= ex.Message};
			}
        }

        public async Task<Response<StageContractProposalDTO>> Delete(int id)
        {
			try
			{
				var contractProposalToDelete = await _stageContractProposalRepository.Find(id);
				if (contractProposalToDelete is null)
				{
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("ContractNotFound"));
                    return new Response<StageContractProposalDTO> { Success = false, StatusCode = HttpStatusCode.NotFound, Message = "ContractNotFound" };
                } 
				var message = await _stageContractProposalRepository.Delete(contractProposalToDelete);
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("ContractSuccessfullyDeleted"));
                return new Response<StageContractProposalDTO> { Success = true, StatusCode = HttpStatusCode.OK, Message = "ContractSuccessfullyDelete" };
			}
			catch (Exception ex)
			{
                _logger.LogError(ex.Message);
                return new Response<StageContractProposalDTO> { Success = false, StatusCode = HttpStatusCode.BadRequest, Message = ex.Message };
            }
        }

		private string GetClaim(string claimType)
		{
			return ((ClaimsIdentity)_httpContextAccessor.HttpContext.User.Identity!).FindFirst(claim => claim.Type == claimType)!.Value;
		}
		private List<string> GetClaimRole(string claimType)
		{
			List<string> rolesList = new List<string>();
			var userRole = ((ClaimsIdentity)_httpContextAccessor.HttpContext.User.Identity!).FindFirst(claim => claim.Type == claimType);
			var content = Newtonsoft.Json.Linq.JObject.Parse(userRole.Value);
			foreach (var role in content["PersHr"]["roles"])
			{
				rolesList.Add(role.ToString());
			}
			return rolesList;
		}

    }

}

