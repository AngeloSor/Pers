﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Pers.BLL.IServices;
using Pers.BLL.Models;
using Pers.DAL.Entities;
using Pers.DAL.IRepositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace Pers.BLL.Services
{
    public class HeadOfficeService : IHeadOfficeService
    {   private readonly IHeadOfficeRepository _headOfficeRepository;
        private readonly IMapper _mapper;
        private ILogger<HeadOfficeService> _logger;
        private readonly IStatusDictionaryService _statusDictionaryService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public HeadOfficeService(IHeadOfficeRepository headOfficeRepository, IMapper mapper, IHttpContextAccessor httpContextAccessor, ILogger<HeadOfficeService> logger, IStatusDictionaryService statusDictionaryService) 
        {
            _headOfficeRepository = headOfficeRepository;
            _mapper = mapper;
            _logger = logger;
            _statusDictionaryService = statusDictionaryService;
           
        }
        public Task<Response<HeadOfficeDTO>> Create(HeadOfficeDTO headOfficeDTO)
        {
            throw new NotImplementedException();
        }

        public Task<Response<HeadOfficeDTO>> Delete(int id)
        {
            throw new NotImplementedException();
        }

        public async Task<Response<HeadOfficeDTO>> Find(int id)
        {
            try
            {
                var headOffice = await _headOfficeRepository.Find(id);
                if (headOffice is null)
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("HeadOfficeNotFound"));
                    return new Response<HeadOfficeDTO> { Success = false, StatusCode = System.Net.HttpStatusCode.NotFound, Message = "HeadOfficeNotFound" };

                }
                var headOfficeToSend = _mapper.Map<HeadOfficeDTO>(headOffice);
                _logger.LogInformation(_statusDictionaryService.GetDictionaryValue("HeadOfficeSuccessfullyFound"));
                return new Response<HeadOfficeDTO> { Success = true, StatusCode = System.Net.HttpStatusCode.OK, Message = "HeadOfficeSuccessfullyFound", Dto= headOfficeToSend };

            }
            catch (Exception ex) 
            {
                _logger.LogError(ex.Message);
                return new Response<HeadOfficeDTO> { Success = false, StatusCode = System.Net.HttpStatusCode.InternalServerError, Message = ex.Message};

            }
        }

        public async Task<ListResponse<HeadOfficeDTO>> GetAll()
        {
            try
            {
                var headOffices = await _headOfficeRepository.GetAll();
                var headOfficesToSend = headOffices.Select(ho => _mapper.Map<HeadOfficeDTO>(ho)).ToList();
                if (headOffices.Count == 0)
                {
                    _logger.LogError(_statusDictionaryService.GetDictionaryValue("HeadOfficeNotFound"));
                    return new ListResponse<HeadOfficeDTO> { Success = false, StatusCode = System.Net.HttpStatusCode.NotFound, Message = "HeadOfficeNotFound" };

                }
                _logger.LogError(_statusDictionaryService.GetDictionaryValue("HeadOfficesSuccessfullyFound"));
                return new ListResponse<HeadOfficeDTO> { Success = true, StatusCode = System.Net.HttpStatusCode.OK, Message = "HeadOfficesSuccessfullyFound", DTOs = headOfficesToSend };

            }
            catch (Exception ex)
            {
                return new ListResponse<HeadOfficeDTO> { Success = false, StatusCode = System.Net.HttpStatusCode.InternalServerError, Message = ex.Message };

            }
        }

        public Task<Response<HeadOfficeDTO>> Put(HeadOfficeDTO bmhrProfileDTO)
        {
            throw new NotImplementedException();
        }
     
    }
}
