﻿using Azure.Storage.Blobs;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Pers.BLL.IServices;
using Pers.BLL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.BLL.Services
{
    public class AzureBlobService: IAzureBlobService
    {
        private readonly IConfiguration _configuration;
        private readonly BlobContainerClient blobContainerClient;
        private readonly string blobUri;
        private readonly string container;
        public AzureBlobService(IConfiguration configuration)
        {
            _configuration = configuration;
            blobUri = _configuration.GetConnectionString("AzureBlob");
            container = _configuration.GetConnectionString("BlobContainer");
            blobContainerClient = new BlobContainerClient(blobUri, container);
        }

        public Task<IFormFile> DownloadBlob()
        {
            throw new NotImplementedException();
        }

        public async Task<bool> UploadBlob(Stream file)
        {
                BlobClient blobClient = blobContainerClient.GetBlobClient("ciao");
                await blobClient.UploadAsync(file, true);
                return blobClient.Exists();
            
        }
    }
}
