﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.BLL.Dictionaries
{
    public class StatusDictionaryResponse
    {
        private Dictionary<string, string> _statusDictionary = new Dictionary<string, string>
        {

               
                //BmHrService
                { "BadRequestFormatCheckFields", "Inserire tutti i campi obbligatori" },
                { "BadRequestFormatFiscalCode", "Il codice fiscale e' in formato errato" },
                { "ProfileSuccessfullyCreated", "Il profilo e' stato creato con successo con id : " },
                { "ProfileNotFound", "L'utente non e' stato trovato" },
                { "ProfileSuccessfullyFound", "Il profilo e' stato trovato con successo" },
                { "ListProfileSuccessfullyFound", "I profili sono stati trovati con successo" },
                { "UpdateProfileBadRequest", "Il profilo che si desidera aggiornare non e' stato trovato" },
                { "ProfileSuccessfullyUpdated", "Il profilo e' stato modificato con successo" },
                { "ProfileSuccessfullyDeleted", "Il profilo e' stato eliminato con successo" },

                //CandidateProfileService
                {"HasForeignKeyZero","L'id della foreign key è zero" },
                { "BadRequestCandidateEmailAlreadyExist","L'email inserita e' gia' associata ad un utente" },
                //TODO : Ricordarsi di cancellarle
                //Key per il trick BE
                { "CandidateNotSaved","Il candidato non e' stato salvato"},
                { "CandidateSuccessfullySet","Il candidato e' stato impostato correttamente"},

                //ContractProposal
                {"ContractNotFound","La proposta di contratto non è stata trovata" },
                { "ContractSuccessfullyCreated", "La proposta di contratto e' stata creata con successo" },
                { "ContractSuccessfullyFound", "La proposta di contratto e' stata trovata con successo" },
                { "ContractSuccessfullyUpdated", "La proposta di contratto e' stata modificata con successo" },
                { "ContractSuccessfullyDeleted", "La proposta di contratto e' stata eliminata con successo" },
                {"ContractAgeExceededForContractType","L'eta' e' superiore al limite previsto per questo tipo di contratto" },

                //PcReservation
                { "PcReservationNotFound","La prenotazione del PC non e' stata trovata"},
                { "ReservationDateTimeCheckFailed","Non e' possibile prenotare in questa fascia oraria" },
                { "PcReservationSuccessfullyCreated", "La prenotazione del PC è stata creata con successo" },
                {"PcReservationSuccessfullyUpdated", "La prenotazione del PC è stata aggiornata con successo" },
                {"PcReservationSuccessfullyFound","La prenotazione del PC è stata trovata con successo" },
                {"PcReservationSuccessfullyDeleted","La prenotazione del PC è stata cancellata con successo" },
                {"PcReservatinonSuccessfullyFound", "Le prenotazioni dei PC sono state trovate con successo"},

                //PersonalDetailsService
                {"PersonalDetailsSuccessfullyCreated","La sezione Dati Personali è stata creata con successo" },
                {"PersonalDetailsCandidateBadRequest","Il candidato scelto ha già una sezione Dati Personali associata" },
                {"PersonalDetailsNotFound","La sezione Dati Personali cercata non è stata trovata" },
                {"PersonalDetailsSuccessfullyFound","La sezione Dati Personali è stata trovata con successo"},
                {"PersonalDetailsSuccessfullyUpdated","La sezione Dati Personali è stata aggiornata con successo" },
                {"PersonalDetailsSuccessfullyDeleted","La sezione Dati Personali è stata eliminata con successo" },
                {"FileNotUploaded", "File non caricato" },
            
                 //HeadOfficeService
                {"HeadOfficeNotFound", "l'ufficio non è stato trovato" },
                {"HeadOfficeSuccessfullyFound", "Ufficio trovato con successo" },
                {"HeadOfficesSuccessfullyFound", "Uffici trovati con successo"},

                //LevelService
                {"LevelNotFound", "Il Livello non è stato trovato "},
                {"LevelsSuccessfullyFound", "I livelli sono stati trovati con successo"},
                {"LevelSuccessfullyFound","Il livello è stato trovato con successo" },

                //ContractProposalService
                {"ContractProposalSuccessfullyCreated","La proposta di Contratto è stata creata con successo" },
                {"ContractProposalNotFound","La proposta di Contratto non è stata trovata" },
                {"ContractProposalSuccesDelete","La proposta di Contratto è stata eliminata con successo" },
                {"ContractsProposalSuccessfullyFound","Le proposte di Contratto sono state trovae con successo" },
                {"ContractProposalSuccessfullyUpdated","La proposta di Contratto è stata Aggiornata con Successo" },
                {"ContractProposalHasForeignKeyZeroOrAlreadyCreated", "La proposta di contratto ha FK uguale a 0 o è già esistente" },

                //HiredContractProposalService
                {"HiredContractProposalSuccessfullyCreated","La proposta di Contratto di assunzione è stata creata con successo" },
                {"HiredContractProposalNotFound","La proposta di Contratto di assunzione non è stata trovata" },
                { "HiredContractProposalSuccessfullyFound", "La proposta di Contratto di assunzione è stata trovata con successo" },
                {"HiredContractProposalSuccessfullyUpdated","La proposta di Contratto di assunzione è stata Aggiornata con Successo" },
                {"HiredContractProposalSuccessfullyDelete","La proposta di Contratto di assunzione è stata eliminata con successo" },

                //StageContractProposalService
                {"ContractHasAlreadyAssociatedStage","La proposta di contratto ha già una sezione stage associata" },

                //EquipmentManagementService
                {"ContractHasAlreadyAssociatedEquipment","La proposta di contratto ha già una sezione Gestione Attrezzature associata" },
                {"EquipmentManagementSuccessfullyCreated","La sezione Gestione Attrezzature è stata creata con successo" },
                {"EquipmentNotFound","La sezione Gestione Attrezzature cercata non è stata trovata" },
                {"EquipmentManagementSuccessfullyUpdated","La sezione Gestione Attrezzature è stata aggiornata con successo" },
                {"EquipmentManagementSuccessfullyFound","La sezione Gestione Attrezzature è stata trovata con successo" },
                {"EquipmentManagementSuccessfullyDeleted","La sezione Gestione Attrezzature è stata eliminata con successo" }, 
                {"EquipmentManagementNotCreatedForDataCheck","Equipment non Creato per controllo data"},
                
                //CostCalculationService
                {"SuccessfullyCalculated","Il calcolo è andato a buon fine" }
        }; 

        public string GetValueByKey(string key)
        {
            string value;
            if (_statusDictionary.TryGetValue(key, out value))
            {
                return value;
            }
            else
            {
                // La chiave non è stata trovata nel dizionario
                throw new KeyNotFoundException("La chiave non è stata trovata nel dizionario");
            }
        }
        public Dictionary<string, string> StatusDictionary { get { return _statusDictionary; } }
    }
}
