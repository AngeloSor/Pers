﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.BLL.Models
{
    public class CostCalculation
    {
        public float? TotalSalaryCost { get; set; }
        public float? TotalOtherCost { get; set; }
        public float? TotalItCost { get; set; }
        public float? TotalOtherCost2 { get; set; }
        public float? ResourceCost { get; set; }
        public float? DailyFare { get; set; }
        public float? Margin { get; set; }
    }
}
