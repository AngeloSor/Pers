﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.BLL.Models
{
    public class PersonalDetailsDTO
    {
        public int Id { get; set; }
        public string Surname { get; set; }
        public string Name { get; set; }
        public string BirthPlace { get; set; }
        public string ResidenceAddress { get; set; }
        public string ResidenceCity { get; set; }
        public string DomicileAddress { get; set; }
        public string DomicileCity { get; set; }
        public string FiscalCode { get; set; }
        public string Institute { get; set; }
        public string? Notes1 { get; set; }
        public string? OriginCompany { get; set; }
        public string? Notes2 { get; set; }
        public EducationType Education { get; set; }
        public FacultyDegreeType FacultyDegree { get; set; }
        public PrevExperienceType PrevExperience { get; set; }
        public bool Certification { get; set; }
        public string? ShortDescription { get; set; }
        public bool HasSingleCitizenship { get; set; }
        public bool HasItalianCitizenship { get; set; }
        public string? Citizenship1 { get; set; }
        public string? Citizenship2 { get; set; }
        public bool HasAlreadyWorkedForAlten { get; set; }
        public DateTime DateBirth { get; set; }
        public int ResidenceZIPCode { get; set; }
        public int DomicileZIPCode { get; set; }
        public long Telephone { get; set; }
        public string Vote { get; set; }
        public string? CandidateEmail { get; set; }
        public int CandidateProfileId { get; set; }
  

        public enum EducationType
        {
            Diploma,
            LaureaTriennale,
            LaureaMagistrale,
            LaureaCicloUnico
        }
        public enum FacultyDegreeType
        {
            Umanistico,
            Tecnico_Scientifico
        }
        public enum PrevExperienceType
        {
            PrimaEsperienza,
            Experienced
        }

    }
}
