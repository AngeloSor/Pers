﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.BLL.Models
{
    public class FilesDTO
    {
        public int CandidateId { get; set; }
        public List<IFormFile> files { get; set; }
    }
}
