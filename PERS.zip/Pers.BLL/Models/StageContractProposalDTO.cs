﻿using Pers.DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.BLL.Models
{
    public class StageContractProposalDTO
    {
        public int Id { get; set; }
        public DateTime StartStage { get; set; }
        public DateTime EndStage { get; set; }
        public string DurationStage { get; set; }
        public string TutorStage1 { get; set; }
        public string TutorStage2 { get; set; }
        public string? TutorStage3 { get; set; }
        public string FunctionTutor1 { get; set; }
        public string FunctionTutor2 { get; set; }
        public string? FunctionTutor3 { get; set; }
        public string ProjectDescription { get; set; }
        public bool Billable { get; set; }
        public double? DailyCost { get; set; }
        public double RefundStage { get; set; }
        public bool ProportionateDaysPresence { get; set; }
        public bool HasSensitiveData { get; set; }
        public bool WorkstationAltenCompany { get; set; }
        public bool TravelAllowance { get; set; }
        public bool Guesthouse { get; set; }
        public string? Customer { get; set; }
        public string? AddressCustomer { get; set; }
        public bool? AdminSystemAlten { get; set; }

        public int ContractProposalId { get; set; }


    }
}
