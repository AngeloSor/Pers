﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.BLL.Models
{
    public class CandidateProfileDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Surname { get; set; }
        public string PhoneNumber { get; set; }
        public FormType StateForm { get; set; }
        public Condition CandidateCondition { get; set; }
        public string? Bm { get; set; }
		public int? BmHrId { get; set; }
        public Career StatusCareer { get; set; }
        public enum Condition
        {
            Candidate,
            Career
        }
        public enum FormType
        {
            NotSend,
            Send,
            Compiled
        }
        public enum Career
        { 
            CareerNotChosen,
            WaitingForValidation,
            Validated
        }



    }
}
