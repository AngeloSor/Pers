﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.BLL.Models
{
    public class FilePath
    {
        public Type type { get; set; }
        public string Path { get; set; }

        public enum Type 
        { 
            IdCard,
            HealthCard,
            ResidencePermit
        }
    }
}
