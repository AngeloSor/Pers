﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Pers.BLL.Models.EquipmentManagementDTO;


namespace Pers.BLL.Models
{
    public class PcReservationDTO
    {
        public int Id { get; set; }
        public DateTime Date { get; set; }
        public TimeOnly Time { get; set; }
        public LaptopType Laptop { get; set; }
        public string? LaptopModel { get; set; }
        public string OfficeVersion { get; set; }
        public bool AdminPermits { get; set; }
        public bool ProjectSTD { get; set; }
        public bool VSPro { get; set; }
        public bool VSEnterprise { get; set; }
        public bool? VisioSTD { get; set; }
        public string OS { get; set; }
        public string? Other { get; set; }
        public string? PCCustom { get; set; }
        public BaseLanguageType BaseLanguage { get; set; }
        public double? ApproximatePrice { get; set; }
        public string ClaimOnSite { get; set; }
        public int ContractProposalId { get; set; }
        public string? Candidate { get; set; }
        public int? BmHrId { get; set; }
       
    }
}
