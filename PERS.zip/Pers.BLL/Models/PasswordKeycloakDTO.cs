﻿using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.BLL.Models
{
    public class PasswordKeycloakDTO
    {
            [JsonProperty("type")]
            public string Type { get; set; } = "password";
            [JsonProperty("value")]
            public string Value { get; set; }
            [JsonProperty("temporary")]
            public bool Temporary { get; set; } = false;

    }
}
