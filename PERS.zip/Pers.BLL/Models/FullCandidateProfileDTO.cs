﻿using Pers.DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.BLL.Models
{
	public class FullCandidateProfileDTO : CandidateProfileDTO
	{
		
		public string? FiscalCode { get; set; }
		public string? BirthPlace { get; set; }
		public DateOnly? BirthDate { get; set; }
		public string? Gender { get; set; }
		public string? ResidentialAddress { get; set; }
		public int? ResidentialCap { get; set; }
		public string? ResidentialCity { get; set; }
		public string? LivingAddress { get; set; }
		public int? LivingCap { get; set; }
		public string? LivingCity { get; set; }
		public string? Degree { get; set; }
		public string? University { get; set; }
		public string? DegreeAddress { get; set; }
		public string? TypeDegreee { get; set; }
		public string? DegreeGrade { get; set; }
		public bool? IsFirstExperience { get; set; }
		public string? OriginCompany { get; set; }
		public bool? IsSingleNationality { get; set; }
		public bool? IsItalianNationality { get; set; }
		public string? Secondarynationality { get; set; }
		public string? Note1 { get; set; }
		public string? Note2 { get; set; }
        public string? LinkedinProfile { get; set; }
        public bool? IsUserContacted { get; set; }
		public bool? IsContractSend { get; set; }

	}
}
