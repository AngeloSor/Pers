﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.BLL.Models
{
    public class ContractDTO
    {
        public ContractProposalDTO ContractProposalDTO { get; set; }
        public HiredContractProposalDTO? HiredContractProposalDTO { get; set; }
        public StageContractProposalDTO? StageContractProposalDTO { get; set;}
        public EquipmentManagementDTO EquipmentManagementDTO { get; set; }
       
    }
}
