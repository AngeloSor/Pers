﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Hosting;
using Microsoft.Win32;
using Newtonsoft.Json;
using Org.BouncyCastle.Asn1.Mozilla;
using Pers.DAL.Context.Converter;
using Pers.DAL.Entities;

namespace Pers.DAL.Context
{
    public class PersDbContext : DbContext 
    {
        public PersDbContext(DbContextOptions<PersDbContext> options) : base(options)
        {
        }
        public DbSet<CandidateProfile>? Candidate { get; set; }
        public DbSet<ContractProposal>? ContractProposal { get; set; }
        public DbSet<BmHrProfile>? BmHr { get; set; }
        public DbSet<StageContractProposal>? StageContractProposal { get; set; }
        public DbSet<HiredContractProposal>? HiredContractProposals { get; set; }
        public DbSet<HeadOffice>? HeadOffice { get; set; }
        public DbSet<Level>? Level { get; set; }
        public DbSet<Level>? LevelCost { get; set; }
        public DbSet<PcReservation>? PcReservation { get; set; }
        public DbSet<PersonalDetails> PersonalDetails { get; set; }
        public DbSet<EquipmentManagement> EquipmentManagement { get; set; }
        public DbSet<CandidateFile> CandidateFile { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<BmHrProfile>(builder =>
            {
                builder.Property(x => x.BirthDate)
                    .HasConversion<DateOnlyConverter, DateOnlyComparer>();
            });
            modelBuilder.Entity<CandidateProfile>(builder =>
            {
                builder.Property(x => x.BirthDate)
                    .HasConversion<Converter.DateOnlyConverter, DateOnlyComparer>();
            });
            modelBuilder.Entity<PcReservation>(builder =>
            {
                builder.Property(x => x.Date)
                    .HasConversion<DateOnlyConverter, DateOnlyComparer>();
                builder.Property(x => x.Time)
                    .HasConversion<TimeOnlyConverter, TimeOnlyComparer>();
            });
            modelBuilder.Entity<EquipmentManagement>(builder =>
            {
                builder.Property(x => x.Time)
                    .HasConversion<TimeOnlyConverter, TimeOnlyComparer>();
            });

        }


    }
}
