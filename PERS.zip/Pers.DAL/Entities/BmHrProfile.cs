﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.DAL.Entities
{
	public class BmHrProfile
	{ 
		public int Id { get; set; }
		public string IdKeycloak { get; set; }
		public string Name { get; set; }
		public string Surname { get; set; }
		public string Email { get; set; }
		public string FiscalCode { get; set; }
		public DateOnly BirthDate { get; set; }
		public string Gender { get; set; }
		public string City { get; set; }
		public string Region { get; set; }
		public string Province { get; set; }
		public int ZipCode { get; set; }
		public string Address { get; set; }
        public string StreetNumber { get; set; }
        public GroupType Group { get; set; }
		public virtual IList<PcReservation> PcReservations { get; set; }
		public virtual IList<CandidateProfile>? Candidates { get; set; }

        public enum GroupType 
		{
			BM,
			HR,
			User,
			Admin
		}
	}
}

