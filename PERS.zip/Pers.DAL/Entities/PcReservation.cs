﻿using Org.BouncyCastle.Asn1.Mozilla;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.DAL.Entities
{
    public class PcReservation
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public DateOnly Date { get; set; }
        public TimeOnly Time { get; set; }
        public string IsLaptopNecessary { get; set; }
        public LaptopModelType LaptopModel { get; set; }
        public OSType Os { get; set; }
        public string? OtherOs { get; set; }
        public CustomPcType CustomPc { get; set; }
        public bool IsOfficeFullNecessary { get; set; }
        public string? OfficeFullMotivation { get; set; }
        public string? DetailsMotivation { get; set; }
        public bool AdministratorPermission { get; set; }
        public string? AdministratorPermissionMotivation { get; set; }
        public bool IsProjectStdNecessary { get; set; }
        public string? ProjectStdMotivation { get; set; }
        public bool IsVisualStudioProfessionalNecessary { get; set; }
        public string? VisualStudioProfessionaleMotivation { get; set; }
        public bool IsVisualStudioEnterpriseNecessary { get; set; }
        public string? VisualStudioEnterpriseMotivation { get; set; }
        public bool IsVisioStdNecessary { get; set; }
        public string? VisioStdMotivation { get; set; } 
        public LanguageType Language { get; set; }
        public bool? IsEmailSecNecessary { get; set; }
        public float? approximatePrice { get; set; }

		public int BmHrId { get; set; }
        public int CandidateId { get; set; }
		public virtual CandidateProfile Candidate { get; set; }
        public virtual BmHrProfile BmHr { get; set; }
        public enum LanguageType
        {
            Italian,
            English
        }

        public enum LaptopModelType
        {
            Base,
            i7,
			BM_TUM
		}
        public enum CustomPcType
        {   NoCustomPc,
            Laptop,
            Desktop
        }
        public enum OSType
        {
            Windows,
            NoOS,
            Other
        }

    }
}
