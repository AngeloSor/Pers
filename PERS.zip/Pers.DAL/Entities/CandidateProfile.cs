﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.DAL.Entities
{
	public class CandidateProfile
	{
		public int Id { get; set; }
		public string Email { get; set; }
		public string Name { get; set; }
		public string Surname { get; set; }
		public string PhoneNumber { get; set; }
		public string? FiscalCode { get; set; }
		public string? BirthPlace { get; set; }
		public DateOnly? BirthDate { get; set; }
		public string? ResidentialAddress { get; set; }
		public int? ResidentialCap { get; set; }
		public string? ResidentialCity { get; set; }
		public string? LivingAddress { get; set; }
		public int? LivingCap { get; set; }
		public string? LivingCity { get; set; }
		public string? Degree { get; set; }
		public string? University { get; set; }
		public string? DegreeAddress { get; set; }
		public string? TypeDegree { get; set; }
		public string? DegreeGrade { get; set; }
		public bool? IsFirstExperience { get; set; }
		public string? OriginCompany { get; set; }
		public bool? IsSingleNationality { get; set; }
		public bool? IsItalianNationality { get; set; }
		public string? Secondarynationality { get; set; }
		public string? Note1 { get; set; }
		public string? Note2 { get; set; }
		public string? LinkedinProfile { get; set; }
		public bool? IsUserContacted { get; set; }
		public bool? IsContractSend { get; set; }
		
		public int? BmHrId { get; set; }
		public GroupType StateForm { get; set; }
		public Condition CandidateCondition { get; set; }
		public Career StatusCareer { get; set; }
		
		public virtual PersonalDetails PersonalDetails { get; set; }
		public virtual BmHrProfile BmHr { get; set; }
        public virtual CandidateFile CandidateFile { get; set; }
        public virtual IList<PcReservation>? PcReservations { get; set; }
        public enum Condition
        {
            Candidate,
            Career
        }
        public enum GroupType
		{
			NotSend,
            Send,
            Compiled
        }
		public enum Career
		{
			CareerNotChosen,
			WaitingForValidation,
			Validated
		}



	}
}
