﻿using Org.BouncyCastle.Asn1.Mozilla;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.DAL.Entities
{
	public class HeadOffice
	{ 
		public int Id { get; set; }
		public string Name { get; set; }
		public string Address { get; set; }
		public float DailyCost { get; set; }

		public virtual IList<ContractProposal> ContractProposals { get; set; }
		public virtual IList<LevelCost> levelCosts { get; set; }
	}
}
