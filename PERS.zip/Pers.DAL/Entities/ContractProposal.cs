﻿ using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.DAL.Entities
{
    public class ContractProposal
    {
        public int Id { get; set; }
        public FunctionType Function { get; set; }
        public Contracts ContractType { get; set; }
        public bool? AlreadyStage { get; set; }
        public DateTime StartDateDet { get; set; }
        public DateTime EndDateDet { get; set; }
        public string? PossibilityOfReliefs { get; set; }
        public string? Duration { get; set; }
        public string? FailureToPayNotice { get; set; }
        public bool SmartWorking { get; set; }
        public int? SwDays { get; set; }
        public bool MobilityLayoffs { get; set; }
        public DateTime StartDate { get; set; }

        
        public HiredContractProposal HiredContractProposal { get; set; }
        public int HeadOfficeId {get; set;}
        public virtual HeadOffice HeadOffice { get; set; }
        public int BmHrId { get; set; }
        public virtual BmHrProfile BmHr { get; set; }
        public int CandidateId { get; set; }
        public virtual CandidateProfile Candidate { get; set; }
        public virtual EquipmentManagement EquipmentManagement { get; set; }
        public virtual StageContractProposal StageContractProposal { get; set; }
        public enum Contracts
        {
            TempoIndeterminato,
            TempoDeterminato,
            Apprendistato,
            StageCurriculare,
            Stage
           

        }
        public enum FunctionType
		{
			BM,
            Engineering,
            Staff

        }
	}
}
