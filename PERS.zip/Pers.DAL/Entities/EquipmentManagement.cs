﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.DAL.Entities
{
    public class EquipmentManagement
    {
        public int Id { get; set; }
        public DateTime Date { get; set; }
        public TimeOnly Time { get; set; }
        public LaptopType Laptop { get; set; }
        public string? LaptopModel { get; set; }
        public string OfficeVersion { get; set; }
        public bool AdminPermits { get; set; }
        public string OS { get; set; }
        public string? Other { get; set; }
        public bool? Telephone { get; set; }
        public bool? SIM { get; set; }
        public bool? Car { get; set; }
        public bool? FringeBenefitCar { get; set; }
        public bool? Badge { get; set; }
        public BaseLanguageType? BaseLanguage { get; set; }
        public double? ApproximatePrice { get; set; }
        public string ClaimOnSite { get; set; }
        public virtual ContractProposal ContractProposal { get; set; }
        public int ContractProposalId { get; set; }

        public enum BaseLanguageType
        {
            Inglese,
            Italiano
        }
        public enum LaptopType
        {
            Si,
            No
          
        }

    }
}
