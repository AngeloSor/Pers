﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.DAL.Entities
{
	public class LevelCost
	{
		public int Id { get; set; }
		public float MonthlyMinimumSalary { get; set; }
		public float AnnualMinimumWage { get; set; }
		public int HeadOfficeId { get; set; }

	}
}
