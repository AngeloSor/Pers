﻿using Org.BouncyCastle.Asn1.Mozilla;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.DAL.Entities
{
    public class CandidateFile
    {
        public int Id { get; set; }
        public string IDCard { get; set; }
        public string HealthCard { get; set; }
        public string? ResidencePermit { get; set; }
        public int CandidateId { get; set; }
        public virtual CandidateProfile Candidate { get; set; }

    }
}
