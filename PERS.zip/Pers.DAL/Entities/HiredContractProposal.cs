﻿using Org.BouncyCastle.Asn1.Mozilla;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Pers.DAL.Entities
{
    public class HiredContractProposal
    {

        public int Id { get; set; }
        public StatusType Status { get; set; }
        public string? Client { get; set; }
        public bool IsAerospaceDefence { get; set; }
        public ClassifiedProjectType? ClassifiedProject { get; set; }
        public string? JobDescription { get; set; }
        public string EmailTutor1 { get; set; }
        public string EmailTutor2 { get; set; }
        public string TutorFunction { get; set; }
        public bool HasSensitiveData { get; set; }
        public string TrialPeriod { get; set; }
        public double Ral { get; set; }
        public double? AnnualMinimumWage { get; set; }
        public double GrossMonthlySalary
        { get; set; }
        public double? SuperMinimumAbsorbable { get; set; }
        public BonusType Bonus { get; set; }
        public double? BonusValue { get; set; }
        public string Ticket { get; set; }
        public int? ApproximateDailyPrice { get; set; }
        public bool TraveAllowance { get; set; }
        public float? Amount { get; set; }
        public bool WorkstationAltenCompany { get; set; }
        public string? Customer { get; set; }
        public string? AddressCustomer { get; set; }
        public bool Guesthouse { get; set; }
        public float? ApproximateMonthlyPrice { get; set; }
        public float DailyCost { get; set; }
        public string? Other { get; set; }
        public string? Notes { get; set; }


        public enum StatusType
        {
            OnProject,
            DirectHiring
        }
        public enum ClassifiedProjectType
        {
            NonClassificato,
            Riservato,
            Riservatissimo,
            Segreto
        }
        public enum BonusType
        {
            Nessuno,
            WelcomeBonus,
            BonusStrutturato,
            RetentionBonus
        }

        public int LevelId { get; set; }
        public virtual Level Level { get; set; }
        public int ContractProposalId { get; set; }
        public virtual ContractProposal ContractProposal { get; set; }

    }
}
