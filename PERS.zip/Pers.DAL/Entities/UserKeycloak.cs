﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.DAL.Entities
{
    public class UserKeycloak
    {
        [JsonProperty("id")]
        public string? id;
        [JsonProperty("createdTimestamp")]
        public int createdTimestamp;
        [JsonProperty("username")]
        public string username;
        [JsonProperty("enabled")]
        public bool enabled = true;
        [JsonProperty("totp")]
        public bool totp = true;
        [JsonProperty("emailVerified")]
        public bool emailVerified = true;
        [JsonProperty("firstName")]
        public string firstName;
        [JsonProperty("lastName")]
        public string lastName;
        [JsonProperty("email")]
        public string email;
        [JsonProperty("disableableCredentialTypes")]
        public int[] disableableCredentialTypes;
        [JsonProperty("requiredActions")]
        public int[] requiredActions;
        [JsonProperty("notBefore")]
        public int notBefore = 0;
        [JsonProperty("access")]
        public Access access = new Access { impersonate = true, manage = true, view = true, mapRoles = true, manageGroupMembership = true };
        
    }
    public class Access 
    {
        //[JsonProperty("manageGroupMembership")]
        public bool manageGroupMembership;
        //[JsonProperty("view")]
        public bool view;
        //[JsonProperty("mapRoles")]
        public bool mapRoles;
        //[JsonProperty("impersonate")]
        public bool impersonate;
        //[JsonProperty("manage")]
        public bool manage;
    }
}
