﻿using Microsoft.EntityFrameworkCore;
using Pers.DAL.Context;
using Pers.DAL.Entities;
using Pers.DAL.IRepositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.DAL.Repositories
{
    public class LevelRepository :AbstractRepository<Level>,  ILevelRepository
    {
        public LevelRepository(PersDbContext context): base(context) 
        {
        }

        public override  Task<int> Create(Level user)
        {
            throw new NotImplementedException();
        }

        public override Task<bool> Delete(Level user)
        {
            throw new NotImplementedException();
        }

        public override async Task<Level> Find(int id)
        {
            var level = await _context.Level.FirstOrDefaultAsync(lev => lev.Id == id);
            return level;
        }

        public override async Task<List<Level>> GetAll()
        {
            var levels = await _context.Level.ToListAsync();
            return levels;
        }

        public override Task<Level> Update(Level user)
        {
            throw new NotImplementedException();
        }
    }
}
