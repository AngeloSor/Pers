﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Internal;
using Pers.DAL.Context;
using Pers.DAL.Entities;
using Pers.DAL.IRepositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;


namespace Pers.DAL.Repositories
{
    public class StageContractProposalRepository : AbstractRepository<StageContractProposal>, IStageContractProposalRepository 
    {
        public StageContractProposalRepository(PersDbContext context) : base(context) 
        {

        }
        public async Task<bool> ContractExist(int id)
        {
            return await _context.StageContractProposal.AnyAsync(stage => stage.Id == id);
        }

        public async Task<bool> ContractAlreadyAssociated(int contractId)
        {
            return await _context.StageContractProposal.AnyAsync(stage=>stage.ContractProposalId == contractId);
        }

        public override async Task<int> Create(StageContractProposal stageContractProposal)
        {
            _context.StageContractProposal.Add(stageContractProposal);
            await _context.SaveChangesAsync();
            return stageContractProposal.Id;
        }

        public override async Task<bool> Delete(StageContractProposal stageContractProposal)
        {
            try
            {
                _context.Entry(stageContractProposal).State = EntityState.Deleted;
                return await this.Save();

            }
            catch (Exception ex) 
            {
                throw ex;
            }
        }

        public override Task<StageContractProposal> Find(int id)
        {
            var stageContractProposalToFind = _context.StageContractProposal.FirstOrDefaultAsync(stageContract => stageContract.Id == id);
            if (stageContractProposalToFind is null) return null;
            return stageContractProposalToFind;
        }

        public async Task<StageContractProposal> FindContract(int candidateId)
        {
            var query = _context.ContractProposal.Where(contract => contract.CandidateId == candidateId)
           .Join(_context.StageContractProposal, contract => contract.Id, stage => stage.ContractProposalId, (contract, stage) => new { Contract = contract, Stage = stage })
           .Where(joinresult => joinresult.Stage.ContractProposalId == joinresult.Contract.Id)
           .Select(joinresult => joinresult.Stage);
            var response = await query.FirstOrDefaultAsync();
            return response;
        }

        public override async Task<List<StageContractProposal>> GetAll()
        {
            var stageContractList = await _context.StageContractProposal.ToListAsync();
            return stageContractList;
        }

        public override async Task<StageContractProposal> Update(StageContractProposal stageContractProposal)
        {
            try
            {
                _context.Entry(stageContractProposal).State = EntityState.Modified;
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return stageContractProposal;
        }

		private async Task<bool> Save()
		{
			var saved = await _context.SaveChangesAsync();
			return saved >= 0;
		}

	}
}
