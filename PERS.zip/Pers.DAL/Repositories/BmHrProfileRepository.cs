﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pers.DAL.IRepositories;
using Pers.DAL.Context;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Microsoft.Win32;
using Pers.DAL.Entities;

namespace Pers.DAL.Repositories
{
	public class BmHrProfileRepository : AbstractRepository<BmHrProfile> , IBmHrProfileRepository
	{
		public BmHrProfileRepository(PersDbContext context) : base(context)
		{
		}
		public override async Task<int> Create(BmHrProfile bmhrProfile)
		{
            _context.BmHr.Add(bmhrProfile);
            await _context.SaveChangesAsync();
			return bmhrProfile.Id;
        }

		public override async Task<bool> Delete(BmHrProfile bmhrProfile)
		{

			try 
			{ 
				_context.Entry(bmhrProfile).State = EntityState.Deleted;
                return await this.Save();
            }
			catch (Exception ex)
			{
				throw ex;
			}
			
		}

		public override async Task<BmHrProfile> Find(int id)
		{
			var bmhrToFind = await _context.BmHr.FirstOrDefaultAsync(bmhr => bmhr.Id == id);
			if (bmhrToFind is null) return null;
			return bmhrToFind;
			
		}


        public async Task<BmHrProfile> Find(string email)
        {
            var userToFind = await _context.BmHr.FirstOrDefaultAsync(user => user.Email == email);
            if (userToFind is null) return userToFind;
            return userToFind;
        }
        public override async Task<List<BmHrProfile>> GetAll()
        {
            var bmhr = await _context.BmHr.ToListAsync();
			return bmhr;

        }
		public async override Task<BmHrProfile> Update(BmHrProfile bmhrProfile)
		{

            try
            {
                _context.Entry(bmhrProfile).State = EntityState.Modified;
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return bmhrProfile;
        
		}

		private async Task<bool> Save()
		{
			var saved = await _context.SaveChangesAsync();
			return saved >= 0;
		}

		public async Task<bool> UserExists(int id)
		{
			return await _context.BmHr.AnyAsync(bmhr => bmhr.Id == id);
		}
        public async Task<bool> UserExists(string email)
        {
            return await _context.BmHr.AnyAsync(user => user.Email == email);
        }
    }
}
