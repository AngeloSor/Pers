﻿using Microsoft.EntityFrameworkCore;
using Pers.DAL.Context;
using Pers.DAL.Entities;
using Pers.DAL.IRepositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.DAL.Repositories
{
    public class HiredContractProposalRepository : AbstractRepository<HiredContractProposal>, IHiredContractProposalRepository
    {
        public HiredContractProposalRepository(PersDbContext context) : base(context)
        {
        }

        public async Task<bool> ContractExist(int id)
        {
            return await _context.HiredContractProposals.AnyAsync(contract => contract.Id == id);
      
        }

        public override async Task<int> Create(HiredContractProposal hiredContractProposal)
        {
            _context.HiredContractProposals.Add(hiredContractProposal);
            await _context.SaveChangesAsync();
            return hiredContractProposal.Id;
        }

        public override async Task<bool> Delete(HiredContractProposal hiredContractProposal)
        {
            try
            {
                _context.Entry(hiredContractProposal).State = EntityState.Deleted;
                return await this.Save();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public override Task<HiredContractProposal> Find(int id)
        {
            var hiredContractProposalToFind = _context.HiredContractProposals.FirstOrDefaultAsync(hiredContract => hiredContract.Id == id);
            return hiredContractProposalToFind;
        }

        public async Task<bool> ContractAlreadyAssociated(int contractId)
        {
            return await _context.HiredContractProposals.AnyAsync(hired => hired.ContractProposalId == contractId);
        }

        public async Task<bool> ContractAlreadyAssociatedWithIdControl(int Id, int contractId)
        {
            return await _context.HiredContractProposals.Where(hired => hired.Id == Id).AnyAsync(hired => hired.ContractProposalId == contractId);
        }

        public override async Task<List<HiredContractProposal>> GetAll()
        {
            var hiredContractList = await _context.HiredContractProposals.ToListAsync();
            return hiredContractList;
        }

        public override async Task<HiredContractProposal> Update(HiredContractProposal hiredContractProposal)
        {

            try
            {
                _context.Entry(hiredContractProposal).State = EntityState.Modified;
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return hiredContractProposal;

        }
        
        private async Task<bool> Save()
        {
            var saved = await _context.SaveChangesAsync();
            return saved >= 0;
        }
    }
}
