﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Pers.DAL.Context;
using Pers.DAL.Entities;
using Pers.DAL.IRepositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.DAL.Repositories
{
    public class PcReservationRepository : AbstractRepository<PcReservation> , IPcReservationRepository
    {
        public PcReservationRepository(PersDbContext context) : base(context)
        { 
        }

        public override async Task<int> Create(PcReservation pcReservation)
        {
            _context.Add(pcReservation);
            await _context.SaveChangesAsync();
            return pcReservation.Id;
        }

        public override async Task<bool> Delete(PcReservation pcReservation)
        {
            try
            {
                _context.Entry(pcReservation).State = EntityState.Deleted;
                await _context.SaveChangesAsync();
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public override async Task<PcReservation> Find(int id)
        {
            var pcReservationToFind = await _context.PcReservation.FirstOrDefaultAsync(reservation => reservation.Id == id);
            if (pcReservationToFind is null) return null;
            return pcReservationToFind;
        }

        public override async Task<List<PcReservation>> GetAll()
        {
            var allPcReservation = await _context.PcReservation.ToListAsync();
            if (allPcReservation is null) return null;
            return allPcReservation;
        }
        public async Task<bool> DateCheck(DateOnly date)
        {
           var numberOfReservation = await _context.PcReservation.CountAsync(reservation => reservation.Date == date);
           if (numberOfReservation >= 10) return false;
           return true;

        }
        public async Task<bool> TimeCheck(TimeOnly time)
        {
            var numberOfReservation = await _context.PcReservation.CountAsync(reservation => reservation.Time == time);
            if(numberOfReservation >= 3) return false;
            return true;
        }

        public Task<bool> PcReservationExist(int id)
        {
            throw new NotImplementedException();
        }

        public override async Task<PcReservation> Update(PcReservation pcReservation)
        {
            try
            {
                _context.Entry(pcReservation).State = EntityState.Modified;
                await _context.SaveChangesAsync();
            }
            catch(Exception ex)
            {
                throw ex;
            }
                return pcReservation;
        }
    }
}
