﻿using Microsoft.EntityFrameworkCore;
using Pers.DAL.Context;
using Pers.DAL.Entities;
using Pers.DAL.IRepositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.DAL.Repositories
{
    public class PersonalDetailsRepository : AbstractRepository<PersonalDetails> , IPersonalDetailsRepository
    {
        public PersonalDetailsRepository(PersDbContext context) : base(context)
        {
        }

        public override async Task<int> Create(PersonalDetails details)
        {
            _context.PersonalDetails.Add(details);
            await _context.SaveChangesAsync();
            return details.Id;
        }

        public override async Task<PersonalDetails> Find(int id)
        {
            return await _context.PersonalDetails.FirstOrDefaultAsync(details => details.Id == id);
        }

        public override async Task<PersonalDetails> Update(PersonalDetails details)
        {

            try
            {
                _context.Entry(details).State = EntityState.Modified;
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return details;
        }
        public override async Task<bool> Delete(PersonalDetails details)
        {
            try
            {
                _context.Entry(details).State = EntityState.Deleted;
                return await this.Save();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<bool> DetailsExists(int id)
        {
            return await _context.PersonalDetails.AnyAsync(details => details.Id == id);
        }
        public async Task<bool> CandidateAssociatedExists(int candidateId)
        {
            return await _context.PersonalDetails.AnyAsync(details => details.CandidateProfileId == candidateId);
        }

        public async Task<PersonalDetails?> FindByCandidate(int candidateId)
        {
            return await _context.PersonalDetails.Include(x => x.CandidateProfile).FirstOrDefaultAsync(details => details.CandidateProfileId == candidateId);
        }


        public async override Task<List<PersonalDetails>> GetAll()
        {
            var allDetails = await _context.PersonalDetails.ToListAsync();
            return (allDetails is null) ? null : allDetails;
        }
        private async Task<bool> Save()
        {
            var saved = await _context.SaveChangesAsync();
            return saved >= 0;
        }
    }
}
