﻿using Microsoft.AspNetCore.Routing.Constraints;
using Microsoft.EntityFrameworkCore;
using Pers.DAL.Context;
using Pers.DAL.Entities;
using Pers.DAL.IRepositories;
using System.ComponentModel;
using System.Diagnostics;

namespace Pers.DAL.Repositories
{
    public class CandidateProfileRepositoy : AbstractRepository<CandidateProfile>, ICandidateProfileRepository
    {
        public CandidateProfileRepositoy(PersDbContext context) : base(context)
        {
        }

        public override async Task<int> Create(CandidateProfile candidateProfile)
        {
            candidateProfile.CandidateCondition = 0;
            _context.Candidate.Add(candidateProfile);
            await _context.SaveChangesAsync();
            return candidateProfile.Id;
        }

        public override async Task<bool> Delete(CandidateProfile candidateProfile)
        {
            try
            {
                _context.Entry(candidateProfile).State = EntityState.Deleted;
                return await this.Save();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public override async Task<CandidateProfile> Find(int id)
        {
            var candidateToFind = await _context.Candidate.FirstOrDefaultAsync(cand => cand.Id == id);
            return (candidateToFind is null) ? null : candidateToFind;
        }
        public override async Task<List<CandidateProfile>> GetAll()
        {
            var candidate = await _context.Candidate.Include(x => x.BmHr).ToListAsync();
            return candidate;
        }
        
        public async override Task<CandidateProfile> Update(CandidateProfile candidateProfile)
        {
            try
            {
                _context.Entry(candidateProfile).State = EntityState.Modified;
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return candidateProfile;
        }
        private async Task<bool> Save()
        {
            var saved = await _context.SaveChangesAsync();
            return saved >= 0;
        }
        public async Task<bool> CandidateExists(int id)
        {
            return await _context.Candidate.AnyAsync(candidate => candidate.Id == id);
        }
        public async Task<bool> CandidateExists(string email)
        {
            return await _context.Candidate.AnyAsync(candidate => candidate.Email == email);
        }
        public async Task<bool> SetFormToSend(CandidateProfile candidateProfile)
        {

            candidateProfile.StateForm = CandidateProfile.GroupType.Send;
            _context.Update(candidateProfile);
            return await this.Save();
        }
        public async Task<bool> SetFormToCompiled(CandidateProfile candidateProfile)
        {

            candidateProfile.StateForm = CandidateProfile.GroupType.Compiled;
            _context.Update(candidateProfile);
            return await this.Save();
        }

        public async Task<List<CandidateProfile>> GetCandidateBM(int bmId)
        {
            return await _context.Candidate.Where(cand => cand.BmHrId == bmId).ToListAsync();
        }
        public async Task<List<CandidateProfile>> GetCandidateWithAcceptedForm()
        {
            return await _context.Candidate.Where(cand => cand.CandidateCondition == CandidateProfile.Condition.Career).ToListAsync();
        }

        public async Task<bool> SetCareer(CandidateProfile candidateProfile)
        {
            if (candidateProfile.CandidateCondition == CandidateProfile.Condition.Career) candidateProfile.CandidateCondition = CandidateProfile.Condition.Candidate;
            else candidateProfile.CandidateCondition = CandidateProfile.Condition.Career;
            _context.Update(candidateProfile);
            return await this.Save();
        }
    }
}
