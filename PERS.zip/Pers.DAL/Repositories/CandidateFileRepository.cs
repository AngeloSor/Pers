﻿using Microsoft.EntityFrameworkCore;
using Pers.DAL.Context;
using Pers.DAL.Entities;
using Pers.DAL.IRepositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.DAL.Repositories
{
    public class CandidateFileRepository : AbstractRepository<CandidateFile>, ICandidateFileRepository
    {
        public CandidateFileRepository(PersDbContext context) : base(context)
        {
        }

        public async override Task<int> Create(CandidateFile file)
        {
            _context.CandidateFile.Add(file);
            await _context.SaveChangesAsync();
            return file.Id;
        }

        public async override Task<bool> Delete(CandidateFile file)
        {
            try
            {
                _context.Entry(file).State = EntityState.Deleted;
                return await this.Save();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public override Task<CandidateFile> Find(int id)
        {
            try
            {
                var candFile = _context.CandidateFile.FirstOrDefaultAsync(x => x.Id == id);
                return candFile;
            }
            catch (Exception ex) 
            {
                throw ex;
            }
        }

        public async Task<CandidateFile> FindByCandidateId(int candidateId)
        {
            var candiFileToSend = await _context.CandidateFile.FirstOrDefaultAsync(x => x.CandidateId == candidateId);
            return candiFileToSend;
        }

        public override Task<List<CandidateFile>> GetAll()
        {
            throw new NotImplementedException();
        }

        public override Task<CandidateFile> Update(CandidateFile user)
        {
            throw new NotImplementedException();
        }
        private async Task<bool> Save()
        {
            var saved = await _context.SaveChangesAsync();
            return saved >= 0;
        }
    }
}
