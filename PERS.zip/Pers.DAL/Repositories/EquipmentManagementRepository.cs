﻿using Microsoft.EntityFrameworkCore;
using Pers.DAL.Context;
using Pers.DAL.Entities;
using Pers.DAL.IRepositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.DAL.Repositories
{
    public class EquipmentManagementRepository : AbstractRepository<EquipmentManagement>, IEquipmentManagementRepository
    {
        public EquipmentManagementRepository(PersDbContext context) : base(context)
        {

        }
        public override async Task<int> Create(EquipmentManagement equipment)
        {
            _context.EquipmentManagement.Add(equipment);
            await _context.SaveChangesAsync();
            return equipment.Id;
        }

        public override async Task<bool> Delete(EquipmentManagement equipment)
        {
            try
            {
                _context.Entry(equipment).State = EntityState.Deleted;
                return await this.Save();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<bool> ContractAlreadyAssociated(int contractId)
        {
            return await _context.EquipmentManagement.AnyAsync(equipment => equipment.ContractProposalId == contractId);
        }
        public async Task<bool> ContractAlreadyAssociatedWithIdControl(int Id,int contractId)
        {
            return await _context.EquipmentManagement.Where(equipment=>equipment.Id==Id).AnyAsync(equipment => equipment.ContractProposalId == contractId);
        }
        public async Task<bool> EquipmentExists(int id)
        {
            return await _context.EquipmentManagement.AnyAsync(equipment => equipment.Id == id);
        }

        public override Task<EquipmentManagement> Find(int id)
        {
            var equipmentToFind = _context.EquipmentManagement.Include(x => x.ContractProposal).ThenInclude(x => x.Candidate).AsNoTracking().FirstOrDefaultAsync(equipment => equipment.Id == id);
            if (equipmentToFind is null) return null;
            return equipmentToFind;
        }

        public override async Task<List<EquipmentManagement>> GetAll()
        {
            var equipmentToList = await _context.EquipmentManagement.Include(x => x.ContractProposal).ThenInclude(y => y.Candidate).ToListAsync();
            return equipmentToList;
        }

        public override async Task<EquipmentManagement> Update(EquipmentManagement equipment)
        {
             _context.Update(equipment);
            await _context.SaveChangesAsync();
            return equipment;
        }

        private async Task<bool> Save()
        {
            var saved = await _context.SaveChangesAsync();
            return saved >= 0;
        }

        public async Task<bool> DataCheck(DateTime date, TimeOnly time)
        {
            var numberOfReservation = await _context.EquipmentManagement.CountAsync(res => res.Date == date.Date);
            if(numberOfReservation >= 12) return false;
            var numberOfResTime = await _context.EquipmentManagement.CountAsync(res => res.Time == time);
            if(numberOfResTime >= 3) return false;
            return true;
        }
    
    }
}
