﻿using Pers.DAL.IRepositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pers.DAL.Context;
using Microsoft.EntityFrameworkCore;

namespace Pers.DAL.Repositories
{
	public abstract class AbstractRepository<T> : IRepository<T>
	{
		protected readonly PersDbContext _context;
		public AbstractRepository(PersDbContext context)
		{
			_context = context;
		}
		public abstract Task<int> Create(T user);
		public abstract Task<bool> Delete(T user);
		public abstract Task<T> Update(T user);
		public abstract Task<T> Find(int id);
		public abstract Task<List<T>> GetAll();
        protected int GetUserIdFromKeycloakId(string keycloakId)
		{
			return _context.BmHr.Where(r => r.IdKeycloak == keycloakId).Select(r => r.Id).FirstOrDefaultAsync().Result;
		}
	}
}
