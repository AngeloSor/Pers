﻿using Microsoft.EntityFrameworkCore;
using Pers.DAL.Context;
using Pers.DAL.Entities;
using Pers.DAL.IRepositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.DAL.Repositories
{
    public class HeadOfficeRepository : AbstractRepository<HeadOffice> , IHeadOfficeRepository
    {
        public HeadOfficeRepository(PersDbContext context) : base(context) 
        { 
        }

        public override async Task<int> Create(HeadOffice headOffice)
        {
            _context.HeadOffice.Add(headOffice);
            await _context.SaveChangesAsync();
            return headOffice.Id;
        }

        public override Task<bool> Delete(HeadOffice user)
        {
            throw new NotImplementedException();
        }

        public override async Task<HeadOffice> Find(int id)
        {
            var headOffice = await _context.HeadOffice.FirstOrDefaultAsync(ho => ho.Id == id);
            return headOffice;
        }

        public override async Task<List<HeadOffice>> GetAll()
        {
            var headOffices = await _context.HeadOffice.ToListAsync();
            return headOffices;
        }

        public override Task<HeadOffice> Update(HeadOffice user)
        {
            throw new NotImplementedException();
        }
    }
}
