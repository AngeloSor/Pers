﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Pers.DAL.Context;
using Pers.DAL.Entities;
using Pers.DAL.IRepositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;
using static Pers.DAL.Entities.CandidateProfile;

namespace Pers.DAL.Repositories
{
    public class ContractProposalRepository : AbstractRepository<ContractProposal>, IContractProposalRepository
    {
        private readonly IMapper _mapper;
        public ContractProposalRepository(PersDbContext context) : base(context)
        {
           
        }

        public override async Task<int> Create(ContractProposal contractProposal)
        {
            _context.ContractProposal.Add(contractProposal);
            await _context.SaveChangesAsync();
            return contractProposal.Id;
        }

        public override async Task<bool> Delete(ContractProposal contractProposal)
        {

            try
            {
                _context.Entry(contractProposal).State = EntityState.Deleted;
                return await this.Save();
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        public async Task<bool> HasAlreadyContract(int candidateId)
        {
            var contract = await _context.ContractProposal.FirstOrDefaultAsync(contract => contract.CandidateId == candidateId);
            if (contract is null) return false;
            return true;
        }
        public async override Task<ContractProposal> Find(int id)
        {
            var contractToFind = await _context.ContractProposal.Include(x => x.HiredContractProposal).Include(x => x.StageContractProposal).Include( x => x.EquipmentManagement).FirstOrDefaultAsync(contract => contract.Id == id);
            return contractToFind;

        }

        public override async Task<ContractProposal> Update(ContractProposal contractProposal)
        {
            try
            {
                _context.Entry(contractProposal).State = EntityState.Modified;
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return contractProposal;
        }
        
        private async Task<bool> Save()
        {
            var saved = await _context.SaveChangesAsync();
            return saved >= 0;
        }

        public async override Task<List<ContractProposal>> GetAll()
        {
            return await _context.ContractProposal.ToListAsync();
        }

       
    }
}
