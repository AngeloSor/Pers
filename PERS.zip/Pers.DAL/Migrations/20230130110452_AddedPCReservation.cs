﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Pers.DAL.Migrations
{
    public partial class AddedPCReservation : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_HeadOffice_LevelCost_LevelCostId",
                table: "HeadOffice");

            migrationBuilder.DropForeignKey(
                name: "FK_Level_LevelCost_LevelCostId",
                table: "Level");

            migrationBuilder.DropIndex(
                name: "IX_Level_LevelCostId",
                table: "Level");

            migrationBuilder.DropIndex(
                name: "IX_HeadOffice_LevelCostId",
                table: "HeadOffice");

            migrationBuilder.DropColumn(
                name: "LevelCostId",
                table: "Level");

            migrationBuilder.DropColumn(
                name: "LevelCostId",
                table: "HeadOffice");

            migrationBuilder.AddColumn<int>(
                name: "PcReservationId",
                table: "Candidate",
                type: "int",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "PcReservation",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Time = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsLaptopNecessary = table.Column<bool>(type: "bit", nullable: false),
                    PcNoCustom = table.Column<int>(type: "int", nullable: false),
                    Os = table.Column<int>(type: "int", nullable: false),
                    OtherOs = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CustomPc = table.Column<int>(type: "int", nullable: false),
                    IsOfficeFUllNecessary = table.Column<bool>(type: "bit", nullable: false),
                    OfficeFullMotivation = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AdministratorPermission = table.Column<bool>(type: "bit", nullable: false),
                    AdministratorPermissionMOtivation = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IsProjectStdNecessary = table.Column<bool>(type: "bit", nullable: false),
                    ProjectStdMotivation = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IsVisualStudioProfessionalNecessary = table.Column<bool>(type: "bit", nullable: false),
                    VisualStudioProfessionaleMotivation = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IsVisualStudioEnterpriseNecessary = table.Column<bool>(type: "bit", nullable: false),
                    VisualStudioEnterpriseMOtivation = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IsVisioStdNecessary = table.Column<bool>(type: "bit", nullable: false),
                    VisioStdMotivation = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Language = table.Column<int>(type: "int", nullable: false),
                    IsEmailSecNecessary = table.Column<bool>(type: "bit", nullable: true),
                    BmHrId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PcReservation", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PcReservation_BmHr_BmHrId",
                        column: x => x.BmHrId,
                        principalTable: "BmHr",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_LevelCost_HeadOfficeId",
                table: "LevelCost",
                column: "HeadOfficeId");

            migrationBuilder.CreateIndex(
                name: "IX_LevelCost_LevelId",
                table: "LevelCost",
                column: "LevelId");

            migrationBuilder.CreateIndex(
                name: "IX_Candidate_PcReservationId",
                table: "Candidate",
                column: "PcReservationId",
                unique: true,
                filter: "[PcReservationId] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_PcReservation_BmHrId",
                table: "PcReservation",
                column: "BmHrId");

            migrationBuilder.AddForeignKey(
                name: "FK_Candidate_PcReservation_PcReservationId",
                table: "Candidate",
                column: "PcReservationId",
                principalTable: "PcReservation",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_LevelCost_HeadOffice_HeadOfficeId",
                table: "LevelCost",
                column: "HeadOfficeId",
                principalTable: "HeadOffice",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_LevelCost_Level_LevelId",
                table: "LevelCost",
                column: "LevelId",
                principalTable: "Level",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Candidate_PcReservation_PcReservationId",
                table: "Candidate");

            migrationBuilder.DropForeignKey(
                name: "FK_LevelCost_HeadOffice_HeadOfficeId",
                table: "LevelCost");

            migrationBuilder.DropForeignKey(
                name: "FK_LevelCost_Level_LevelId",
                table: "LevelCost");

            migrationBuilder.DropTable(
                name: "PcReservation");

            migrationBuilder.DropIndex(
                name: "IX_LevelCost_HeadOfficeId",
                table: "LevelCost");

            migrationBuilder.DropIndex(
                name: "IX_LevelCost_LevelId",
                table: "LevelCost");

            migrationBuilder.DropIndex(
                name: "IX_Candidate_PcReservationId",
                table: "Candidate");

            migrationBuilder.DropColumn(
                name: "PcReservationId",
                table: "Candidate");

            migrationBuilder.AddColumn<int>(
                name: "LevelCostId",
                table: "Level",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "LevelCostId",
                table: "HeadOffice",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Level_LevelCostId",
                table: "Level",
                column: "LevelCostId");

            migrationBuilder.CreateIndex(
                name: "IX_HeadOffice_LevelCostId",
                table: "HeadOffice",
                column: "LevelCostId");

            migrationBuilder.AddForeignKey(
                name: "FK_HeadOffice_LevelCost_LevelCostId",
                table: "HeadOffice",
                column: "LevelCostId",
                principalTable: "LevelCost",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Level_LevelCost_LevelCostId",
                table: "Level",
                column: "LevelCostId",
                principalTable: "LevelCost",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
