﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Pers.DAL.Migrations
{
    public partial class HRBM : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ContractProposal_User_UserId",
                table: "ContractProposal");

            migrationBuilder.DropPrimaryKey(
                name: "PK_User",
                table: "User");

            migrationBuilder.RenameTable(
                name: "User",
                newName: "BmHr");

            migrationBuilder.AddPrimaryKey(
                name: "PK_BmHr",
                table: "BmHr",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ContractProposal_BmHr_UserId",
                table: "ContractProposal",
                column: "UserId",
                principalTable: "BmHr",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ContractProposal_BmHr_UserId",
                table: "ContractProposal");

            migrationBuilder.DropPrimaryKey(
                name: "PK_BmHr",
                table: "BmHr");

            migrationBuilder.RenameTable(
                name: "BmHr",
                newName: "User");

            migrationBuilder.AddPrimaryKey(
                name: "PK_User",
                table: "User",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ContractProposal_User_UserId",
                table: "ContractProposal",
                column: "UserId",
                principalTable: "User",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
