﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Pers.DAL.Migrations
{
    public partial class UpdateContractLogic : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ContractProposal");

            migrationBuilder.AddColumn<int>(
                name: "HiredContractProposalId",
                table: "Candidate",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "StageContractProposalId",
                table: "Candidate",
                type: "int",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "LevelCost",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MonthlyMinimumSalary = table.Column<float>(type: "real", nullable: false),
                    AnnualMinimumWage = table.Column<float>(type: "real", nullable: false),
                    HeadOfficeId = table.Column<int>(type: "int", nullable: false),
                    LevelId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LevelCost", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "HeadOffice",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DailyCost = table.Column<float>(type: "real", nullable: false),
                    LevelCostId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HeadOffice", x => x.Id);
                    table.ForeignKey(
                        name: "FK_HeadOffice_LevelCost_LevelCostId",
                        column: x => x.LevelCostId,
                        principalTable: "LevelCost",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "Level",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LevelCostId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Level", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Level_LevelCost_LevelCostId",
                        column: x => x.LevelCostId,
                        principalTable: "LevelCost",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "HiredContractProposals",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AlreadyStage = table.Column<bool>(type: "bit", nullable: false),
                    PossibilityOfReliefs = table.Column<bool>(type: "bit", nullable: true),
                    Status = table.Column<int>(type: "int", nullable: false),
                    Client = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    EndDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    IsAerospaceDefenceNavalSector = table.Column<bool>(type: "bit", nullable: false),
                    MonthDuration = table.Column<int>(type: "int", nullable: true),
                    JobDescription = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LevelCostId = table.Column<int>(type: "int", nullable: false),
                    AnnualGrossIncome = table.Column<float>(type: "real", nullable: false),
                    Bonus = table.Column<int>(type: "int", nullable: false),
                    Contract = table.Column<int>(type: "int", nullable: false),
                    BmHrId = table.Column<int>(type: "int", nullable: false),
                    Function = table.Column<int>(type: "int", nullable: false),
                    MissedPayment = table.Column<float>(type: "real", nullable: false),
                    StartDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Mobility_IntegrationFound = table.Column<bool>(type: "bit", nullable: false),
                    EmailTutor1 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    EmailTutor2 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TutorFunction = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SistemAdministrator = table.Column<bool>(type: "bit", nullable: false),
                    SensitiveDataTreatment = table.Column<bool>(type: "bit", nullable: false),
                    HeadOfficeId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HiredContractProposals", x => x.Id);
                    table.ForeignKey(
                        name: "FK_HiredContractProposals_BmHr_BmHrId",
                        column: x => x.BmHrId,
                        principalTable: "BmHr",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_HiredContractProposals_HeadOffice_HeadOfficeId",
                        column: x => x.HeadOfficeId,
                        principalTable: "HeadOffice",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_HiredContractProposals_LevelCost_LevelCostId",
                        column: x => x.LevelCostId,
                        principalTable: "LevelCost",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "StageContractProposals",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MonthDuration = table.Column<int>(type: "int", nullable: false),
                    EndDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DescriptionTrainingProcess = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StageRefound = table.Column<float>(type: "real", nullable: false),
                    Billable = table.Column<bool>(type: "bit", nullable: false),
                    ReproportionateToDaysInPresenze = table.Column<bool>(type: "bit", nullable: false),
                    DailyRate = table.Column<double>(type: "float", nullable: false),
                    BmHrId = table.Column<int>(type: "int", nullable: false),
                    Function = table.Column<int>(type: "int", nullable: false),
                    MissedPayment = table.Column<float>(type: "real", nullable: false),
                    StartDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Mobility_IntegrationFound = table.Column<bool>(type: "bit", nullable: false),
                    EmailTutor1 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    EmailTutor2 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TutorFunction = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SistemAdministrator = table.Column<bool>(type: "bit", nullable: false),
                    SensitiveDataTreatment = table.Column<bool>(type: "bit", nullable: false),
                    HeadOfficeId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_StageContractProposals", x => x.Id);
                    table.ForeignKey(
                        name: "FK_StageContractProposals_BmHr_BmHrId",
                        column: x => x.BmHrId,
                        principalTable: "BmHr",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_StageContractProposals_HeadOffice_HeadOfficeId",
                        column: x => x.HeadOfficeId,
                        principalTable: "HeadOffice",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_Candidate_HiredContractProposalId",
                table: "Candidate",
                column: "HiredContractProposalId",
                unique: true,
                filter: "[HiredContractProposalId] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_Candidate_StageContractProposalId",
                table: "Candidate",
                column: "StageContractProposalId",
                unique: true,
                filter: "[StageContractProposalId] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_HeadOffice_LevelCostId",
                table: "HeadOffice",
                column: "LevelCostId");

            migrationBuilder.CreateIndex(
                name: "IX_HiredContractProposals_BmHrId",
                table: "HiredContractProposals",
                column: "BmHrId");

            migrationBuilder.CreateIndex(
                name: "IX_HiredContractProposals_HeadOfficeId",
                table: "HiredContractProposals",
                column: "HeadOfficeId");

            migrationBuilder.CreateIndex(
                name: "IX_HiredContractProposals_LevelCostId",
                table: "HiredContractProposals",
                column: "LevelCostId");

            migrationBuilder.CreateIndex(
                name: "IX_Level_LevelCostId",
                table: "Level",
                column: "LevelCostId");

            migrationBuilder.CreateIndex(
                name: "IX_StageContractProposals_BmHrId",
                table: "StageContractProposals",
                column: "BmHrId");

            migrationBuilder.CreateIndex(
                name: "IX_StageContractProposals_HeadOfficeId",
                table: "StageContractProposals",
                column: "HeadOfficeId");

            migrationBuilder.AddForeignKey(
                name: "FK_Candidate_HiredContractProposals_HiredContractProposalId",
                table: "Candidate",
                column: "HiredContractProposalId",
                principalTable: "HiredContractProposals",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Candidate_StageContractProposals_StageContractProposalId",
                table: "Candidate",
                column: "StageContractProposalId",
                principalTable: "StageContractProposals",
                principalColumn: "Id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Candidate_HiredContractProposals_HiredContractProposalId",
                table: "Candidate");

            migrationBuilder.DropForeignKey(
                name: "FK_Candidate_StageContractProposals_StageContractProposalId",
                table: "Candidate");

            migrationBuilder.DropTable(
                name: "HiredContractProposals");

            migrationBuilder.DropTable(
                name: "Level");

            migrationBuilder.DropTable(
                name: "StageContractProposals");

            migrationBuilder.DropTable(
                name: "HeadOffice");

            migrationBuilder.DropTable(
                name: "LevelCost");

            migrationBuilder.DropIndex(
                name: "IX_Candidate_HiredContractProposalId",
                table: "Candidate");

            migrationBuilder.DropIndex(
                name: "IX_Candidate_StageContractProposalId",
                table: "Candidate");

            migrationBuilder.DropColumn(
                name: "HiredContractProposalId",
                table: "Candidate");

            migrationBuilder.DropColumn(
                name: "StageContractProposalId",
                table: "Candidate");

            migrationBuilder.CreateTable(
                name: "ContractProposal",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CandidateId = table.Column<int>(type: "int", nullable: false),
                    UserId = table.Column<int>(type: "int", nullable: false),
                    Addresslocation = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    AdministrationSistem = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    AnnualGrossIncome = table.Column<float>(type: "real", nullable: false),
                    BonusType = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ClassificationLevel = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ContractType = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Customer = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DailyRate = table.Column<float>(type: "real", nullable: false),
                    Duration = table.Column<int>(type: "int", nullable: true),
                    EndDeterminate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    EndStageDateTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    GrossMonthlySalary = table.Column<float>(type: "real", nullable: false),
                    HiringLocation = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IsAerospaceDefensenavalSector = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IsAlreadyintern = table.Column<bool>(type: "bit", nullable: true),
                    IsBillable = table.Column<bool>(type: "bit", nullable: false),
                    JobDescription = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    MinimumGrading = table.Column<float>(type: "real", nullable: false),
                    MissedPayment = table.Column<float>(type: "real", nullable: false),
                    MobilityLayoff = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ReliefsPossibility = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SensitiveDataHandlingConsultants = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StartDeterminate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    StartStageDateTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Status = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TrialPeriod = table.Column<int>(type: "int", nullable: false),
                    Tutor1 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Tutor2 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TutorFunction = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ContractProposal", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ContractProposal_BmHr_UserId",
                        column: x => x.UserId,
                        principalTable: "BmHr",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ContractProposal_Candidate_CandidateId",
                        column: x => x.CandidateId,
                        principalTable: "Candidate",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_ContractProposal_CandidateId",
                table: "ContractProposal",
                column: "CandidateId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_ContractProposal_UserId",
                table: "ContractProposal",
                column: "UserId");
        }
    }
}
