﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Pers.DAL.Migrations
{
    public partial class updateLevelHeadOffice : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_HeadOffice_LevelCost_LevelCostId",
                table: "HeadOffice");

            migrationBuilder.DropForeignKey(
                name: "FK_Level_LevelCost_LevelCostId",
                table: "Level");

            migrationBuilder.AlterColumn<int>(
                name: "LevelCostId",
                table: "Level",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "LevelCostId",
                table: "HeadOffice",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_HeadOffice_LevelCost_LevelCostId",
                table: "HeadOffice",
                column: "LevelCostId",
                principalTable: "LevelCost",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Level_LevelCost_LevelCostId",
                table: "Level",
                column: "LevelCostId",
                principalTable: "LevelCost",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_HeadOffice_LevelCost_LevelCostId",
                table: "HeadOffice");

            migrationBuilder.DropForeignKey(
                name: "FK_Level_LevelCost_LevelCostId",
                table: "Level");

            migrationBuilder.AlterColumn<int>(
                name: "LevelCostId",
                table: "Level",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<int>(
                name: "LevelCostId",
                table: "HeadOffice",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddForeignKey(
                name: "FK_HeadOffice_LevelCost_LevelCostId",
                table: "HeadOffice",
                column: "LevelCostId",
                principalTable: "LevelCost",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Level_LevelCost_LevelCostId",
                table: "Level",
                column: "LevelCostId",
                principalTable: "LevelCost",
                principalColumn: "Id");
        }
    }
}
