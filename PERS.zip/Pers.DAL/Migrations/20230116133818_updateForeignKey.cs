﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Pers.DAL.Migrations
{
    public partial class updateForeignKey : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Candidate_ContractProposal_ContractProposalId",
                table: "Candidate");

            migrationBuilder.DropForeignKey(
                name: "FK_User_ContractProposal_ContractProposalId",
                table: "User");

            migrationBuilder.DropIndex(
                name: "IX_User_ContractProposalId",
                table: "User");

            migrationBuilder.DropIndex(
                name: "IX_Candidate_ContractProposalId",
                table: "Candidate");

            migrationBuilder.DropColumn(
                name: "ContractProposalId",
                table: "User");

            migrationBuilder.DropColumn(
                name: "ContractProposalId",
                table: "Candidate");

            migrationBuilder.RenameColumn(
                name: "DaiLyRate",
                table: "ContractProposal",
                newName: "DailyRate");

            migrationBuilder.AddColumn<int>(
                name: "CandidateId",
                table: "ContractProposal",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_ContractProposal_CandidateId",
                table: "ContractProposal",
                column: "CandidateId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_ContractProposal_UserId",
                table: "ContractProposal",
                column: "UserId");

            migrationBuilder.AddForeignKey(
                name: "FK_ContractProposal_Candidate_CandidateId",
                table: "ContractProposal",
                column: "CandidateId",
                principalTable: "Candidate",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ContractProposal_User_UserId",
                table: "ContractProposal",
                column: "UserId",
                principalTable: "User",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ContractProposal_Candidate_CandidateId",
                table: "ContractProposal");

            migrationBuilder.DropForeignKey(
                name: "FK_ContractProposal_User_UserId",
                table: "ContractProposal");

            migrationBuilder.DropIndex(
                name: "IX_ContractProposal_CandidateId",
                table: "ContractProposal");

            migrationBuilder.DropIndex(
                name: "IX_ContractProposal_UserId",
                table: "ContractProposal");

            migrationBuilder.DropColumn(
                name: "CandidateId",
                table: "ContractProposal");

            migrationBuilder.RenameColumn(
                name: "DailyRate",
                table: "ContractProposal",
                newName: "DaiLyRate");

            migrationBuilder.AddColumn<int>(
                name: "ContractProposalId",
                table: "User",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ContractProposalId",
                table: "Candidate",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_User_ContractProposalId",
                table: "User",
                column: "ContractProposalId");

            migrationBuilder.CreateIndex(
                name: "IX_Candidate_ContractProposalId",
                table: "Candidate",
                column: "ContractProposalId");

            migrationBuilder.AddForeignKey(
                name: "FK_Candidate_ContractProposal_ContractProposalId",
                table: "Candidate",
                column: "ContractProposalId",
                principalTable: "ContractProposal",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_User_ContractProposal_ContractProposalId",
                table: "User",
                column: "ContractProposalId",
                principalTable: "ContractProposal",
                principalColumn: "Id");
        }
    }
}
