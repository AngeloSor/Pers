﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Pers.DAL.Migrations
{
    public partial class CandidateUpdate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Candidate_HiredContractProposals_HiredContractProposalId",
                table: "Candidate");

            migrationBuilder.DropForeignKey(
                name: "FK_Candidate_StageContractProposals_StageContractProposalId",
                table: "Candidate");

            migrationBuilder.DropIndex(
                name: "IX_Candidate_HiredContractProposalId",
                table: "Candidate");

            migrationBuilder.DropIndex(
                name: "IX_Candidate_StageContractProposalId",
                table: "Candidate");

            migrationBuilder.DropColumn(
                name: "Gender",
                table: "Candidate");

            migrationBuilder.DropColumn(
                name: "HiredContractProposalId",
                table: "Candidate");

            migrationBuilder.DropColumn(
                name: "StageContractProposalId",
                table: "Candidate");

            migrationBuilder.AddColumn<int>(
                name: "CandidateId",
                table: "StageContractProposals",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "CandidateId",
                table: "HiredContractProposals",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_StageContractProposals_CandidateId",
                table: "StageContractProposals",
                column: "CandidateId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_HiredContractProposals_CandidateId",
                table: "HiredContractProposals",
                column: "CandidateId",
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_HiredContractProposals_Candidate_CandidateId",
                table: "HiredContractProposals",
                column: "CandidateId",
                principalTable: "Candidate",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_StageContractProposals_Candidate_CandidateId",
                table: "StageContractProposals",
                column: "CandidateId",
                principalTable: "Candidate",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_HiredContractProposals_Candidate_CandidateId",
                table: "HiredContractProposals");

            migrationBuilder.DropForeignKey(
                name: "FK_StageContractProposals_Candidate_CandidateId",
                table: "StageContractProposals");

            migrationBuilder.DropIndex(
                name: "IX_StageContractProposals_CandidateId",
                table: "StageContractProposals");

            migrationBuilder.DropIndex(
                name: "IX_HiredContractProposals_CandidateId",
                table: "HiredContractProposals");

            migrationBuilder.DropColumn(
                name: "CandidateId",
                table: "StageContractProposals");

            migrationBuilder.DropColumn(
                name: "CandidateId",
                table: "HiredContractProposals");

            migrationBuilder.AddColumn<string>(
                name: "Gender",
                table: "Candidate",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "HiredContractProposalId",
                table: "Candidate",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "StageContractProposalId",
                table: "Candidate",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Candidate_HiredContractProposalId",
                table: "Candidate",
                column: "HiredContractProposalId",
                unique: true,
                filter: "[HiredContractProposalId] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_Candidate_StageContractProposalId",
                table: "Candidate",
                column: "StageContractProposalId",
                unique: true,
                filter: "[StageContractProposalId] IS NOT NULL");

            migrationBuilder.AddForeignKey(
                name: "FK_Candidate_HiredContractProposals_HiredContractProposalId",
                table: "Candidate",
                column: "HiredContractProposalId",
                principalTable: "HiredContractProposals",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Candidate_StageContractProposals_StageContractProposalId",
                table: "Candidate",
                column: "StageContractProposalId",
                principalTable: "StageContractProposals",
                principalColumn: "Id");
        }
    }
}
