﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Pers.DAL.Migrations
{
    public partial class UpdateEQ : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "AddressCustomer",
                table: "HiredContractProposals");
            migrationBuilder.DropColumn(
               name: "Amount",
               table: "HiredContractProposals");
            migrationBuilder.DropColumn(
               name: "ApproximateDailyPrice",
               table: "HiredContractProposals");
            migrationBuilder.DropColumn(
               name: "ApproximateMonthlyPrice",
               table: "HiredContractProposals");
            migrationBuilder.DropColumn(
               name: "Customer",
               table: "HiredContractProposals");
            migrationBuilder.DropColumn(
               name: "Guesthouse",
               table: "HiredContractProposals");
            migrationBuilder.DropColumn(
               name: "Notes",
               table: "HiredContractProposals");

            migrationBuilder.DropColumn(
               name: "Other",
               table: "HiredContractProposals");
            migrationBuilder.DropColumn(
               name: "TraveAllowance",
               table: "HiredContractProposals");

            migrationBuilder.DropColumn(
               name: "Ticket",
               table: "HiredContractProposals");

            migrationBuilder.DropColumn(
               name: "WorkstationAltenCompany",
               table: "HiredContractProposals");
            migrationBuilder.AddColumn<string>(
                name: "AddressCustomer",
                table: "HiredContractProposals",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<float>(
                name: "Amount",
                table: "HiredContractProposals",
                type: "real",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ApproximateDailyPrice",
                table: "HiredContractProposals",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<float>(
                name: "ApproximateMonthlyPrice",
                table: "HiredContractProposals",
                type: "real",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Customer",
                table: "HiredContractProposals",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "Guesthouse",
                table: "HiredContractProposals",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<string>(
                name: "Notes",
                table: "HiredContractProposals",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Other",
                table: "HiredContractProposals",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Ticket",
                table: "HiredContractProposals",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<bool>(
                name: "TraveAllowance",
                table: "HiredContractProposals",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "WorkstationAltenCompany",
                table: "HiredContractProposals",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AlterColumn<bool>(
                name: "VisioSTD",
                table: "EquipmentManagement",
                type: "bit",
                nullable: true,
                oldClrType: typeof(bool),
                oldType: "bit");

            migrationBuilder.AlterColumn<string>(
                name: "OfficeVersion",
                table: "EquipmentManagement",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(bool),
                oldType: "bit");

            migrationBuilder.AlterColumn<bool>(
                name: "Badge",
                table: "EquipmentManagement",
                type: "bit",
                nullable: true,
                oldClrType: typeof(bool),
                oldType: "bit");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "AddressCustomer",
                table: "HiredContractProposals");

            migrationBuilder.DropColumn(
                name: "Amount",
                table: "HiredContractProposals");

            migrationBuilder.DropColumn(
                name: "ApproximateDailyPrice",
                table: "HiredContractProposals");

            migrationBuilder.DropColumn(
                name: "ApproximateMonthlyPrice",
                table: "HiredContractProposals");

            migrationBuilder.DropColumn(
                name: "Customer",
                table: "HiredContractProposals");

            migrationBuilder.DropColumn(
                name: "Guesthouse",
                table: "HiredContractProposals");

            migrationBuilder.DropColumn(
                name: "Notes",
                table: "HiredContractProposals");

            migrationBuilder.DropColumn(
                name: "Other",
                table: "HiredContractProposals");

            migrationBuilder.DropColumn(
                name: "Ticket",
                table: "HiredContractProposals");

            migrationBuilder.DropColumn(
                name: "TraveAllowance",
                table: "HiredContractProposals");

            migrationBuilder.DropColumn(
                name: "WorkstationAltenCompany",
                table: "HiredContractProposals");

            migrationBuilder.AlterColumn<bool>(
                name: "VisioSTD",
                table: "EquipmentManagement",
                type: "bit",
                nullable: false,
                defaultValue: false,
                oldClrType: typeof(bool),
                oldType: "bit",
                oldNullable: true);

            migrationBuilder.AlterColumn<bool>(
                name: "OfficeVersion",
                table: "EquipmentManagement",
                type: "bit",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<bool>(
                name: "Badge",
                table: "EquipmentManagement",
                type: "bit",
                nullable: false,
                defaultValue: false,
                oldClrType: typeof(bool),
                oldType: "bit",
                oldNullable: true);
        }
    }
}
