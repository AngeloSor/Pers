﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Pers.DAL.Migrations
{
    public partial class AddedEquipmentManagement : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "EquipmentManagement",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Time = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Laptop = table.Column<int>(type: "int", nullable: false),
                    LaptopModel = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    OfficeVersion = table.Column<bool>(type: "bit", nullable: false),
                    AdminPermits = table.Column<bool>(type: "bit", nullable: false),
                    ProjectSTD = table.Column<bool>(type: "bit", nullable: false),
                    VSPro = table.Column<bool>(type: "bit", nullable: false),
                    VSEnterprise = table.Column<bool>(type: "bit", nullable: false),
                    VisioSTD = table.Column<bool>(type: "bit", nullable: false),
                    OS = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Other = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PCCustom = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Telephone = table.Column<bool>(type: "bit", nullable: true),
                    SIM = table.Column<bool>(type: "bit", nullable: true),
                    InternetKey = table.Column<bool>(type: "bit", nullable: true),
                    Car = table.Column<bool>(type: "bit", nullable: true),
                    FringeBenefitCar = table.Column<bool>(type: "bit", nullable: true),
                    Badge = table.Column<bool>(type: "bit", nullable: false),
                    BaseLanguage = table.Column<int>(type: "int", nullable: false),
                    ApproximatePrice = table.Column<double>(type: "float", nullable: false),
                    ClaimOnSite = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ContractProposalId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EquipmentManagement", x => x.Id);
                    table.ForeignKey(
                        name: "FK_EquipmentManagement_ContractProposal_ContractProposalId",
                        column: x => x.ContractProposalId,
                        principalTable: "ContractProposal",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_EquipmentManagement_ContractProposalId",
                table: "EquipmentManagement",
                column: "ContractProposalId",
                unique: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "EquipmentManagement");
        }
    }
}
