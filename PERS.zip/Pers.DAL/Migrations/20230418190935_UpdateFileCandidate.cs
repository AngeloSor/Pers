﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Pers.DAL.Migrations
{
    public partial class UpdateFileCandidate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_CandidateFile_PersonalDetails_PersonalDetailId",
                table: "CandidateFile");

            migrationBuilder.RenameColumn(
                name: "PersonalDetailId",
                table: "CandidateFile",
                newName: "CandidateId");

            migrationBuilder.RenameIndex(
                name: "IX_CandidateFile_PersonalDetailId",
                table: "CandidateFile",
                newName: "IX_CandidateFile_CandidateId");

            migrationBuilder.AddForeignKey(
                name: "FK_CandidateFile_Candidate_CandidateId",
                table: "CandidateFile",
                column: "CandidateId",
                principalTable: "Candidate",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_CandidateFile_Candidate_CandidateId",
                table: "CandidateFile");

            migrationBuilder.RenameColumn(
                name: "CandidateId",
                table: "CandidateFile",
                newName: "PersonalDetailId");

            migrationBuilder.RenameIndex(
                name: "IX_CandidateFile_CandidateId",
                table: "CandidateFile",
                newName: "IX_CandidateFile_PersonalDetailId");

            migrationBuilder.AddForeignKey(
                name: "FK_CandidateFile_PersonalDetails_PersonalDetailId",
                table: "CandidateFile",
                column: "PersonalDetailId",
                principalTable: "PersonalDetails",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
