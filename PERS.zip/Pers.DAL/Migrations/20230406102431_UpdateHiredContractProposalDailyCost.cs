﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Pers.DAL.Migrations
{
    public partial class UpdateHiredContractProposalDailyCost : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_StageContractProposal_ContractProposalId",
                table: "StageContractProposal");

            migrationBuilder.AddColumn<float>(
                name: "DailyCost",
                table: "HiredContractProposals",
                type: "real",
                nullable: false,
                defaultValue: 0f);

            migrationBuilder.CreateIndex(
                name: "IX_StageContractProposal_ContractProposalId",
                table: "StageContractProposal",
                column: "ContractProposalId",
                unique: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_StageContractProposal_ContractProposalId",
                table: "StageContractProposal");

            migrationBuilder.DropColumn(
                name: "DailyCost",
                table: "HiredContractProposals");

            migrationBuilder.CreateIndex(
                name: "IX_StageContractProposal_ContractProposalId",
                table: "StageContractProposal",
                column: "ContractProposalId");
        }
    }
}
