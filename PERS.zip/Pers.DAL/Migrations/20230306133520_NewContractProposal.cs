﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Pers.DAL.Migrations
{
    public partial class NewContractProposal : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ContractProposal_HeadOffice_HeadOfficeId",
                table: "ContractProposal");

            migrationBuilder.DropForeignKey(
                name: "FK_ContractProposal_LevelCost_LevelCostId",
                table: "ContractProposal");

            migrationBuilder.DropIndex(
                name: "IX_ContractProposal_CandidateId",
                table: "ContractProposal");

            migrationBuilder.DropIndex(
                name: "IX_ContractProposal_LevelCostId",
                table: "ContractProposal");

            migrationBuilder.DropColumn(
                name: "AnnualGrossIncome",
                table: "ContractProposal");

            migrationBuilder.DropColumn(
                name: "Billable",
                table: "ContractProposal");

            migrationBuilder.DropColumn(
                name: "Bonus",
                table: "ContractProposal");

            migrationBuilder.DropColumn(
                name: "Client",
                table: "ContractProposal");

            migrationBuilder.DropColumn(
                name: "Contract",
                table: "ContractProposal");

            migrationBuilder.DropColumn(
                name: "DailyRate",
                table: "ContractProposal");

            migrationBuilder.DropColumn(
                name: "Discriminator",
                table: "ContractProposal");

            migrationBuilder.DropColumn(
                name: "EmailTutor1",
                table: "ContractProposal");

            migrationBuilder.DropColumn(
                name: "EmailTutor2",
                table: "ContractProposal");

            migrationBuilder.DropColumn(
                name: "IsAerospaceDefenceNavalSector",
                table: "ContractProposal");

            migrationBuilder.DropColumn(
                name: "LevelCostId",
                table: "ContractProposal");

            migrationBuilder.DropColumn(
                name: "MissedPayment",
                table: "ContractProposal");

            migrationBuilder.DropColumn(
                name: "Mobility_IntegrationFound",
                table: "ContractProposal");

            migrationBuilder.DropColumn(
                name: "MonthDuration",
                table: "ContractProposal");

            migrationBuilder.DropColumn(
                name: "ReproportionateToDaysInPresences",
                table: "ContractProposal");

            migrationBuilder.DropColumn(
                name: "StageContractProposal_MonthDuration",
                table: "ContractProposal");

            migrationBuilder.DropColumn(
                name: "StageRefound",
                table: "ContractProposal");

            migrationBuilder.DropColumn(
                name: "Status",
                table: "ContractProposal");

            migrationBuilder.DropColumn(
                name: "TutorFunction",
                table: "ContractProposal");

            migrationBuilder.RenameColumn(
                name: "StageContractProposal_EndDate",
                table: "ContractProposal",
                newName: "StartDateDet");

            migrationBuilder.RenameColumn(
                name: "SistemAdministrator",
                table: "ContractProposal",
                newName: "SmartWorking");

            migrationBuilder.RenameColumn(
                name: "SensitiveDataTreatment",
                table: "ContractProposal",
                newName: "MobilityLayoffs");

            migrationBuilder.RenameColumn(
                name: "JobDescription",
                table: "ContractProposal",
                newName: "FailureToPayNotice");

            migrationBuilder.RenameColumn(
                name: "EndDate",
                table: "ContractProposal",
                newName: "EndDateDet");

            migrationBuilder.RenameColumn(
                name: "DescriptionTrainingProcess",
                table: "ContractProposal",
                newName: "Duration");

            migrationBuilder.AlterColumn<string>(
                name: "PossibilityOfReliefs",
                table: "ContractProposal",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(bool),
                oldType: "bit",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "HeadOfficeId",
                table: "ContractProposal",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<bool>(
                name: "AlreadyStage",
                table: "ContractProposal",
                type: "bit",
                nullable: false,
                defaultValue: false,
                oldClrType: typeof(bool),
                oldType: "bit",
                oldNullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ContractType",
                table: "ContractProposal",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "SwDays",
                table: "ContractProposal",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "HiredContractProposal",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AlreadyStage = table.Column<bool>(type: "bit", nullable: false),
                    Status = table.Column<int>(type: "int", nullable: false),
                    Client = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    EndDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    IsAerospaceDefenceNavalSector = table.Column<bool>(type: "bit", nullable: false),
                    MonthDuration = table.Column<int>(type: "int", nullable: true),
                    JobDescription = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    AnnualGrossIncome = table.Column<float>(type: "real", nullable: false),
                    Bonus = table.Column<int>(type: "int", nullable: false),
                    Contract = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HiredContractProposal", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "StageContractProposal",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MonthDuration = table.Column<int>(type: "int", nullable: false),
                    EndDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DescriptionTrainingProcess = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StageRefound = table.Column<float>(type: "real", nullable: false),
                    Billable = table.Column<bool>(type: "bit", nullable: false),
                    ReproportionateToDaysInPresences = table.Column<bool>(type: "bit", nullable: false),
                    DailyRate = table.Column<double>(type: "float", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_StageContractProposal", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_ContractProposal_CandidateId",
                table: "ContractProposal",
                column: "CandidateId");

            migrationBuilder.AddForeignKey(
                name: "FK_ContractProposal_HeadOffice_HeadOfficeId",
                table: "ContractProposal",
                column: "HeadOfficeId",
                principalTable: "HeadOffice",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ContractProposal_HeadOffice_HeadOfficeId",
                table: "ContractProposal");

            migrationBuilder.DropTable(
                name: "HiredContractProposal");

            migrationBuilder.DropTable(
                name: "StageContractProposal");

            migrationBuilder.DropIndex(
                name: "IX_ContractProposal_CandidateId",
                table: "ContractProposal");

            migrationBuilder.DropColumn(
                name: "ContractType",
                table: "ContractProposal");

            migrationBuilder.DropColumn(
                name: "SwDays",
                table: "ContractProposal");

            migrationBuilder.RenameColumn(
                name: "StartDateDet",
                table: "ContractProposal",
                newName: "StageContractProposal_EndDate");

            migrationBuilder.RenameColumn(
                name: "SmartWorking",
                table: "ContractProposal",
                newName: "SistemAdministrator");

            migrationBuilder.RenameColumn(
                name: "MobilityLayoffs",
                table: "ContractProposal",
                newName: "SensitiveDataTreatment");

            migrationBuilder.RenameColumn(
                name: "FailureToPayNotice",
                table: "ContractProposal",
                newName: "JobDescription");

            migrationBuilder.RenameColumn(
                name: "EndDateDet",
                table: "ContractProposal",
                newName: "EndDate");

            migrationBuilder.RenameColumn(
                name: "Duration",
                table: "ContractProposal",
                newName: "DescriptionTrainingProcess");

            migrationBuilder.AlterColumn<bool>(
                name: "PossibilityOfReliefs",
                table: "ContractProposal",
                type: "bit",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "HeadOfficeId",
                table: "ContractProposal",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<bool>(
                name: "AlreadyStage",
                table: "ContractProposal",
                type: "bit",
                nullable: true,
                oldClrType: typeof(bool),
                oldType: "bit");

            migrationBuilder.AddColumn<float>(
                name: "AnnualGrossIncome",
                table: "ContractProposal",
                type: "real",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "Billable",
                table: "ContractProposal",
                type: "bit",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "Bonus",
                table: "ContractProposal",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Client",
                table: "ContractProposal",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "Contract",
                table: "ContractProposal",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<double>(
                name: "DailyRate",
                table: "ContractProposal",
                type: "float",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Discriminator",
                table: "ContractProposal",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "EmailTutor1",
                table: "ContractProposal",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "EmailTutor2",
                table: "ContractProposal",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<bool>(
                name: "IsAerospaceDefenceNavalSector",
                table: "ContractProposal",
                type: "bit",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "LevelCostId",
                table: "ContractProposal",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<float>(
                name: "MissedPayment",
                table: "ContractProposal",
                type: "real",
                nullable: false,
                defaultValue: 0f);

            migrationBuilder.AddColumn<bool>(
                name: "Mobility_IntegrationFound",
                table: "ContractProposal",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<int>(
                name: "MonthDuration",
                table: "ContractProposal",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "ReproportionateToDaysInPresences",
                table: "ContractProposal",
                type: "bit",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "StageContractProposal_MonthDuration",
                table: "ContractProposal",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<float>(
                name: "StageRefound",
                table: "ContractProposal",
                type: "real",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "Status",
                table: "ContractProposal",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "TutorFunction",
                table: "ContractProposal",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateIndex(
                name: "IX_ContractProposal_CandidateId",
                table: "ContractProposal",
                column: "CandidateId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_ContractProposal_LevelCostId",
                table: "ContractProposal",
                column: "LevelCostId");

            migrationBuilder.AddForeignKey(
                name: "FK_ContractProposal_HeadOffice_HeadOfficeId",
                table: "ContractProposal",
                column: "HeadOfficeId",
                principalTable: "HeadOffice",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ContractProposal_LevelCost_LevelCostId",
                table: "ContractProposal",
                column: "LevelCostId",
                principalTable: "LevelCost",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
