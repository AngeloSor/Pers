﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Pers.DAL.Migrations
{
    public partial class updateBmHr : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Career",
                table: "Candidate",
                newName: "IsContractSend");

            migrationBuilder.AddColumn<int>(
                name: "BmHrId",
                table: "Candidate",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Candidate_BmHrId",
                table: "Candidate",
                column: "BmHrId");

            migrationBuilder.AddForeignKey(
                name: "FK_Candidate_BmHr_BmHrId",
                table: "Candidate",
                column: "BmHrId",
                principalTable: "BmHr",
                principalColumn: "Id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Candidate_BmHr_BmHrId",
                table: "Candidate");

            migrationBuilder.DropIndex(
                name: "IX_Candidate_BmHrId",
                table: "Candidate");

            migrationBuilder.DropColumn(
                name: "BmHrId",
                table: "Candidate");

            migrationBuilder.RenameColumn(
                name: "IsContractSend",
                table: "Candidate",
                newName: "Career");
        }
    }
}
