﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Pers.DAL.Migrations
{
    public partial class UpdateCarriera : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "InternetKey",
                table: "EquipmentManagement");

            migrationBuilder.DropColumn(
                name: "PCCustom",
                table: "EquipmentManagement");

            migrationBuilder.DropColumn(
                name: "ProjectSTD",
                table: "EquipmentManagement");

            migrationBuilder.DropColumn(
                name: "VSEnterprise",
                table: "EquipmentManagement");

            migrationBuilder.DropColumn(
                name: "VSPro",
                table: "EquipmentManagement");

            migrationBuilder.DropColumn(
                name: "VisioSTD",
                table: "EquipmentManagement");

            migrationBuilder.AlterColumn<int>(
                name: "BaseLanguage",
                table: "EquipmentManagement",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<int>(
                name: "BaseLanguage",
                table: "EquipmentManagement",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "InternetKey",
                table: "EquipmentManagement",
                type: "bit",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "PCCustom",
                table: "EquipmentManagement",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "ProjectSTD",
                table: "EquipmentManagement",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "VSEnterprise",
                table: "EquipmentManagement",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "VSPro",
                table: "EquipmentManagement",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "VisioSTD",
                table: "EquipmentManagement",
                type: "bit",
                nullable: true);
        }
    }
}
