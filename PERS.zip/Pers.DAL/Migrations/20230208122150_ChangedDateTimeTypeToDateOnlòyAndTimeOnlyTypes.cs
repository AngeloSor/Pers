﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Pers.DAL.Migrations
{
    public partial class ChangedDateTimeTypeToDateOnlòyAndTimeOnlyTypes : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_StageContractProposals_BmHr_BmHrId",
                table: "StageContractProposals");

            migrationBuilder.DropForeignKey(
                name: "FK_StageContractProposals_Candidate_CandidateId",
                table: "StageContractProposals");

            migrationBuilder.DropForeignKey(
                name: "FK_StageContractProposals_HeadOffice_HeadOfficeId",
                table: "StageContractProposals");

            migrationBuilder.DropTable(
                name: "HiredContractProposals");

            migrationBuilder.DropPrimaryKey(
                name: "PK_StageContractProposals",
                table: "StageContractProposals");

            migrationBuilder.RenameTable(
                name: "StageContractProposals",
                newName: "ContractProposal");

            migrationBuilder.RenameIndex(
                name: "IX_StageContractProposals_HeadOfficeId",
                table: "ContractProposal",
                newName: "IX_ContractProposal_HeadOfficeId");

            migrationBuilder.RenameIndex(
                name: "IX_StageContractProposals_CandidateId",
                table: "ContractProposal",
                newName: "IX_ContractProposal_CandidateId");

            migrationBuilder.RenameIndex(
                name: "IX_StageContractProposals_BmHrId",
                table: "ContractProposal",
                newName: "IX_ContractProposal_BmHrId");

            migrationBuilder.AddColumn<TimeSpan>(
                name: "Time",
                table: "PcReservation",
                type: "time",
                nullable: false,
                defaultValue: new TimeSpan(0, 0, 0, 0, 0));

            migrationBuilder.AlterColumn<float>(
                name: "StageRefound",
                table: "ContractProposal",
                type: "real",
                nullable: true,
                oldClrType: typeof(float),
                oldType: "real");

            migrationBuilder.AlterColumn<bool>(
                name: "ReproportionateToDaysInPresences",
                table: "ContractProposal",
                type: "bit",
                nullable: true,
                oldClrType: typeof(bool),
                oldType: "bit");

            migrationBuilder.AlterColumn<int>(
                name: "MonthDuration",
                table: "ContractProposal",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<DateTime>(
                name: "EndDate",
                table: "ContractProposal",
                type: "datetime2",
                nullable: true,
                oldClrType: typeof(DateTime),
                oldType: "datetime2");

            migrationBuilder.AlterColumn<string>(
                name: "DescriptionTrainingProcess",
                table: "ContractProposal",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<double>(
                name: "DailyRate",
                table: "ContractProposal",
                type: "float",
                nullable: true,
                oldClrType: typeof(double),
                oldType: "float");

            migrationBuilder.AlterColumn<bool>(
                name: "Billable",
                table: "ContractProposal",
                type: "bit",
                nullable: true,
                oldClrType: typeof(bool),
                oldType: "bit");

            migrationBuilder.AddColumn<bool>(
                name: "AlreadyStage",
                table: "ContractProposal",
                type: "bit",
                nullable: true);

            migrationBuilder.AddColumn<float>(
                name: "AnnualGrossIncome",
                table: "ContractProposal",
                type: "real",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "Bonus",
                table: "ContractProposal",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Client",
                table: "ContractProposal",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "Contract",
                table: "ContractProposal",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Discriminator",
                table: "ContractProposal",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<bool>(
                name: "IsAerospaceDefenceNavalSector",
                table: "ContractProposal",
                type: "bit",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "JobDescription",
                table: "ContractProposal",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "LevelCostId",
                table: "ContractProposal",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "PossibilityOfReliefs",
                table: "ContractProposal",
                type: "bit",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "StageContractProposal_EndDate",
                table: "ContractProposal",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "StageContractProposal_MonthDuration",
                table: "ContractProposal",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "Status",
                table: "ContractProposal",
                type: "int",
                nullable: true);

            migrationBuilder.AddPrimaryKey(
                name: "PK_ContractProposal",
                table: "ContractProposal",
                column: "Id");

            migrationBuilder.CreateIndex(
                name: "IX_ContractProposal_LevelCostId",
                table: "ContractProposal",
                column: "LevelCostId");

            migrationBuilder.AddForeignKey(
                name: "FK_ContractProposal_BmHr_BmHrId",
                table: "ContractProposal",
                column: "BmHrId",
                principalTable: "BmHr",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ContractProposal_Candidate_CandidateId",
                table: "ContractProposal",
                column: "CandidateId",
                principalTable: "Candidate",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ContractProposal_HeadOffice_HeadOfficeId",
                table: "ContractProposal",
                column: "HeadOfficeId",
                principalTable: "HeadOffice",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ContractProposal_LevelCost_LevelCostId",
                table: "ContractProposal",
                column: "LevelCostId",
                principalTable: "LevelCost",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ContractProposal_BmHr_BmHrId",
                table: "ContractProposal");

            migrationBuilder.DropForeignKey(
                name: "FK_ContractProposal_Candidate_CandidateId",
                table: "ContractProposal");

            migrationBuilder.DropForeignKey(
                name: "FK_ContractProposal_HeadOffice_HeadOfficeId",
                table: "ContractProposal");

            migrationBuilder.DropForeignKey(
                name: "FK_ContractProposal_LevelCost_LevelCostId",
                table: "ContractProposal");

            migrationBuilder.DropPrimaryKey(
                name: "PK_ContractProposal",
                table: "ContractProposal");

            migrationBuilder.DropIndex(
                name: "IX_ContractProposal_LevelCostId",
                table: "ContractProposal");

            migrationBuilder.DropColumn(
                name: "Time",
                table: "PcReservation");

            migrationBuilder.DropColumn(
                name: "AlreadyStage",
                table: "ContractProposal");

            migrationBuilder.DropColumn(
                name: "AnnualGrossIncome",
                table: "ContractProposal");

            migrationBuilder.DropColumn(
                name: "Bonus",
                table: "ContractProposal");

            migrationBuilder.DropColumn(
                name: "Client",
                table: "ContractProposal");

            migrationBuilder.DropColumn(
                name: "Contract",
                table: "ContractProposal");

            migrationBuilder.DropColumn(
                name: "Discriminator",
                table: "ContractProposal");

            migrationBuilder.DropColumn(
                name: "IsAerospaceDefenceNavalSector",
                table: "ContractProposal");

            migrationBuilder.DropColumn(
                name: "JobDescription",
                table: "ContractProposal");

            migrationBuilder.DropColumn(
                name: "LevelCostId",
                table: "ContractProposal");

            migrationBuilder.DropColumn(
                name: "PossibilityOfReliefs",
                table: "ContractProposal");

            migrationBuilder.DropColumn(
                name: "StageContractProposal_EndDate",
                table: "ContractProposal");

            migrationBuilder.DropColumn(
                name: "StageContractProposal_MonthDuration",
                table: "ContractProposal");

            migrationBuilder.DropColumn(
                name: "Status",
                table: "ContractProposal");

            migrationBuilder.RenameTable(
                name: "ContractProposal",
                newName: "StageContractProposals");

            migrationBuilder.RenameIndex(
                name: "IX_ContractProposal_HeadOfficeId",
                table: "StageContractProposals",
                newName: "IX_StageContractProposals_HeadOfficeId");

            migrationBuilder.RenameIndex(
                name: "IX_ContractProposal_CandidateId",
                table: "StageContractProposals",
                newName: "IX_StageContractProposals_CandidateId");

            migrationBuilder.RenameIndex(
                name: "IX_ContractProposal_BmHrId",
                table: "StageContractProposals",
                newName: "IX_StageContractProposals_BmHrId");

            migrationBuilder.AlterColumn<float>(
                name: "StageRefound",
                table: "StageContractProposals",
                type: "real",
                nullable: false,
                defaultValue: 0f,
                oldClrType: typeof(float),
                oldType: "real",
                oldNullable: true);

            migrationBuilder.AlterColumn<bool>(
                name: "ReproportionateToDaysInPresences",
                table: "StageContractProposals",
                type: "bit",
                nullable: false,
                defaultValue: false,
                oldClrType: typeof(bool),
                oldType: "bit",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "MonthDuration",
                table: "StageContractProposals",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<DateTime>(
                name: "EndDate",
                table: "StageContractProposals",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified),
                oldClrType: typeof(DateTime),
                oldType: "datetime2",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "DescriptionTrainingProcess",
                table: "StageContractProposals",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<double>(
                name: "DailyRate",
                table: "StageContractProposals",
                type: "float",
                nullable: false,
                defaultValue: 0.0,
                oldClrType: typeof(double),
                oldType: "float",
                oldNullable: true);

            migrationBuilder.AlterColumn<bool>(
                name: "Billable",
                table: "StageContractProposals",
                type: "bit",
                nullable: false,
                defaultValue: false,
                oldClrType: typeof(bool),
                oldType: "bit",
                oldNullable: true);

            migrationBuilder.AddPrimaryKey(
                name: "PK_StageContractProposals",
                table: "StageContractProposals",
                column: "Id");

            migrationBuilder.CreateTable(
                name: "HiredContractProposals",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    BmHrId = table.Column<int>(type: "int", nullable: false),
                    CandidateId = table.Column<int>(type: "int", nullable: false),
                    HeadOfficeId = table.Column<int>(type: "int", nullable: true),
                    LevelCostId = table.Column<int>(type: "int", nullable: false),
                    AlreadyStage = table.Column<bool>(type: "bit", nullable: false),
                    AnnualGrossIncome = table.Column<float>(type: "real", nullable: false),
                    Bonus = table.Column<int>(type: "int", nullable: false),
                    Client = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Contract = table.Column<int>(type: "int", nullable: false),
                    EmailTutor1 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    EmailTutor2 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    EndDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Function = table.Column<int>(type: "int", nullable: false),
                    IsAerospaceDefenceNavalSector = table.Column<bool>(type: "bit", nullable: false),
                    JobDescription = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    MissedPayment = table.Column<float>(type: "real", nullable: false),
                    Mobility_IntegrationFound = table.Column<bool>(type: "bit", nullable: false),
                    MonthDuration = table.Column<int>(type: "int", nullable: true),
                    PossibilityOfReliefs = table.Column<bool>(type: "bit", nullable: true),
                    SensitiveDataTreatment = table.Column<bool>(type: "bit", nullable: false),
                    SistemAdministrator = table.Column<bool>(type: "bit", nullable: false),
                    StartDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Status = table.Column<int>(type: "int", nullable: false),
                    TutorFunction = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HiredContractProposals", x => x.Id);
                    table.ForeignKey(
                        name: "FK_HiredContractProposals_BmHr_BmHrId",
                        column: x => x.BmHrId,
                        principalTable: "BmHr",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_HiredContractProposals_Candidate_CandidateId",
                        column: x => x.CandidateId,
                        principalTable: "Candidate",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_HiredContractProposals_HeadOffice_HeadOfficeId",
                        column: x => x.HeadOfficeId,
                        principalTable: "HeadOffice",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_HiredContractProposals_LevelCost_LevelCostId",
                        column: x => x.LevelCostId,
                        principalTable: "LevelCost",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_HiredContractProposals_BmHrId",
                table: "HiredContractProposals",
                column: "BmHrId");

            migrationBuilder.CreateIndex(
                name: "IX_HiredContractProposals_CandidateId",
                table: "HiredContractProposals",
                column: "CandidateId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_HiredContractProposals_HeadOfficeId",
                table: "HiredContractProposals",
                column: "HeadOfficeId");

            migrationBuilder.CreateIndex(
                name: "IX_HiredContractProposals_LevelCostId",
                table: "HiredContractProposals",
                column: "LevelCostId");

            migrationBuilder.AddForeignKey(
                name: "FK_StageContractProposals_BmHr_BmHrId",
                table: "StageContractProposals",
                column: "BmHrId",
                principalTable: "BmHr",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_StageContractProposals_Candidate_CandidateId",
                table: "StageContractProposals",
                column: "CandidateId",
                principalTable: "Candidate",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_StageContractProposals_HeadOffice_HeadOfficeId",
                table: "StageContractProposals",
                column: "HeadOfficeId",
                principalTable: "HeadOffice",
                principalColumn: "Id");
        }
    }
}
