﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Pers.DAL.Migrations
{
    public partial class PcReservationUpdated : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Time",
                table: "PcReservation");

            migrationBuilder.RenameColumn(
                name: "ReproportionateToDaysInPresenze",
                table: "StageContractProposals",
                newName: "ReproportionateToDaysInPresences");

            migrationBuilder.RenameColumn(
                name: "VisualStudioEnterpriseMOtivation",
                table: "PcReservation",
                newName: "VisualStudioEnterpriseMotivation");

            migrationBuilder.RenameColumn(
                name: "IsOfficeFUllNecessary",
                table: "PcReservation",
                newName: "IsOfficeFullNecessary");

            migrationBuilder.RenameColumn(
                name: "AdministratorPermissionMOtivation",
                table: "PcReservation",
                newName: "AdministratorPermissionMotivation");

            migrationBuilder.RenameColumn(
                name: "TypeDegreee",
                table: "Candidate",
                newName: "TypeDegree");

            migrationBuilder.RenameColumn(
                name: "Seconarynationality",
                table: "Candidate",
                newName: "Secondarynationality");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "ReproportionateToDaysInPresences",
                table: "StageContractProposals",
                newName: "ReproportionateToDaysInPresenze");

            migrationBuilder.RenameColumn(
                name: "VisualStudioEnterpriseMotivation",
                table: "PcReservation",
                newName: "VisualStudioEnterpriseMOtivation");

            migrationBuilder.RenameColumn(
                name: "IsOfficeFullNecessary",
                table: "PcReservation",
                newName: "IsOfficeFUllNecessary");

            migrationBuilder.RenameColumn(
                name: "AdministratorPermissionMotivation",
                table: "PcReservation",
                newName: "AdministratorPermissionMOtivation");

            migrationBuilder.RenameColumn(
                name: "TypeDegree",
                table: "Candidate",
                newName: "TypeDegreee");

            migrationBuilder.RenameColumn(
                name: "Secondarynationality",
                table: "Candidate",
                newName: "Seconarynationality");

            migrationBuilder.AddColumn<DateTime>(
                name: "Time",
                table: "PcReservation",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));
        }
    }
}
