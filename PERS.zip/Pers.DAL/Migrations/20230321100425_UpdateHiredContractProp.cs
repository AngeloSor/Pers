﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Pers.DAL.Migrations
{
    public partial class UpdateHiredContractProp : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "AddressCustomer",
                table: "HiredContractProposals",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<float>(
                name: "Amount",
                table: "HiredContractProposals",
                type: "real",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ApproximateDailyPrice",
                table: "HiredContractProposals",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<float>(
                name: "ApproximateMonthlyPrice",
                table: "HiredContractProposals",
                type: "real",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Customer",
                table: "HiredContractProposals",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "Guesthouse",
                table: "HiredContractProposals",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<string>(
                name: "Notes",
                table: "HiredContractProposals",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Other",
                table: "HiredContractProposals",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Ticket",
                table: "HiredContractProposals",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<bool>(
                name: "TraveAllowance",
                table: "HiredContractProposals",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "WorkstationAltenCompany",
                table: "HiredContractProposals",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "AddressCustomer",
                table: "HiredContractProposals");

            migrationBuilder.DropColumn(
                name: "Amount",
                table: "HiredContractProposals");

            migrationBuilder.DropColumn(
                name: "ApproximateDailyPrice",
                table: "HiredContractProposals");

            migrationBuilder.DropColumn(
                name: "ApproximateMonthlyPrice",
                table: "HiredContractProposals");

            migrationBuilder.DropColumn(
                name: "Customer",
                table: "HiredContractProposals");

            migrationBuilder.DropColumn(
                name: "Guesthouse",
                table: "HiredContractProposals");

            migrationBuilder.DropColumn(
                name: "Notes",
                table: "HiredContractProposals");

            migrationBuilder.DropColumn(
                name: "Other",
                table: "HiredContractProposals");

            migrationBuilder.DropColumn(
                name: "Ticket",
                table: "HiredContractProposals");

            migrationBuilder.DropColumn(
                name: "TraveAllowance",
                table: "HiredContractProposals");

            migrationBuilder.DropColumn(
                name: "WorkstationAltenCompany",
                table: "HiredContractProposals");
        }
    }
}
