﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Pers.DAL.Migrations
{
    public partial class UpdateRelationshipLevelHired : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_HiredContractProposals_LevelId",
                table: "HiredContractProposals");

            migrationBuilder.CreateIndex(
                name: "IX_HiredContractProposals_LevelId",
                table: "HiredContractProposals",
                column: "LevelId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_HiredContractProposals_LevelId",
                table: "HiredContractProposals");

            migrationBuilder.CreateIndex(
                name: "IX_HiredContractProposals_LevelId",
                table: "HiredContractProposals",
                column: "LevelId",
                unique: true);
        }
    }
}
