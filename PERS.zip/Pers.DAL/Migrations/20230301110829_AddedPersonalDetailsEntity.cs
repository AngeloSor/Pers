﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Pers.DAL.Migrations
{
    public partial class AddedPersonalDetailsEntity : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "PersonalDetails",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Surname = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    BirthPlace = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ResidenceAddress = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ResidenceCity = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DomicileAddress = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DomicileCity = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FiscalCode = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Institute = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Notes1 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    OriginCompany = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Notes2 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Education = table.Column<int>(type: "int", nullable: false),
                    FacultyDegree = table.Column<int>(type: "int", nullable: false),
                    PrevExperience = table.Column<int>(type: "int", nullable: false),
                    Certification = table.Column<bool>(type: "bit", nullable: false),
                    ShortDescription = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    HasSingleCitizenship = table.Column<bool>(type: "bit", nullable: false),
                    HasItalianCitizenship = table.Column<bool>(type: "bit", nullable: false),
                    Citizenship1 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Citizenship2 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    HasAlreadyWorkedForAlten = table.Column<bool>(type: "bit", nullable: false),
                    DateBirth = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ResidenceZIPCode = table.Column<int>(type: "int", nullable: false),
                    DomicileZIPCode = table.Column<int>(type: "int", nullable: false),
                    Telephone = table.Column<int>(type: "int", nullable: false),
                    Vote = table.Column<int>(type: "int", nullable: false),
                    CandidateProfileId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PersonalDetails", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PersonalDetails_Candidate_CandidateProfileId",
                        column: x => x.CandidateProfileId,
                        principalTable: "Candidate",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_PersonalDetails_CandidateProfileId",
                table: "PersonalDetails",
                column: "CandidateProfileId",
                unique: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "PersonalDetails");
        }
    }
}
