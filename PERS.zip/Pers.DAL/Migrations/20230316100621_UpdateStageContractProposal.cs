﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Pers.DAL.Migrations
{
    public partial class UpdateStageContractProposal : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "StageRefound",
                table: "StageContractProposal");

            migrationBuilder.RenameColumn(
                name: "ReproportionateToDaysInPresences",
                table: "StageContractProposal",
                newName: "WorkstationAltenCompany");

            migrationBuilder.RenameColumn(
                name: "MonthDuration",
                table: "StageContractProposal",
                newName: "ContractProposalId");

            migrationBuilder.RenameColumn(
                name: "EndDate",
                table: "StageContractProposal",
                newName: "StartStage");

            migrationBuilder.RenameColumn(
                name: "DescriptionTrainingProcess",
                table: "StageContractProposal",
                newName: "TutorStage2");

            migrationBuilder.RenameColumn(
                name: "DailyRate",
                table: "StageContractProposal",
                newName: "RefundStage");

            migrationBuilder.AddColumn<string>(
                name: "AddressCustomer",
                table: "StageContractProposal",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Customer",
                table: "StageContractProposal",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<double>(
                name: "DailyCost",
                table: "StageContractProposal",
                type: "float",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "DurationStage",
                table: "StageContractProposal",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<DateTime>(
                name: "EndStage",
                table: "StageContractProposal",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<string>(
                name: "FunctionTutor1",
                table: "StageContractProposal",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "FunctionTutor2",
                table: "StageContractProposal",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "FunctionTutor3",
                table: "StageContractProposal",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "Guesthouse",
                table: "StageContractProposal",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "HasSensitiveData",
                table: "StageContractProposal",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<string>(
                name: "ProjectDescription",
                table: "StageContractProposal",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<bool>(
                name: "ProportionateDaysPresence",
                table: "StageContractProposal",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "TravelAllowance",
                table: "StageContractProposal",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<string>(
                name: "TutorStage1",
                table: "StageContractProposal",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "TutorStage3",
                table: "StageContractProposal",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_StageContractProposal_ContractProposalId",
                table: "StageContractProposal",
                column: "ContractProposalId");

            migrationBuilder.AddForeignKey(
                name: "FK_StageContractProposal_ContractProposal_ContractProposalId",
                table: "StageContractProposal",
                column: "ContractProposalId",
                principalTable: "ContractProposal",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_StageContractProposal_ContractProposal_ContractProposalId",
                table: "StageContractProposal");

            migrationBuilder.DropIndex(
                name: "IX_StageContractProposal_ContractProposalId",
                table: "StageContractProposal");

            migrationBuilder.DropColumn(
                name: "AddressCustomer",
                table: "StageContractProposal");

            migrationBuilder.DropColumn(
                name: "Customer",
                table: "StageContractProposal");

            migrationBuilder.DropColumn(
                name: "DailyCost",
                table: "StageContractProposal");

            migrationBuilder.DropColumn(
                name: "DurationStage",
                table: "StageContractProposal");

            migrationBuilder.DropColumn(
                name: "EndStage",
                table: "StageContractProposal");

            migrationBuilder.DropColumn(
                name: "FunctionTutor1",
                table: "StageContractProposal");

            migrationBuilder.DropColumn(
                name: "FunctionTutor2",
                table: "StageContractProposal");

            migrationBuilder.DropColumn(
                name: "FunctionTutor3",
                table: "StageContractProposal");

            migrationBuilder.DropColumn(
                name: "Guesthouse",
                table: "StageContractProposal");

            migrationBuilder.DropColumn(
                name: "HasSensitiveData",
                table: "StageContractProposal");

            migrationBuilder.DropColumn(
                name: "ProjectDescription",
                table: "StageContractProposal");

            migrationBuilder.DropColumn(
                name: "ProportionateDaysPresence",
                table: "StageContractProposal");

            migrationBuilder.DropColumn(
                name: "TravelAllowance",
                table: "StageContractProposal");

            migrationBuilder.DropColumn(
                name: "TutorStage1",
                table: "StageContractProposal");

            migrationBuilder.DropColumn(
                name: "TutorStage3",
                table: "StageContractProposal");

            migrationBuilder.RenameColumn(
                name: "WorkstationAltenCompany",
                table: "StageContractProposal",
                newName: "ReproportionateToDaysInPresences");

            migrationBuilder.RenameColumn(
                name: "TutorStage2",
                table: "StageContractProposal",
                newName: "DescriptionTrainingProcess");

            migrationBuilder.RenameColumn(
                name: "StartStage",
                table: "StageContractProposal",
                newName: "EndDate");

            migrationBuilder.RenameColumn(
                name: "RefundStage",
                table: "StageContractProposal",
                newName: "DailyRate");

            migrationBuilder.RenameColumn(
                name: "ContractProposalId",
                table: "StageContractProposal",
                newName: "MonthDuration");

            migrationBuilder.AddColumn<float>(
                name: "StageRefound",
                table: "StageContractProposal",
                type: "real",
                nullable: false,
                defaultValue: 0f);
        }
    }
}
