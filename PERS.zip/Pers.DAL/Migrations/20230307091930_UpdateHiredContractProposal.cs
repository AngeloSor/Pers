﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Pers.DAL.Migrations
{
    public partial class UpdateHiredContractProposal : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_LevelCost_Level_LevelId",
                table: "LevelCost");

            migrationBuilder.DropIndex(
                name: "IX_LevelCost_LevelId",
                table: "LevelCost");

            migrationBuilder.DropPrimaryKey(
                name: "PK_HiredContractProposal",
                table: "HiredContractProposal");

            migrationBuilder.DropColumn(
                name: "LevelId",
                table: "LevelCost");

            migrationBuilder.DropColumn(
                name: "AnnualGrossIncome",
                table: "HiredContractProposal");

            migrationBuilder.DropColumn(
                name: "EndDate",
                table: "HiredContractProposal");

            migrationBuilder.RenameTable(
                name: "HiredContractProposal",
                newName: "HiredContractProposals");

            migrationBuilder.RenameColumn(
                name: "MonthDuration",
                table: "HiredContractProposals",
                newName: "ClassifiedProject");

            migrationBuilder.RenameColumn(
                name: "IsAerospaceDefenceNavalSector",
                table: "HiredContractProposals",
                newName: "IsAerospaceDefence");

            migrationBuilder.RenameColumn(
                name: "Contract",
                table: "HiredContractProposals",
                newName: "SuperMinimumAbsorbable");

            migrationBuilder.RenameColumn(
                name: "AlreadyStage",
                table: "HiredContractProposals",
                newName: "HasSensitiveData");

            migrationBuilder.AlterColumn<string>(
                name: "Vote",
                table: "PersonalDetails",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddColumn<int>(
                name: "AnnualMinimumWage",
                table: "HiredContractProposals",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "BonusValue",
                table: "HiredContractProposals",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ContractProposalId",
                table: "HiredContractProposals",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "EmailTutor1",
                table: "HiredContractProposals",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "EmailTutor2",
                table: "HiredContractProposals",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<int>(
                name: "GrossMonthlySalary",
                table: "HiredContractProposals",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "LevelId",
                table: "HiredContractProposals",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Ral",
                table: "HiredContractProposals",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "TrialPeriod",
                table: "HiredContractProposals",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "TutorFunction",
                table: "HiredContractProposals",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddPrimaryKey(
                name: "PK_HiredContractProposals",
                table: "HiredContractProposals",
                column: "Id");

            migrationBuilder.CreateIndex(
                name: "IX_HiredContractProposals_ContractProposalId",
                table: "HiredContractProposals",
                column: "ContractProposalId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_HiredContractProposals_LevelId",
                table: "HiredContractProposals",
                column: "LevelId",
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_HiredContractProposals_ContractProposal_ContractProposalId",
                table: "HiredContractProposals",
                column: "ContractProposalId",
                principalTable: "ContractProposal",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_HiredContractProposals_Level_LevelId",
                table: "HiredContractProposals",
                column: "LevelId",
                principalTable: "Level",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_HiredContractProposals_ContractProposal_ContractProposalId",
                table: "HiredContractProposals");

            migrationBuilder.DropForeignKey(
                name: "FK_HiredContractProposals_Level_LevelId",
                table: "HiredContractProposals");

            migrationBuilder.DropPrimaryKey(
                name: "PK_HiredContractProposals",
                table: "HiredContractProposals");

            migrationBuilder.DropIndex(
                name: "IX_HiredContractProposals_ContractProposalId",
                table: "HiredContractProposals");

            migrationBuilder.DropIndex(
                name: "IX_HiredContractProposals_LevelId",
                table: "HiredContractProposals");

            migrationBuilder.DropColumn(
                name: "AnnualMinimumWage",
                table: "HiredContractProposals");

            migrationBuilder.DropColumn(
                name: "BonusValue",
                table: "HiredContractProposals");

            migrationBuilder.DropColumn(
                name: "ContractProposalId",
                table: "HiredContractProposals");

            migrationBuilder.DropColumn(
                name: "EmailTutor1",
                table: "HiredContractProposals");

            migrationBuilder.DropColumn(
                name: "EmailTutor2",
                table: "HiredContractProposals");

            migrationBuilder.DropColumn(
                name: "GrossMonthlySalary",
                table: "HiredContractProposals");

            migrationBuilder.DropColumn(
                name: "LevelId",
                table: "HiredContractProposals");

            migrationBuilder.DropColumn(
                name: "Ral",
                table: "HiredContractProposals");

            migrationBuilder.DropColumn(
                name: "TrialPeriod",
                table: "HiredContractProposals");

            migrationBuilder.DropColumn(
                name: "TutorFunction",
                table: "HiredContractProposals");

            migrationBuilder.RenameTable(
                name: "HiredContractProposals",
                newName: "HiredContractProposal");

            migrationBuilder.RenameColumn(
                name: "SuperMinimumAbsorbable",
                table: "HiredContractProposal",
                newName: "Contract");

            migrationBuilder.RenameColumn(
                name: "IsAerospaceDefence",
                table: "HiredContractProposal",
                newName: "IsAerospaceDefenceNavalSector");

            migrationBuilder.RenameColumn(
                name: "HasSensitiveData",
                table: "HiredContractProposal",
                newName: "AlreadyStage");

            migrationBuilder.RenameColumn(
                name: "ClassifiedProject",
                table: "HiredContractProposal",
                newName: "MonthDuration");

            migrationBuilder.AlterColumn<int>(
                name: "Vote",
                table: "PersonalDetails",
                type: "int",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AddColumn<int>(
                name: "LevelId",
                table: "LevelCost",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<float>(
                name: "AnnualGrossIncome",
                table: "HiredContractProposal",
                type: "real",
                nullable: false,
                defaultValue: 0f);

            migrationBuilder.AddColumn<DateTime>(
                name: "EndDate",
                table: "HiredContractProposal",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddPrimaryKey(
                name: "PK_HiredContractProposal",
                table: "HiredContractProposal",
                column: "Id");

            migrationBuilder.CreateIndex(
                name: "IX_LevelCost_LevelId",
                table: "LevelCost",
                column: "LevelId");

            migrationBuilder.AddForeignKey(
                name: "FK_LevelCost_Level_LevelId",
                table: "LevelCost",
                column: "LevelId",
                principalTable: "Level",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
