﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Pers.DAL.Migrations
{
    public partial class InitialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ContractProposal",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ContractType = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StartStageDateTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    EndStageDateTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    MissedPayment = table.Column<float>(type: "real", nullable: false),
                    HiringLocation = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Addresslocation = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    MobilityLayoff = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Duration = table.Column<int>(type: "int", nullable: true),
                    IsAlreadyintern = table.Column<bool>(type: "bit", nullable: true),
                    StartDeterminate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    EndDeterminate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ReliefsPossibility = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Status = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Customer = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IsAerospaceDefensenavalSector = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    JobDescription = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Tutor1 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Tutor2 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AdministrationSistem = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TutorFunction = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SensitiveDataHandlingConsultants = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IsBillable = table.Column<bool>(type: "bit", nullable: false),
                    TrialPeriod = table.Column<int>(type: "int", nullable: false),
                    ClassificationLevel = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    AnnualGrossIncome = table.Column<float>(type: "real", nullable: false),
                    MinimumGrading = table.Column<float>(type: "real", nullable: false),
                    GrossMonthlySalary = table.Column<float>(type: "real", nullable: false),
                    BonusType = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DaiLyRate = table.Column<float>(type: "real", nullable: false),
                    UserId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ContractProposal", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Candidate",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Surname = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PhoneNumber = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FiscalCode = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    BirthPlace = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    BirthDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Gender = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ResidentialAddress = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ResidentialCap = table.Column<int>(type: "int", nullable: false),
                    ResidentialCity = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LivingAddress = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LivingCap = table.Column<int>(type: "int", nullable: false),
                    LivingCity = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Degree = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    University = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DegreeAddress = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TypeDegreee = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DegreeGrade = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IsFirstExperience = table.Column<bool>(type: "bit", nullable: false),
                    OriginCompany = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IsSingleNationality = table.Column<bool>(type: "bit", nullable: false),
                    IsItalianNationality = table.Column<bool>(type: "bit", nullable: false),
                    Seconarynationality = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Note1 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Note2 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ContractProposalId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Candidate", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Candidate_ContractProposal_ContractProposalId",
                        column: x => x.ContractProposalId,
                        principalTable: "ContractProposal",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "User",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    IdKeycloak = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Surname = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FiscalCode = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    BirthDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Gender = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    City = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Region = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Province = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ZipCode = table.Column<int>(type: "int", nullable: false),
                    Address = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ContractProposalId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_User", x => x.Id);
                    table.ForeignKey(
                        name: "FK_User_ContractProposal_ContractProposalId",
                        column: x => x.ContractProposalId,
                        principalTable: "ContractProposal",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_Candidate_ContractProposalId",
                table: "Candidate",
                column: "ContractProposalId");

            migrationBuilder.CreateIndex(
                name: "IX_User_ContractProposalId",
                table: "User",
                column: "ContractProposalId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Candidate");

            migrationBuilder.DropTable(
                name: "User");

            migrationBuilder.DropTable(
                name: "ContractProposal");
        }
    }
}
