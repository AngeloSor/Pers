﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Pers.DAL.Migrations
{
    public partial class ChangePcReservation : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Candidate_PcReservation_PcReservationId",
                table: "Candidate");

            migrationBuilder.DropIndex(
                name: "IX_Candidate_PcReservationId",
                table: "Candidate");

            migrationBuilder.DropColumn(
                name: "PcReservationId",
                table: "Candidate");

            migrationBuilder.RenameColumn(
                name: "PcNoCustom",
                table: "PcReservation",
                newName: "LaptopModel");

            migrationBuilder.AddColumn<int>(
                name: "CandidateId",
                table: "PcReservation",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<float>(
                name: "approximatePrice",
                table: "PcReservation",
                type: "real",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_PcReservation_CandidateId",
                table: "PcReservation",
                column: "CandidateId");

            migrationBuilder.AddForeignKey(
                name: "FK_PcReservation_Candidate_CandidateId",
                table: "PcReservation",
                column: "CandidateId",
                principalTable: "Candidate",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_PcReservation_Candidate_CandidateId",
                table: "PcReservation");

            migrationBuilder.DropIndex(
                name: "IX_PcReservation_CandidateId",
                table: "PcReservation");

            migrationBuilder.DropColumn(
                name: "CandidateId",
                table: "PcReservation");

            migrationBuilder.DropColumn(
                name: "approximatePrice",
                table: "PcReservation");

            migrationBuilder.RenameColumn(
                name: "LaptopModel",
                table: "PcReservation",
                newName: "PcNoCustom");

            migrationBuilder.AddColumn<int>(
                name: "PcReservationId",
                table: "Candidate",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Candidate_PcReservationId",
                table: "Candidate",
                column: "PcReservationId",
                unique: true,
                filter: "[PcReservationId] IS NOT NULL");

            migrationBuilder.AddForeignKey(
                name: "FK_Candidate_PcReservation_PcReservationId",
                table: "Candidate",
                column: "PcReservationId",
                principalTable: "PcReservation",
                principalColumn: "Id");
        }
    }
}
