﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Pers.DAL.Migrations
{
    public partial class ChangeCandidate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "Career",
                table: "Candidate",
                type: "bit",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "StateForm",
                table: "Candidate",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Career",
                table: "Candidate");

            migrationBuilder.DropColumn(
                name: "StateForm",
                table: "Candidate");
        }
    }
}
