﻿using Org.BouncyCastle.Asn1.Mozilla;
using Pers.DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.DAL.IRepositories
{
    public interface IHiredContractProposalRepository: IRepository<HiredContractProposal>
    {
        Task<HiredContractProposal> Find(int id);
        Task<bool> ContractExist(int id);
        Task<bool> ContractAlreadyAssociated(int contractId);
        Task<bool> ContractAlreadyAssociatedWithIdControl(int Id, int contractId);

    }
}
