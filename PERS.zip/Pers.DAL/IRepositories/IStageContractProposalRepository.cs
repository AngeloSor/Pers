﻿using Pers.DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.DAL.IRepositories
{
	public interface IStageContractProposalRepository : IRepository<StageContractProposal>
	{
        public Task<StageContractProposal> Find(int id);
        public Task<bool> ContractExist(int id);
        public Task<StageContractProposal> FindContract(int candidateId);
        Task<bool> ContractAlreadyAssociated(int contractId);
    }
}

