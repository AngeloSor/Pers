﻿using Pers.DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.DAL.IRepositories
{
    public interface IEquipmentManagementRepository : IRepository<EquipmentManagement>
    {
        Task<bool> ContractAlreadyAssociated(int contractId);
        Task<bool> ContractAlreadyAssociatedWithIdControl(int Id, int contractId);
        Task<bool> EquipmentExists(int id);
        Task<bool> DataCheck(DateTime date, TimeOnly time);
    }
}
