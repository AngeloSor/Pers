﻿using Pers.DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pers.DAL.IRepositories
{
	public interface ICandidateProfileRepository : IRepository<CandidateProfile>
	{
        Task<bool> CandidateExists(int id);
        Task<bool> CandidateExists(string email);
        Task<List<CandidateProfile>> GetCandidateBM(int bmId);
		Task<List<CandidateProfile>> GetCandidateWithAcceptedForm();
        Task<bool> SetFormToSend(CandidateProfile candidateProfile);
        Task<bool> SetFormToCompiled(CandidateProfile candidateProfile);
        Task<bool> SetCareer(CandidateProfile candidateProfile);


    }
}
