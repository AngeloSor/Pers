﻿using Pers.DAL.Entities;

namespace Pers.DAL.IRepositories
{
    public interface IPersonalDetailsRepository : IRepository<PersonalDetails>
    {
        Task<bool> DetailsExists(int id);
        Task<bool> CandidateAssociatedExists(int candidateId);
        Task<PersonalDetails?> FindByCandidate(int candidateId);
    }
}
