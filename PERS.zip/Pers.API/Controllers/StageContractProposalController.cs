﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata;
using Pers.BLL.IServices;
using CoreApiResponse;
using Pers.BLL.Models;
using Pers.BLL.Services;
using Pers.DAL.Entities;
using Pers.DAL.IRepositories;
using Pers.DAL.Repositories;
using System.Data;
using System.Net;
using System.Security.Claims;
using System.ComponentModel.DataAnnotations;

namespace Pers.API.Controllers
{


	[EnableCors("default")]
	[ApiController]
	[Route("api/StageContractProposal")]
	public class StageContractProposalController : BaseController
	{
		private readonly IStageContractProposalService _stageContractProposalService;
		public StageContractProposalController(IStageContractProposalService stageContractProposalService)
		{
			_stageContractProposalService = stageContractProposalService;
		}

		[HttpPost("Create")]
		[Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,bm,hr")]
		public async Task<IActionResult> Create(StageContractProposalDTO stageContractProposalDTO)
		{
			var response = await _stageContractProposalService.Create(stageContractProposalDTO);
			return CustomResult(response.Message, response.Dto, response.StatusCode);
		}

		[HttpGet("GetAll")]
		[Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
		public async Task<IActionResult> GetAll()
		{
			var response = await _stageContractProposalService.GetAll();
			return CustomResult(response.Message, response.DTOs, response.StatusCode);        }
		[HttpPut("Update")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,bm,hr")]
        public async Task<IActionResult> Update(StageContractProposalDTO contractProposalDTO)
        {
            var response = await _stageContractProposalService.Update(contractProposalDTO);
            return CustomResult(response.Message, response.Dto, response.StatusCode);
        }
		[HttpGet("Find")]
		[Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,bm,hr")]
		public async Task<IActionResult> Find([Required]int id)
		{
			var response = await _stageContractProposalService.Find(id);
			return CustomResult(response.Message, response.Dto, response.StatusCode);

		}
        [HttpGet("FindForSpecificCandidate")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,bm,hr")]
        public async Task<IActionResult> FindForSpecificCandidate([Required]int candidateId)
        {
            var response = await _stageContractProposalService.FindContractProposal(candidateId);
            return CustomResult(response.Message, response.Dto, response.StatusCode);

        }
        [HttpDelete("Delete")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,bm,hr")]
        public async Task<IActionResult> Delete([Required]int Id)
        {
            var response = await _stageContractProposalService.Delete(Id);
            return CustomResult(response.Message, response.Dto, response.StatusCode);
        }

	}
}
