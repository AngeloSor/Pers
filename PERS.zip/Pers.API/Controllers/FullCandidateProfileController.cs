﻿using CoreApiResponse;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Pers.BLL.IServices;
using Pers.BLL.Models;
using Pers.BLL.Services;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Net;

namespace Pers.API.Controllers
{

    [EnableCors("default")]
    [ApiController]
    [Route("api/CandidateFullProfile")]
    public class FullCandidateProfileController : BaseController
    {
        private readonly IFullCandidateProfileService _fullCandidateProfileService;
        public FullCandidateProfileController(IFullCandidateProfileService fullcandidateProfileService)
        {
            _fullCandidateProfileService = fullcandidateProfileService;
            
        }
        [HttpPut("Update")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        public async Task<IActionResult> Update(FullCandidateProfileDTO candidateProfileDTO)
        {
            var response = await _fullCandidateProfileService.Put(candidateProfileDTO);
            return CustomResult(response.Message, response.Dto, response.StatusCode);

        }
        [HttpGet("Find")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,bm,hr")]
        public async Task<IActionResult> Find([Required]int Id)
        {
            var response = await _fullCandidateProfileService.Find(Id);
            return CustomResult(response.Message, response.Dto, response.StatusCode);
        }

        [HttpGet("GetAll")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,hr")]
        public async Task<IActionResult> GetAll()
        {
            var response = await _fullCandidateProfileService.GetAll();
            return CustomResult(response.Message, response.DTOs, response.StatusCode);
        }
        [HttpDelete("Delete")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,bm,hr")]
        public async Task<IActionResult> Delete([Required]int Id)
        {
            var response = await _fullCandidateProfileService.Delete(Id);
            return CustomResult(response.Message, response.Dto, response.StatusCode);
        }



    }
}
