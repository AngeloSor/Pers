﻿using CoreApiResponse;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Pers.BLL.IServices;
using System.ComponentModel.DataAnnotations;

namespace Pers.API.Controllers
{
    [EnableCors("default")]
    [ApiController]
    [Route("api/[Controller]")]
    public class LevelController : BaseController
    {
        private readonly ILevelService _levelService;
        public LevelController(ILevelService levelService)
        {
            _levelService = levelService;
        }
        [HttpGet("Find")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator, hr, bm")]
        public async Task<IActionResult> Find([Required]int id)
        {
            var response = await _levelService.Find(id);
            return CustomResult(response.Message, response.Dto, response.StatusCode);
        }
        [HttpGet("GetAll")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator, hr, bm")]
        public async Task<IActionResult> GetAll()
        {
            var response = await _levelService.GetAll();
            return CustomResult(response.Message, response.DTOs, response.StatusCode);
        }
    }
}
