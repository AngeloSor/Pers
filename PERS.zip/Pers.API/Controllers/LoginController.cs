﻿using Microsoft.AspNetCore.Mvc;
using CoreApiResponse;
using Pers.BLL.IServices;
using Pers.BLL.Models;
using Microsoft.AspNetCore.Cors;
using System.Collections;
using Pers.BLL.Services;

namespace Pers.API.Controllers
{
    [EnableCors("default")]
    [ApiController]
    [Route("api/Login")]
    public class LoginController : BaseController
    {
        private readonly IKeycloakService _keycloakService;
        private readonly ICandidateProfileService _candidateProfileService;
        public LoginController(IKeycloakService keycloakService, ICandidateProfileService candidateProfileService)
        {
            _keycloakService = keycloakService;
            _candidateProfileService = candidateProfileService;
        }

        [HttpPost("Login")]
        public async Task<IActionResult> Login(CredentialDTO credentialDTO)
        {
            var response = await _keycloakService.Login(credentialDTO);
            return CustomResult(response.Message, response.Dto, response.StatusCode);
        }
        [HttpGet("GetStatusForm")]
        public async Task<CandidateProfileDTO.FormType> GetStatusForm(int id)
        {
            try
            {
                var response = await _candidateProfileService.Find(id);
                return response.Dto.StateForm;
            }
            catch (Exception ex) 
            {
                throw ex;
            }  
        }
        [HttpGet("RefreshToken")]
        public async Task<IActionResult> RefreshToken(string token)
        {
            var response = await _keycloakService.RefreshToken(token);
            return CustomResult(response.Message, response.Dto, response.StatusCode);
        }
        [HttpPut("SetPassword")]
        public async Task<bool> SetPassword(string password,string userId)
        {
            var response = await _keycloakService.SetPasswordOnKeycloak(password,userId);
            return response;
        }


    }
}
