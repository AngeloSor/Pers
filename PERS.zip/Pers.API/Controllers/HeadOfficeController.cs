﻿using CoreApiResponse;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Pers.BLL.IServices;
using System.ComponentModel.DataAnnotations;

namespace Pers.API.Controllers
{
    [EnableCors("default")]
    [ApiController]
    [Route("api/HeadOffice")]
    public class HeadOfficeController : BaseController
    {
        private readonly IHeadOfficeService _headOfficeService;
        
        public HeadOfficeController(IHeadOfficeService headOfficeService)
        {
            _headOfficeService= headOfficeService;

        }

        [HttpGet("Find")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator, bm, hr")]
        public async Task<IActionResult> Find([Required]int id)
        {
            var response = await _headOfficeService.Find(id);
            return CustomResult(response.Message, response.Dto, response.StatusCode);
        }
        [HttpGet("GetAll")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator, bm, hr")]
        public async Task<IActionResult> GetAll()
        {
            var response = await _headOfficeService.GetAll();
            return CustomResult(response.Message, response.DTOs, response.StatusCode);
        }
    }
}
