﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using CoreApiResponse;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Pers.BLL.IServices;
using Pers.BLL.Models;
using Pers.BLL.Services;
using Pers.DAL.Entities;
using Pers.DAL.IRepositories;
using Pers.DAL.Repositories;
using System.Data;
using System.Net;
using System.Security.Claims;
using System.Threading.Tasks.Dataflow;
using System.Web.Http.Results;
using System.Reflection.Metadata.Ecma335;
using MimeKit.Cryptography;
using System.ComponentModel.DataAnnotations;

namespace Pers.API.Controllers
{
    [EnableCors("default")]
    [ApiController]
    [Route("api/BmHrProfile")]
    public class BmHrProfileController : BaseController
    {
        private readonly IBmHrProfileService _bmHrProfileService;
        public BmHrProfileController(IBmHrProfileService bmHrProfileService)
        {
            _bmHrProfileService = bmHrProfileService;
        }

        [HttpPost("Create")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        public async Task<IActionResult> Create(BmHrProfileDTO bmHrProfileDTO)
        {
            var response = await _bmHrProfileService.Create(bmHrProfileDTO);
            return CustomResult(response.Message,response.Dto, response.StatusCode);
        }
        
        [HttpGet("Find")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,bm,hr")]
        public async Task<IActionResult> Find([Required]int id)
        {
            var response = await _bmHrProfileService.Find(id);
            return CustomResult(response.Message, response.Dto, response.StatusCode);
        }
        [HttpGet("FindByEmail")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,bm,hr")]
        public async Task<IActionResult> Find([Required]string email)
        {
            var response = await _bmHrProfileService.Find(email);
            return CustomResult(response.Message, response.Dto, response.StatusCode);
        }
        [HttpGet("GetAll")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        public async Task<IActionResult> GetAll()
        {
            var response = await _bmHrProfileService.GetAll();
            return CustomResult(response.Message, response.DTOs, response.StatusCode);
            
        }

        [HttpPut("Update")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        public async Task<IActionResult> Put(BmHrProfileDTO bmHrProfileDTO)
        {
            var response = await _bmHrProfileService.Put(bmHrProfileDTO);
            return CustomResult(response.Message, response.Dto, response.StatusCode);

        }

        [HttpDelete("Delete")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        public async Task<IActionResult> Delete([Required]int id)
        {
            var response = await _bmHrProfileService.Delete(id);
            return CustomResult(response.Message, response.Dto, response.StatusCode);
        }
    }
        
}
