﻿using Azure;
using CoreApiResponse;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Identity.Client;
using Pers.BLL.IServices;
using Pers.BLL.Models;
using Pers.BLL.Services;
using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using static Pers.API.Configuration.AddAuthKeycloak.AuthorizationConstants;

namespace Pers.API.Controllers
{
    [EnableCors("default")]
    [ApiController]
    [Route("api/PersonalDetails")]
    public class PersonalDetailsController : BaseController
    {
        private readonly IPersonalDetailsService _personalDetailsService;
        public PersonalDetailsController(IPersonalDetailsService personalDetailsService)
        {
            _personalDetailsService= personalDetailsService;

        }
        [HttpPost("Create"), DisableRequestSizeLimit]
        public async Task<IActionResult> Create(PersonalDetailsDTO personalDetailsDTO)
        {
            try 
            {
                
                
                var response = await _personalDetailsService.Create(personalDetailsDTO);
                return CustomResult(response.Message, response.Dto, response.StatusCode);
            }
            catch (Exception ex)
            {
                return CustomResult(ex.Message, System.Net.HttpStatusCode.InternalServerError);

            }

        }
        [HttpPost("UploadFiles")]
        public async Task<IActionResult> UploadFiles([FromForm]FilesDTO files)
        {

            var response = await _personalDetailsService.FilesManagement(files);
            return CustomResult(response.Message, response.Dto, response.StatusCode);
        }
        [HttpGet("Find")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,bm,hr")]
        public async Task<IActionResult> Find([Required]int id)
        {
            var response = await _personalDetailsService.Find(id);
            return CustomResult(response.Message, response.Dto, response.StatusCode);

        }
        [HttpGet("FindDetailsForCandidate")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,bm,hr")]
        public async Task<IActionResult> FindDetailsForCandidate([Required]int idCandidate)
        {
            var response = await _personalDetailsService.FindDetailsForSpecificCandidate(idCandidate);
            return CustomResult(response.Message, response.Dto, response.StatusCode);
        }
        [HttpPut("Update")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,bm,hr")]
        public async Task<IActionResult> Update(PersonalDetailsDTO contractProposalDTO)
        {
            var response = await _personalDetailsService.Put(contractProposalDTO);
            return CustomResult(response.Message, response.Dto, response.StatusCode);
        }

        [HttpGet("GetIdCard")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,bm,hr")]
        public async Task<IActionResult> GetIdCard([Required] int candidateId)
        {
            var response = await _personalDetailsService.GetIdCard(candidateId);
            return CustomResult(response.Message, response.Dto, response.StatusCode);

        }
        [HttpGet("GetHealthCard")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,bm,hr")]
        public async Task<IActionResult> GetHealthCard([Required] int candidateId)
        {
            var response = await _personalDetailsService.GetHealthCard(candidateId);
            return CustomResult(response.Message, response.Dto, response.StatusCode);

        }
        [HttpGet("GetResidencePermit")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,bm,hr")]
        public async Task<IActionResult> GetResidencePermit([Required] int candidateId)
        {
            var response = await _personalDetailsService.GetResidencepermit(candidateId);
            return CustomResult(response.Message, response.Dto, response.StatusCode);

        }
        [HttpGet("HasResidencePermit")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,bm,hr")]
        public async Task<bool> HasResidencePermit(int candidateId) 
        {
            var response = await _personalDetailsService.HasResidencePermit(candidateId);
            return response;
        }
        [HttpDelete("Delete")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,bm,hr")]
        public async Task<IActionResult> Delete([Required]int Id)
        {
            var response = await _personalDetailsService.Delete(Id);
            return CustomResult(response.Message, response.Dto, response.StatusCode);
        }
    }
}
