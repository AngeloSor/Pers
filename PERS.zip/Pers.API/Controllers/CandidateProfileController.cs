﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata;
using Pers.BLL.IServices;
using CoreApiResponse;
using Pers.BLL.Models;
using Pers.BLL.Services;

using System.Data;
using System.Net;
using System.Security.Claims;
using System;
using System.ComponentModel.DataAnnotations;

namespace Pers.API.Controllers
{

	[EnableCors("default")]
	[ApiController]
	[Route("api/CandidateStartingProfile")]
	public class CandidateProfileController : BaseController
	{
		private readonly ICandidateProfileService _candidateProfileService;
        private readonly IStageContractProposalService _stageContractProposalService;
		private readonly IPowerAutomateService _powerAutomateService;
		public CandidateProfileController(ICandidateProfileService candidateProfileService, IPowerAutomateService powerAutomateService, IStageContractProposalService stageContractProposalService)
		{
			_candidateProfileService = candidateProfileService;
			_powerAutomateService = powerAutomateService;
            _stageContractProposalService = stageContractProposalService;
		}
		[HttpPost("Create")]
		[Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator, bm, hr")]
		public async Task<IActionResult> Create([Required] CandidateProfileDTO candidateProfileDTO)
		{
			var response = await _candidateProfileService.Create(candidateProfileDTO);
            return CustomResult(response.Message, response.Dto, response.StatusCode);
        }
        [HttpGet("Find")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator, bm, hr")]
        public async Task<IActionResult> Find([Required] int Id)
        {
            var response = await _candidateProfileService.Find(Id);
            return CustomResult(response.Message, response.Dto, response.StatusCode);
        }
        [HttpGet("GetAllCandidateBm")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator, bm")]
        public async Task<IActionResult> GetAllCandidateBm([Required] int bmProfileId)
        {
            var response = await _candidateProfileService.GetAllCandidateBm(bmProfileId);
            return CustomResult(response.Message, response.DTOs, response.StatusCode);

        }
        [HttpGet("GetAllCandidateWithAcceptedForm")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator, bm")]
        public async Task<IActionResult> GetAllCandidateWithAcceptedForm()
        {
            var response = await _candidateProfileService.GetAllCandidateWithAcceptedForm();
            return CustomResult(response.Message, response.DTOs, response.StatusCode);

        }

        [HttpGet("GetAll")]
		[Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,hr")]
		public async Task<IActionResult> GetAll()
		{
			var response = await _candidateProfileService.GetAll();
            return CustomResult(response.Message, response.DTOs, response.StatusCode);
        }

        [HttpPut("Update")]
		[Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator, bm, hr")]
		public async Task<IActionResult> Put([Required] CandidateProfileDTO candidateProfileDTO)
        {
            var response = await _candidateProfileService.Put(candidateProfileDTO);
            return CustomResult(response.Message, response.Dto, response.StatusCode);
        }
        [HttpPut("SetStatusFormToSend")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator, bm, hr")]
        public async Task<IActionResult> SetStatusFormToSend([Required] int id)
        {
            var response = await _candidateProfileService.SetFormToSend(id);
            return CustomResult(response.Message, response.Dto, response.StatusCode);
        }
        [HttpPut("SetStatusFormToCompiled")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator, bm, hr")]
        public async Task<IActionResult> SetStatusFormToCompiled([Required] int id)
        {
            var response = await _candidateProfileService.SetFormToCompiled(id);
            return CustomResult(response.Message, response.Dto, response.StatusCode);
        }
        [HttpPut("SetCareer")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator, bm, hr")]
        public async Task<IActionResult> SetCareer([Required] int id)
        {
            var response = await _candidateProfileService.SetCareer(id);
            return CustomResult(response.Message, response.Dto, response.StatusCode);
        }
        [HttpPost("SendFormToCandidate")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator, bm, hr")]
        public async Task<IActionResult> SendFormToCandidate([Required] CandidateProfileDTO candidateProfileDTO)
        {
			var response = await _powerAutomateService.SendForm(candidateProfileDTO);
            return CustomResult(response.Message, response.Dto, response.StatusCode);

        }

    }
}
