﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using CoreApiResponse;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Pers.BLL.IServices;
using Pers.BLL.Models;
using Pers.BLL.Services;
using Pers.DAL.Entities;
using Pers.DAL.IRepositories;
using Pers.DAL.Repositories;
using System.Data;
using System.Net;
using System.Security.Claims;
using System.Threading.Tasks.Dataflow;
using System.Web.Http.Results;
using System.Reflection.Metadata.Ecma335;
using System.ComponentModel.DataAnnotations;

namespace Pers.API.Controllers
{
    [EnableCors("default")]
    [ApiController]
    [Route("api/PcReservation")]
    public class PcReservationController : BaseController
    {
        private readonly IPcReservationService _pcReservationService;
        public PcReservationController(IPcReservationService pcReservationService)
        {
            _pcReservationService = pcReservationService;
        }

		
        [HttpPut("Update")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator, bm")]
        public async Task<IActionResult> Update (PcReservationDTO pcReservationDTO)
        {
            var response = await _pcReservationService.Update(pcReservationDTO);
            return CustomResult(response.Message, response.Dto, response.StatusCode);
        }
        [HttpGet("Find")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator, bm")]
        public async Task<IActionResult> Find ([Required]int Id)
        {
            var response = await _pcReservationService.Find(Id);
            return CustomResult(response.Message, response.Dto, response.StatusCode);
        }
        [HttpGet("FindSmall")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator, bm")]
        public async Task<IActionResult> FindSmall([Required] int Id)
        {
            var response = await _pcReservationService.FindSmall(Id);
            return CustomResult(response.Message, response.Dto, response.StatusCode);
        }
        [HttpGet("GetAll")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator, bm")]
        public async Task<IActionResult> GetAll()
        {
            var response = await _pcReservationService.GetAll();
            return CustomResult(response.Message, response.DTOs, response.StatusCode);
            
        }
        [HttpGet("GetAllSmall")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator, bm")]
        public async Task<IActionResult> GetAllSmall()
        {
            var response = await _pcReservationService.GetAllSmall();
            return CustomResult(response.Message, response.DTOs, response.StatusCode);

        }
        [HttpDelete("Delete")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator, bm")]
        public async Task<IActionResult> Delete([Required]int Id)
        {
            var response = await _pcReservationService.Delete(Id);
            return CustomResult(response.Message, response.Dto, response.StatusCode);
        }
    }
}
