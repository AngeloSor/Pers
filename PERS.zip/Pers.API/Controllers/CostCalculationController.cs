﻿using CoreApiResponse;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Pers.BLL.IServices;
using Pers.BLL.Models;
using Pers.BLL.Services;
using System.ComponentModel.DataAnnotations;
using static Pers.API.Configuration.AddAuthKeycloak.AuthorizationConstants;

namespace Pers.API.Controllers
{
    [EnableCors("default")]
    [ApiController]
    [Route("api/CostCalculation")]
    public class CostCalculationController : BaseController
    {
        private readonly ICostCalculationService _costCalculationService;
        public CostCalculationController(ICostCalculationService costCalculationService)
        {
            _costCalculationService = costCalculationService;
        }


        [HttpPost("MarginResourceCost")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator, bm")]
        public async Task<IActionResult> GenerateMarginResourceCost(ContractDTO contractDTO)
        {
            var response = await _costCalculationService.GenerateMarginResourceCost(contractDTO);
            return CustomResult(response.Message, response.Dto, response.StatusCode);
        }

        
    }
}
