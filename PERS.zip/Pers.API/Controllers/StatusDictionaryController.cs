﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Pers.BLL.IServices;

namespace Pers.API.Controllers
{
    [EnableCors("default")]
    [Route("api/StatusDictionary")]
    [ApiController]
    public class StatusDictionaryController : ControllerBase
    {
        private readonly IStatusDictionaryService _statusDictionaryService;
        public StatusDictionaryController(IStatusDictionaryService statusDictionaryService)
        {
            _statusDictionaryService= statusDictionaryService;
        }
        [HttpGet("GetStatusDictionary")]
        public Dictionary<string, string> GetDictionary(string language)
        {
            var response = _statusDictionaryService.GetDictionary(language);
            return response;
        }

    }
}
