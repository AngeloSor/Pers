﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Pers.BLL.IServices;
using CoreApiResponse;
using Pers.BLL.Models;
using System.ComponentModel.DataAnnotations;

namespace Pers.API.Controllers
{
    [EnableCors("default")]
    [ApiController]
    [Route("api/HiredContractProposal")]
    public class HiredContractProposalController : BaseController
    {
        private readonly IHiredContractProposalService _hiredContractProposalService;
        public HiredContractProposalController(IHiredContractProposalService hiredContractProposalService)
        {
            _hiredContractProposalService = hiredContractProposalService;
        }
        [HttpPost("Create")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,bm,hr")]
        public async Task<IActionResult> Create([Required]HiredContractProposalDTO hiredContractProposalDTO)
        { 
            var response = await _hiredContractProposalService.Create(hiredContractProposalDTO);
            return CustomResult(response.Message, response.Dto, response.StatusCode);
        }
        [HttpGet("Find")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator, bm,hr")]
        public async Task<IActionResult> Find([Required]int Id)
        {
            var response = await _hiredContractProposalService.Find(Id);
            return CustomResult(response.Message, response.Dto, response.StatusCode);
        }
        [HttpPut("Update")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator, bm, hr")]
        public async Task<IActionResult> Put([Required]HiredContractProposalDTO hiredContractProposalDTO)
        {
            var response = await _hiredContractProposalService.Put(hiredContractProposalDTO);
            return CustomResult(response.Message, response.Dto, response.StatusCode);
        
        }
        [HttpGet("GetAll")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator, bm, hr")]
        public async Task<IActionResult> GetAll()
        {
            var response = await _hiredContractProposalService.GetAll();
            return CustomResult(response.Message, response.DTOs, response.StatusCode);
        }
        [HttpDelete("Delete")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator, bm, hr")]
        public async Task<IActionResult> Delete([Required] int Id)
        {
            var response = await _hiredContractProposalService.Delete(Id);
            return CustomResult(response.Message, response.Dto, response.StatusCode);
        }
    }
}
