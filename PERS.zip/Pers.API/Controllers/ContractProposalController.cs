﻿using CoreApiResponse;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Pers.BLL.IServices;
using Pers.BLL.Models;
using System.ComponentModel.DataAnnotations;

namespace Pers.API.Controllers
{
    [EnableCors("default")]
    [ApiController]
    [Route("api/ContractProposal")]
    public class ContractProposalController : BaseController
    {
        private readonly IContractProposalService _contractProposalService;
       public ContractProposalController(IContractProposalService contractProposalService) 
       { 
            _contractProposalService = contractProposalService;
       }

        [HttpPost("Create")]
        [Authorize(AuthenticationSchemes ="Bearer", Roles = "administrator, bm")]
        public async Task<IActionResult> Create(ContractProposalDTO contractProposalDTO)
        {
            var response = await _contractProposalService.Create(contractProposalDTO);
            return CustomResult(response.Message, response.Dto, response.StatusCode);
        }

        [HttpPut("Update")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator, bm")]
        public async Task<IActionResult> Update(ContractProposalDTO contractProposalDTO)
        {
            var response = await _contractProposalService.Update(contractProposalDTO);
            return CustomResult(response.Message, response.Dto, response.StatusCode);
        }

        [HttpGet("Find")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator, bm, hr")]
        public async Task<IActionResult> Find([Required]int  id)
        {
            var response = await _contractProposalService.Find(id);
            return CustomResult(response.Message, response.Dto, response.StatusCode);
        }
        [HttpDelete("Delete")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator, bm")]
        public async Task<IActionResult> Delete([Required]int id)
        {
            var response = await _contractProposalService.Delete(id);
            return CustomResult(response.Message, response.Dto, response.StatusCode);
        }

        [HttpGet("GetAll")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator, bm")]
        public async Task<IActionResult> GetAll()
        {
            var response = await _contractProposalService.GetAll();
            return CustomResult(response.Message, response.DTOs, response.StatusCode);
        }

    }
}
