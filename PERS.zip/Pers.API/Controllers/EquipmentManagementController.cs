﻿using CoreApiResponse;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Pers.BLL.IServices;
using Pers.BLL.Models;
using Pers.BLL.Services;
using System.ComponentModel.DataAnnotations;
using static Pers.API.Configuration.AddAuthKeycloak.AuthorizationConstants;

namespace Pers.API.Controllers
{
    [EnableCors("default")]
    [ApiController]
    [Route("api/EquipmentManagement")]
    public class EquipmentManagementController : BaseController
    {
        private readonly IEquipmentManagementService _equipmentManagementService;
        public EquipmentManagementController([Required]IEquipmentManagementService equipmentManagementService)
        {
            _equipmentManagementService = equipmentManagementService;
        }
        [HttpPost("Create")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,bm,hr")]
        public async Task<IActionResult> Create([Required]EquipmentManagementDTO equipmentManagementDTO)
        {
            var response = await _equipmentManagementService.Create(equipmentManagementDTO);
            return CustomResult(response.Message, response.Dto, response.StatusCode);
        }
        [HttpGet("GetAll")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        public async Task<IActionResult> GetAll()
        {
            var response = await _equipmentManagementService.GetAll();
            return CustomResult(response.Message, response.DTOs, response.StatusCode);
        }
        [HttpPut("Update")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,bm,hr")]
        public async Task<IActionResult> Update([Required]EquipmentManagementDTO equipmentManagementDTO)
        {
            var response = await _equipmentManagementService.Update(equipmentManagementDTO);
            return CustomResult(response.Message, response.Dto, response.StatusCode);
        }
        [HttpGet("Find")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,bm,hr")]
        public async Task<IActionResult> Find([Required]int id)
        {
            var response = await _equipmentManagementService.Find(id);
            return CustomResult(response.Message, response.Dto, response.StatusCode);

        }
        [HttpDelete("Delete")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,bm,hr")]
        public async Task<IActionResult> Delete([Required]int Id)
        {
            var response = await _equipmentManagementService.Delete(Id);
            return CustomResult(response.Message, response.Dto, response.StatusCode);
        }
    }
}
