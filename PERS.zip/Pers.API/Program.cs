using System.Net.Http.Headers;
using System.Text;
using System.Text.Json.Serialization;
using AutoMapper;
using Keycloak.AuthServices.Authentication;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.OpenApi.Models;
using Pers.API.Configuration;
using Pers.BLL.IServices;
using Pers.BLL.Services;
using Pers.DAL;
using Pers.DAL.Context;
using Pers.DAL.IRepositories;
using Pers.DAL.Repositories;
using NLog;
using NLog.Web;
using Pers.BLL.Dictionaries;
using System.Reflection;
using Swashbuckle.AspNetCore.SwaggerGen;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.Extensions.FileProviders;

var logger = NLog.LogManager.Setup().LoadConfigurationFromAppSettings().GetCurrentClassLogger();
logger.Debug("init main");

try
{
    var builder = WebApplication.CreateBuilder(args);
    var configuration = builder.Configuration;

    builder.Services.AddControllers();
    builder.Services.Configure<FormOptions>(o =>
    {
        o.ValueLengthLimit = int.MaxValue;
        o.MultipartBoundaryLengthLimit= int.MaxValue;
        o.MemoryBufferThreshold= int.MaxValue;
    });
    builder.Services.AddEndpointsApiExplorer();
    builder.Services.AddControllersWithViews()
        .AddNewtonsoftJson(options =>
        options.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
    );
    builder.Services.AddDateOnlyTimeOnlyStringConverters();
    builder.Services.AddAuthorization(options =>
    {
        options.AddPolicy("administrator", policy => policy.RequireClaim("user_roles", "[administrator]"));
        options.AddPolicy("bm", policy => policy.RequireClaim("user_roles", "[bm]"));
        options.AddPolicy("hr", policy => policy.RequireClaim("user_roles", "[hr]"));
    });

    builder.Services.AddSwaggerGen(c =>
    {
        c.UseDateOnlyTimeOnlyStringConverters();
        c.SwaggerDoc("v1", new OpenApiInfo { Title = "MyWebApi", Version = "v1" });
        
        c.AddSecurityDefinition(
            "Bearer",
            new OpenApiSecurityScheme
            {
                Description = "JWT Authorization header using the Bearer scheme.",
                Type = SecuritySchemeType.Http,
                Scheme = JwtBearerDefaults.AuthenticationScheme
            });

        c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
              Reference = new OpenApiReference
              {
                  Id = JwtBearerDefaults.AuthenticationScheme,
                  Type = ReferenceType.SecurityScheme
              }
            },
            new List<string>()
        }
    });
    });
    builder.Services.AddMvc().AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.WriteIndented = true;
        options.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
        options.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
    });
    builder.Services.AddDbContext<PersDbContext>(
      options => options.UseSqlServer(
         builder.Configuration.GetConnectionString("DbConn")
      )
    );


    builder.Services.AddDatabaseDeveloperPageExceptionFilter();
    var services = new ServiceCollection();
    builder.Services.AddAutoMapper(typeof(AutoMapperConfiguration));
    var mapperConfig = new MapperConfiguration(cfg =>
    {
        cfg.AddProfile(new AutoMapperConfiguration());
    });
    IMapper mapper = mapperConfig.CreateMapper();
    services.AddSingleton(mapper);

    builder.Services.AddCors(core =>
    {
        core.AddPolicy("default", options =>
        {
            options.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader();
        });
    });
    builder.Services.AddHttpContextAccessor();


    builder.Services.AddScoped<IAzureBlobService, AzureBlobService>();



    builder.Services.AddScoped<IBmHrProfileService, BmHrProfileService>();
    builder.Services.AddScoped<IBmHrProfileRepository, BmHrProfileRepository>();

    builder.Services.AddScoped<ICandidateProfileService, CandidateProfileService>();
    builder.Services.AddScoped<ICandidateProfileRepository, CandidateProfileRepositoy>();

    builder.Services.AddScoped<ICostCalculationService, CostCalculationService>();

    builder.Services.AddScoped<IEquipmentManagementService, EquipmentManagementService>();
    builder.Services.AddScoped<IEquipmentManagementRepository, EquipmentManagementRepository>();

    builder.Services.AddScoped<IFullCandidateProfileService, FullCandidateProfileService>();

    builder.Services.AddScoped<IHiredContractProposalRepository, HiredContractProposalRepository>();
    builder.Services.AddScoped<IHiredContractProposalService, HiredContractProposalService>();

    builder.Services.AddScoped<IKeycloakService, KeycloakService>();

    builder.Services.AddScoped<IPcReservationService, PcReservationService>();
    builder.Services.AddScoped<IPcReservationRepository, PcReservationRepository>();

    builder.Services.AddScoped<IPersonalDetailsRepository,PersonalDetailsRepository>();
    builder.Services.AddScoped<IPersonalDetailsService, PersonalDetailsService>();

    builder.Services.AddScoped<IPowerAutomateService, PowerAutomateService>();

    builder.Services.AddScoped<IStageContractProposalService, StageContractProposalService>();
    builder.Services.AddScoped<IStageContractProposalRepository, StageContractProposalRepository>();

    builder.Services.AddScoped<IContractProposalService, ContractProposalService>();
    builder.Services.AddScoped<IContractProposalRepository, ContractProposalRepository>();

    builder.Services.AddScoped<IHeadOfficeService, HeadOfficeService>();
    builder.Services.AddScoped<IHeadOfficeRepository, HeadOfficeRepository>();

    builder.Services.AddScoped<ILevelRepository, LevelRepository>();
    builder.Services.AddScoped<ILevelService, LevelService>();

    builder.Services.AddScoped<ICandidateFileRepository, CandidateFileRepository>();

    builder.Services.AddScoped<StatusDictionaryResponse, StatusDictionaryResponse>();
    builder.Services.AddScoped<IStatusDictionaryService, StatusDictionaryService>(); 

    //builder.Services.AddTransient<IClaimsTransformation, ClaimsTransformer>();

    
    

    builder.Logging.ClearProviders();
    builder.Host.UseNLog();

    builder.Services.AddKeycloakAuthentication(configuration);

    var app = builder.Build();


    // Configure the HTTP request pipeline.

    app.UseCors("default");
    //app.UseStaticFiles();
    //app.UseStaticFiles(new StaticFileOptions
    //{
    //    FileProvider = new PhysicalFileProvider(Path.Combine(Directory.GetCurrentDirectory(), @"Resources")),
    //    RequestPath = new PathString("/Resources")
    //}) ;
    app.UseSwagger();
    app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "Lotus.API.Integration v1"));

    app.MapGet("/", () => DateTime.UtcNow);

    app.UseHttpsRedirection();

    app.UseAuthorization();

    app.MapControllers();

    app.Run();
}
catch (Exception exception)
{
    // NLog: catch setup errors
    logger.Error(exception, "Stopped program because of exception");
    throw;
}
finally
{
    // Ensure to flush and stop internal timers/threads before application-exit (Avoid segmentation fault on Linux)
    NLog.LogManager.Shutdown();
}
