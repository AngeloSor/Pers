﻿using AutoMapper;
using Keycloak.AuthServices.Sdk.Admin.Models;
using Microsoft.AspNetCore.Routing.Constraints;
using Pers.BLL.Models;
using Pers.DAL.Entities;
using System;
using System.Globalization;

namespace Pers.API.Configuration
{
    public class AutoMapperConfiguration : Profile
    {
        public AutoMapperConfiguration() 
        {
            CreateMap<BmHrProfile,BmHrProfileDTO>().ReverseMap();

            CreateMap<BmHrProfileDTO, UserKeycloak>()
               .ForMember
               (
                    dest => dest.username,
                    opt => opt.MapFrom(src => $"{src.Email}")
               )
               .ForMember
               (
                    dest => dest.firstName,
                    opt => opt.MapFrom(src => $"{src.Name}")
               )
               .ForMember
               (
                    dest => dest.lastName,
                    opt => opt.MapFrom(src => $"{src.Surname}")
               );
            
            CreateMap<CandidateProfile, FullCandidateProfileDTO>().ReverseMap();
            
            CreateMap<ContractProposal, ContractProposalDTO>().ReverseMap();
            
            CreateMap<HiredContractProposal, HiredContractProposalDTO>().ReverseMap();  
            
            CreateMap<StageContractProposal, StageContractProposalDTO>().ReverseMap();
            
            CreateMap<CandidateProfile, CandidateProfileDTO>().ForMember(
                dest => dest.Bm,
                opt => opt.MapFrom(src => $"{src.BmHr.Name}" + " " + $"{src.BmHr.Surname}")
                ).ReverseMap();
            
            CreateMap<EquipmentManagement, PcReservationDTO>().ForMember(
                dest => dest.Candidate,
                opt => opt.MapFrom(src => $"{src.ContractProposal.Candidate.Name}" + " " + $"{src.ContractProposal.Candidate.Surname}") 
                ).ForMember(
                dest => dest.BmHrId,
                opt => opt.MapFrom(src => $"{src.ContractProposal.BmHrId}")
                ).ReverseMap();

            CreateMap<EquipmentManagement, SmallReservationDTO>().ForMember(
                dest => dest.Candidate,
                opt => opt.MapFrom(src => $"{src.ContractProposal.Candidate.Name}" + " " + $"{src.ContractProposal.Candidate.Surname}")
                ).ForMember(
                dest => dest.BmHrId,
                opt => opt.MapFrom(src => $"{src.ContractProposal.BmHrId}")
                ).ReverseMap();

            CreateMap<Level, LevelDTO>().ReverseMap();
            
            CreateMap<HeadOffice, HeadOfficeDTO>().ReverseMap();

            CreateMap<PersonalDetails, PersonalDetailsDTO>().ForMember(
               dest => dest.CandidateEmail,
               opt => opt.MapFrom( src => $"{src.CandidateProfile.Email}")
                ).ReverseMap();
            CreateMap<EquipmentManagement, EquipmentManagementDTO>().ReverseMap();
            

        }
    }
}
